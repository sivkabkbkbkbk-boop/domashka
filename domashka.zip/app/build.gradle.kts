plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "ru.domashka"
    compileSdk = 34

    defaultConfig {
        applicationId = "ru.domashka"
        minSdk = 28
        targetSdk = 34
        versionCode = 5
        versionName = "1.4"
    }

    // Постоянный ключ подписи: новые версии ставятся поверх старых, данные сохраняются
    signingConfigs {
        create("family") {
            storeFile = file("domashka.jks")
            storePassword = "domashka123"
            keyAlias = "domashka"
            keyPassword = "domashka123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("family")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("family")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Распознавание текста на телефоне (русский + английский), без интернета
    implementation("cz.adaptech.tesseract4android:tesseract4android-openmp:4.9.0")
}

// Модели распознавания: русский — самая точная версия (tessdata_best), английский — обычная.
// Скачиваются при сборке, поэтому менять файл сборки на GitHub не нужно.
val ocrModels = mapOf(
    "rus" to "https://github.com/tesseract-ocr/tessdata_best/raw/main/rus.traineddata",
)
val downloadOcrModels by tasks.registering {
    val dir = file("src/main/assets/tessdata")
    val markers = layout.buildDirectory.dir("ocr-models").get().asFile
    doLast {
        dir.mkdirs()
        markers.mkdirs()
        // английская модель больше не нужна — ищем только русские названия предметов
        File(dir, "eng.traineddata").delete()
        ocrModels.forEach { (lang, url) ->
            val target = File(dir, "$lang.traineddata")
            val marker = File(markers, "$lang.url")
            if (!target.exists() || !marker.exists() || marker.readText() != url) {
                println("Скачиваю модель $lang: $url")
                val tmp = File(dir, "$lang.download")
                uri(url).toURL().openStream().use { input -> tmp.outputStream().use { input.copyTo(it) } }
                check(tmp.length() > 1_000_000) { "Модель $lang скачалась не полностью" }
                target.delete()
                tmp.renameTo(target)
                marker.writeText(url)
            }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(downloadOcrModels) }
