package ru.domashka.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import ru.domashka.data.AppDatabase
import ru.domashka.data.HomeworkTask
import ru.domashka.data.elapsed
import ru.domashka.data.isRunning
import ru.domashka.data.Subject
import ru.domashka.data.SubjectKey
import ru.domashka.ocr.OcrEngine
import ru.domashka.ocr.SubjectParser

/** Черновик задания после распознавания — ребёнок может поправить перед сохранением. */
data class Draft(val id: Int, val subject: String, val text: String)

sealed interface OcrState {
    data object Idle : OcrState
    data object Opening : OcrState
    /** Экран обрезки: ребёнок выделяет нужную часть (например, один день). */
    data class Crop(val bitmap: Bitmap) : OcrState
    data object Processing : OcrState
    data class Review(val drafts: List<Draft>, val preview: Bitmap? = null) : OcrState
    data class Error(val message: String) : OcrState
}

const val NO_SUBJECT = "Без предмета"

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDatabase.get(app).dao()
    private val ocr = OcrEngine(app)
    private val writeLock = Mutex()
    private var nextDraftId = 1

    val subjects: StateFlow<List<Subject>> = dao.subjects()
        .map { list -> list.sortedBy { it.name.lowercase() } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val tasks: StateFlow<List<HomeworkTask>> = dao.tasks()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _ocrState = MutableStateFlow<OcrState>(OcrState.Idle)
    val ocrState: StateFlow<OcrState> = _ocrState.asStateFlow()

    // ---------- Распознавание ----------

    private var cropSource: Bitmap? = null

    fun openImage(uri: Uri) {
        _ocrState.value = OcrState.Opening
        viewModelScope.launch {
            try {
                val bmp = ocr.loadBitmap(uri)
                cropSource = bmp
                _ocrState.value = OcrState.Crop(bmp)
            } catch (e: Throwable) {
                _ocrState.value = OcrState.Error("Не удалось открыть фото: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun rotateCrop() {
        val src = cropSource ?: return
        viewModelScope.launch {
            val rotated = withContext(Dispatchers.Default) { ocr.rotate(src) }
            cropSource = rotated
            _ocrState.value = OcrState.Crop(rotated)
        }
    }

    /** l, t, r, b — выделенная часть снимка в долях (0..1). */
    fun recognizeCrop(l: Float, t: Float, r: Float, b: Float) {
        val src = cropSource ?: return
        _ocrState.value = OcrState.Processing
        viewModelScope.launch {
            try {
                val part = withContext(Dispatchers.Default) { ocr.crop(src, l, t, r, b) }
                val text = ocr.recognize(part)
                if (text.isBlank()) {
                    _ocrState.value = OcrState.Error(
                        "Не получилось найти текст. Попробуй сфотографировать ровнее и при хорошем свете."
                    )
                    return@launch
                }
                val blocks = SubjectParser.split(text, subjects.value.map { it.name })
                if (blocks.isEmpty()) {
                    _ocrState.value = OcrState.Error("На снимке нет домашних заданий — везде «не задано». 🎉")
                    return@launch
                }
                _ocrState.value = OcrState.Review(
                    drafts = blocks.map { Draft(nextDraftId++, it.subject ?: "", it.text) },
                    preview = part
                )
                cropSource = null
            } catch (e: Throwable) {
                _ocrState.value = OcrState.Error("Ошибка распознавания: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun addManualDraft() {
        val review = _ocrState.value as? OcrState.Review
        _ocrState.value = OcrState.Review(
            (review?.drafts ?: emptyList()) + Draft(nextDraftId++, "", ""),
            review?.preview
        )
    }

    fun updateDraft(draft: Draft) {
        val s = _ocrState.value as? OcrState.Review ?: return
        _ocrState.value = s.copy(drafts = s.drafts.map { if (it.id == draft.id) draft else it })
    }

    fun removeDraft(id: Int) {
        val s = _ocrState.value as? OcrState.Review ?: return
        val left = s.drafts.filterNot { it.id == id }
        _ocrState.value = if (left.isEmpty()) OcrState.Idle else s.copy(drafts = left)
    }

    fun dismissOcr() {
        cropSource = null
        _ocrState.value = OcrState.Idle
    }

    fun saveDrafts() {
        val s = _ocrState.value as? OcrState.Review ?: return
        _ocrState.value = OcrState.Idle
        viewModelScope.launch {
            writeLock.withLock {
                val now = System.currentTimeMillis()
                s.drafts.filter { it.text.isNotBlank() }.forEachIndexed { index, d ->
                    val subjectId = subjectIdFor(d.subject)
                    // +index чтобы порядок заданий совпадал с порядком на фото
                    dao.insertTask(HomeworkTask(subjectId = subjectId, text = d.text.trim(), createdAt = now - index))
                }
            }
        }
    }

    /** Находит предмет по имени или создаёт новый. Дублей не бывает. */
    private suspend fun subjectIdFor(rawName: String): Long {
        val name = SubjectKey.clean(rawName).ifEmpty { NO_SUBJECT }
        val key = SubjectKey.of(name)
        dao.subjectByKey(key)?.let { return it.id }
        val id = dao.insertSubject(Subject(name = name, nameKey = key))
        return if (id > 0) id else dao.subjectByKey(key)!!.id
    }

    // ---------- Задания ----------

    private fun stopped(t: HomeworkTask, now: Long): HomeworkTask =
        if (t.timerStartedAt == null) t
        else t.copy(spentMs = t.elapsed(now), timerStartedAt = null)

    fun toggleDone(taskId: Long) = viewModelScope.launch {
        writeLock.withLock {
            val t = dao.task(taskId) ?: return@withLock
            val now = System.currentTimeMillis()
            if (!t.done) dao.updateTask(stopped(t, now).copy(done = true, doneAt = now))
            else dao.updateTask(t.copy(done = false, doneAt = null))
        }
    }

    /** Запуск/пауза таймера. Одновременно идёт только один таймер. */
    fun toggleTimer(taskId: Long) = viewModelScope.launch {
        writeLock.withLock {
            val t = dao.task(taskId) ?: return@withLock
            val now = System.currentTimeMillis()
            if (t.isRunning) {
                dao.updateTask(stopped(t, now))
            } else {
                dao.runningTasks().forEach { dao.updateTask(stopped(it, now)) }
                dao.updateTask(t.copy(timerStartedAt = now, done = false, doneAt = null))
            }
        }
    }

    fun resetTimer(taskId: Long) = viewModelScope.launch {
        writeLock.withLock {
            val t = dao.task(taskId) ?: return@withLock
            dao.updateTask(t.copy(spentMs = 0, timerStartedAt = null))
        }
    }

    fun editTask(taskId: Long, text: String, subjectName: String) = viewModelScope.launch {
        writeLock.withLock {
            val t = dao.task(taskId) ?: return@withLock
            val subjectId = subjectIdFor(subjectName)
            dao.updateTask(t.copy(text = text.trim().ifEmpty { t.text }, subjectId = subjectId))
        }
    }

    fun deleteTask(taskId: Long) = viewModelScope.launch {
        writeLock.withLock {
            dao.task(taskId)?.let { dao.deleteTask(it) }
        }
    }

    // ---------- Предметы ----------

    /** Переименование. Если такое имя уже есть — предметы сливаются в один. */
    fun renameSubject(subject: Subject, newName: String) = viewModelScope.launch {
        writeLock.withLock {
            val name = SubjectKey.clean(newName)
            if (name.isEmpty()) return@withLock
            val key = SubjectKey.of(name)
            val other = dao.subjectByKey(key)
            if (other != null && other.id != subject.id) {
                dao.moveTasks(subject.id, other.id)
                dao.deleteSubject(subject)
            } else {
                dao.updateSubject(subject.copy(name = name, nameKey = key))
            }
        }
    }

    /** Удаляет предмет вместе с его заданиями. */
    fun deleteSubject(subject: Subject) = viewModelScope.launch {
        writeLock.withLock { dao.deleteSubject(subject) }
    }
}
