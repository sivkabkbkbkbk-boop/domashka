package ru.domashka.ui

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import ru.domashka.data.Outfit
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 16-битные спрайты голубя (assets/pigeon). Все кадры 100×102 пикселя и лежат друг на друге:
 * голубь собирается из слоёв — лапки, тело, крыло, шея с головой, вещи.
 */
object PigeonSprites {
    const val W = 100
    const val H = 102
    /** Кадр соответствует области рисунка: x от -8 до 110, y от -20 до 100. */
    const val VB_X = -8f
    const val VB_Y = -20f
    const val VB_W = 118f
    const val VB_H = 120f

    private val cache = ConcurrentHashMap<String, ImageBitmap>()
    private val missing = ConcurrentHashMap.newKeySet<String>()
    @Volatile private var appContext: Context? = null

    fun init(context: Context) {
        if (appContext == null) appContext = context.applicationContext
    }

    /** Загружаем все кадры заранее (вызывать в фоне). */
    fun preload(context: Context) {
        appContext = context.applicationContext
        val files = context.assets.list("pigeon") ?: return
        for (f in files) {
            if (!f.endsWith(".png")) continue
            val name = f.removeSuffix(".png")
            if (!cache.containsKey(name)) load(name)
        }
    }

    private fun load(name: String): ImageBitmap? {
        val ctx = appContext ?: return null
        return try {
            ctx.assets.open("pigeon/$name.png").use { BitmapFactory.decodeStream(it) }
                ?.asImageBitmap()?.also { cache[name] = it }
        } catch (e: Exception) {
            missing += name
            null
        }
    }

    fun get(name: String): ImageBitmap? {
        cache[name]?.let { return it }
        if (name in missing) return null
        return load(name)
    }
}

/** Поза голубя из готовых кадров. */
data class SpritePose(
    val pose: String = "idle",      // idle / peck1 / peck2
    val eyes: String = "open",      // open / closed / talk (для idle)
    val flap: Int = 0,              // крыло: 0 / 30 / 60
    val step: Int = 0,              // лапки: -1 / 0 / 1
)

/** Куда на холсте легло: чтобы рисовать реквизит в тех же координатах, что и голубь. */
class SpriteFrame(val left: Float, val top: Float, val width: Float, val height: Float) {
    fun map(x: Float, y: Float) = Offset(
        left + (x - PigeonSprites.VB_X) / PigeonSprites.VB_W * width,
        top + (y - PigeonSprites.VB_Y) / PigeonSprites.VB_H * height,
    )
    /** Сколько пикселей экрана в одной единице рисунка. */
    val unit: Float get() = width / PigeonSprites.VB_W
}

/**
 * Рисует голубя по слоям. Картинка вписывается в холст (по возможности целым масштабом — пиксели чёткие),
 * стоит по центру снизу. dx/dy — смещение в единицах рисунка (прыжки, дрожь).
 */
fun DrawScope.drawPigeonSprite(
    outfit: Outfit,
    p: SpritePose,
    chain: Boolean = false,
    glasses: Boolean = true,
    dx: Float = 0f,
    dy: Float = 0f,
): SpriteFrame {
    val raw = min(size.width / PigeonSprites.W, size.height / PigeonSprites.H)
    val scale = if (raw >= 2f) floor(raw) else raw
    val dw = PigeonSprites.W * scale
    val dh = PigeonSprites.H * scale
    val unit = dw / PigeonSprites.VB_W
    val left = (size.width - dw) / 2f + dx * unit
    val top = size.height - dh + dy * unit
    val frame = SpriteFrame(left, top, dw, dh)

    val color = outfit.color ?: "slate"
    val pose = p.pose
    val headEyes = if (pose == "idle") p.eyes else "open"
    val layers = buildList {
        if (outfit.back == "cape") add("item_cape_$pose")
        add("legs_${color}_${p.step.coerceIn(-1, 1) + 1}")
        add("torso_${color}_$pose")
        if (outfit.back == "backpack") add("item_backpack_$pose")
        add("wing_${color}_${pose}_${listOf(0, 30, 60).minByOrNull { kotlin.math.abs(it - p.flap) }}")
        add("head_${color}_${pose}_$headEyes")
        val neck = if (chain) "chain" else outfit.neck
        if (neck != null) add("item_${neck}_$pose")
        if (glasses && headEyes != "closed" && outfit.eyes != null) add("item_${outfit.eyes}_$pose")
        if (outfit.head != null) add("item_${outfit.head}_$pose")
    }
    val dstOff = IntOffset(left.roundToInt(), top.roundToInt())
    val dstSize = IntSize(max(1, dw.roundToInt()), max(1, dh.roundToInt()))
    for (name in layers) {
        val img = PigeonSprites.get(name) ?: continue
        drawImage(
            image = img,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(img.width, img.height),
            dstOffset = dstOff,
            dstSize = dstSize,
            filterQuality = FilterQuality.None,
        )
    }
    return frame
}
