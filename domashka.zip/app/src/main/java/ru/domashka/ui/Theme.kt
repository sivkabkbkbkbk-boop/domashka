package ru.domashka.ui

import android.content.Context
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Фирменные цвета: тёмный «игровой» фон и неон. */
object Brand {
    val Bg = Color(0xFF0E0F1F)
    val Surface = Color(0xFF1A1C36)
    val Surface2 = Color(0xFF262A4D)
    val Violet = Color(0xFF8B5CF6)
    val Cyan = Color(0xFF22D3EE)
    val Lime = Color(0xFFA3E635)
    val Pink = Color(0xFFFB3B6E)
    val Gold = Color(0xFFFFC53D)
    val Text = Color(0xFFF4F4FF)
    val Muted = Color(0xFFA3A6C9)

    val Main = Brush.horizontalGradient(listOf(Violet, Cyan))
    val Hot = Brush.horizontalGradient(listOf(Pink, Color(0xFFFF8A3D)))
    val Win = Brush.horizontalGradient(listOf(Lime, Color(0xFF34D399)))
    val Header = Brush.linearGradient(listOf(Color(0xFF3B1F8F), Color(0xFF0E7490)))

    /** Цвет-акцент предмета (стабильный для одного и того же названия). */
    private val accents = listOf(
        Color(0xFF8B5CF6), Color(0xFF22D3EE), Color(0xFFA3E635), Color(0xFFFB3B6E),
        Color(0xFFFFC53D), Color(0xFF34D399), Color(0xFFFF8A3D), Color(0xFF60A5FA),
    )
    fun accent(name: String): Color = accents[(name.lowercase().hashCode() and 0x7fffffff) % accents.size]
}

/** Эмодзи для предмета. */
fun subjectEmoji(name: String): String {
    val n = name.lowercase()
    return when {
        "рус" in n -> "✍️"
        "литер" in n || "чтение" in n -> "📖"
        "матем" in n || "алгеб" in n -> "🧮"
        "геометр" in n -> "📐"
        "вероятн" in n -> "🎲"
        "англ" in n || "иностр" in n -> "🇬🇧"
        "немец" in n -> "🇩🇪"
        "франц" in n -> "🇫🇷"
        "китай" in n -> "🇨🇳"
        "истор" in n -> "🏛️"
        "общество" in n -> "🤝"
        "географ" in n -> "🌍"
        "биолог" in n -> "🧬"
        "окружающ" in n -> "🌳"
        "физик" in n -> "⚛️"
        "хими" in n -> "🧪"
        "информ" in n -> "💻"
        "музык" in n -> "🎵"
        "изо" == n || "искусств" in n -> "🎨"
        "труд" in n || "технолог" in n -> "🔨"
        "физкульт" in n || "физ-ра" in n || "физическая" in n -> "⚽"
        "разговор" in n -> "💬"
        "экскурс" in n -> "🚌"
        "исследоват" in n || "проект" in n -> "🔬"
        "однкнр" in n -> "🕊️"
        "обзр" in n || "обж" in n -> "🦺"
        "грамотн" in n -> "🧠"
        "горизонт" in n -> "🧭"
        else -> "📚"
    }
}

/** Спортивный шрифт для заголовков (скачивается при сборке; если его нет — обычный жирный). */
private fun displayFamily(context: Context): FontFamily {
    return try {
        val files = context.assets.list("fonts") ?: emptyArray()
        if ("display.ttf" in files) FontFamily(Font("fonts/display.ttf", context.assets))
        else FontFamily.Default
    } catch (e: Exception) {
        FontFamily.Default
    }
}

@Composable
fun DomashkaTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val display = remember { displayFamily(context) }
    val scheme = darkColorScheme(
        primary = Brand.Violet,
        onPrimary = Color.White,
        primaryContainer = Color(0xFF34256E),
        onPrimaryContainer = Brand.Text,
        secondary = Brand.Cyan,
        onSecondary = Color(0xFF002A33),
        tertiary = Brand.Lime,
        onTertiary = Color(0xFF1A2E05),
        error = Brand.Pink,
        background = Brand.Bg,
        onBackground = Brand.Text,
        surface = Brand.Bg,
        onSurface = Brand.Text,
        surfaceVariant = Brand.Surface2,
        onSurfaceVariant = Brand.Muted,
        surfaceContainer = Brand.Surface,
        surfaceContainerLow = Brand.Surface,
        surfaceContainerHigh = Brand.Surface2,
        surfaceContainerHighest = Brand.Surface2,
        outline = Color(0xFF4B4F80),
    )
    val base = Typography()
    val typography = Typography(
        displaySmall = base.displaySmall.copy(fontFamily = display, fontSize = 34.sp),
        headlineLarge = base.headlineLarge.copy(fontFamily = display, fontSize = 28.sp),
        headlineMedium = base.headlineMedium.copy(fontFamily = display, fontSize = 24.sp),
        headlineSmall = base.headlineSmall.copy(fontFamily = display, fontSize = 20.sp),
        titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold, fontSize = 19.sp),
        titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        titleSmall = base.titleSmall.copy(fontWeight = FontWeight.Medium),
        labelLarge = base.labelLarge.copy(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, letterSpacing = 0.3.sp),
        bodyLarge = base.bodyLarge,
        bodyMedium = base.bodyMedium,
        bodySmall = base.bodySmall,
        labelMedium = base.labelMedium,
        labelSmall = base.labelSmall,
    )
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}
