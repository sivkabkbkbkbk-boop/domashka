package ru.domashka.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import ru.domashka.data.AchStats
import ru.domashka.data.Achievement
import ru.domashka.data.AchievementList
import ru.domashka.data.Item
import ru.domashka.data.Items
import ru.domashka.data.Outfit
import ru.domashka.data.Slot

/** Вкладка «Ачивки»: сверху гардероб голубя, ниже список ачивок. */
@Composable
fun AchievementsTab(
    stats: AchStats,
    unlocked: Set<String>,
    outfit: Outfit,
    onToggle: (Item) -> Unit,
    modifier: Modifier = Modifier,
) {
    val all = AchievementList.ALL
    val sorted = all.sortedWith(compareBy<Achievement>({ it.id !in unlocked }, { -(it.progress(stats).toFloat() / it.target) }))
    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(Brand.Header)
                        .padding(18.dp)
                ) {
                    Text("🏆 Открыто ${unlocked.size} из ${all.size}", style = MaterialTheme.typography.headlineSmall, color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    NeonProgress(unlocked.size.toFloat() / all.size, brush = Brush.horizontalGradient(listOf(Brand.Gold, Color(0xFFFF8A3D))))
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Сделано заданий: ${stats.done} · по таймеру: ${formatHuman(stats.timedMs)} · лучшая серия: ${stats.bestStreak} дн.",
                        color = Color.White.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item { WardrobeSection(unlocked, outfit, onToggle) }
        item {
            Text("Ачивки", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 8.dp))
        }
        items(sorted, key = { it.id }) { a -> AchievementCard(a, stats, a.id in unlocked) }
    }
}

@Composable
private fun AchievementCard(a: Achievement, stats: AchStats, open: Boolean) {
    val value = a.progress(stats).coerceAtMost(a.target)
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = if (open) Color(0xFF2A2350) else Brand.Surface),
        border = if (open) BorderStroke(1.5.dp, Brand.Gold.copy(alpha = 0.7f)) else null
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(if (open) Brand.Gold.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.06f)),
                contentAlignment = Alignment.Center
            ) {
                Text(if (open) a.emoji else "🔒", fontSize = 26.sp, modifier = Modifier.alpha(if (open) 1f else 0.6f))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(a.title, style = MaterialTheme.typography.titleMedium, color = if (open) Brand.Gold else Brand.Text)
                Text(a.description, style = MaterialTheme.typography.bodySmall, color = Brand.Muted)
                Items.forAchievement(a.id)?.let { reward ->
                    Text(
                        "🎁 ${reward.emoji} ${reward.name}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (open) Brand.Lime else Brand.Muted
                    )
                }
                if (!open && a.target > 1) {
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { NeonProgress(value.toFloat() / a.target, brush = Brand.Main) }
                        Spacer(Modifier.width(8.dp))
                        Text("$value/${a.target}", style = MaterialTheme.typography.labelSmall, color = Brand.Muted)
                    }
                }
            }
        }
    }
}

/** Всплывающий сверху баннер «Новая ачивка!». Сам исчезает через несколько секунд. */
@Composable
fun AchievementBanner(a: Achievement?, sounds: Sounds, onDone: () -> Unit, modifier: Modifier = Modifier) {
    var shown by remember { mutableStateOf<Achievement?>(null) }
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(a?.id) {
        if (a == null) return@LaunchedEffect
        shown = a
        visible = true
        sounds.achievement()
        delay(3800)
        visible = false
        delay(400)
        onDone()
    }
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically { -it } + fadeIn(),
        exit = slideOutVertically { -it } + fadeOut(),
        modifier = modifier
    ) {
        val s = shown ?: return@AnimatedVisibility
        Row(
            Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF3B2A0A), Color(0xFF5B3A12))))
                .clickable {
                    visible = false
                }
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(s.emoji, fontSize = 34.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Новая ачивка!", color = Brand.Gold, style = MaterialTheme.typography.labelLarge)
                Text(s.title, color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text(s.description, color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall)
                Items.forAchievement(s.id)?.let {
                    Text("🎁 Голубю: ${it.emoji} ${it.name}", color = Brand.Lime, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

/** Гардероб: голубь в наряде и все вещи по местам. Нажми — наденет, ещё раз — снимет. */
@Composable
private fun WardrobeSection(unlocked: Set<String>, outfit: Outfit, onToggle: (Item) -> Unit) {
    var hint by remember { mutableStateOf("Нажми на вещь, чтобы надеть или снять её") }
    val have = Items.ALL.count { it.achId in unlocked }
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Brand.Surface)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                MascotPigeon(Modifier.size(120.dp), dancing = false, outfit = outfit)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("Гардероб голубя", style = MaterialTheme.typography.headlineSmall)
                    Text("Вещей: $have из ${Items.ALL.size}", color = Brand.Muted, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(hint, color = Brand.Cyan, style = MaterialTheme.typography.bodySmall)
                }
            }
            Slot.entries.forEach { slot ->
                Spacer(Modifier.height(10.dp))
                Text(slot.title, style = MaterialTheme.typography.labelLarge, color = Brand.Muted)
                Spacer(Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    lazyItems(Items.ALL.filter { it.slot == slot }, key = { it.id }) { item ->
                        val open = item.achId in unlocked
                        val worn = outfit.get(slot) == item.id
                        val achTitle = AchievementList.ALL.firstOrNull { it.id == item.achId }?.title ?: ""
                        Column(
                            Modifier
                                .width(78.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    when {
                                        worn -> Brand.Violet
                                        open -> Brand.Surface2
                                        else -> Color.White.copy(alpha = 0.04f)
                                    }
                                )
                                .clickable {
                                    if (open) {
                                        onToggle(item)
                                        hint = if (worn) "Снял: ${item.name}" else "Надел: ${item.name} 😎"
                                    } else {
                                        hint = "🔒 ${item.name} — открой ачивку «$achTitle»"
                                    }
                                }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(if (open) item.emoji else "🔒", fontSize = 26.sp, modifier = Modifier.alpha(if (open) 1f else 0.5f))
                            Text(
                                item.name,
                                fontSize = 11.sp,
                                color = if (open) Brand.Text else Brand.Muted,
                                maxLines = 2,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                lineHeight = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
