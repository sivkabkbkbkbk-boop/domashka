package ru.domashka.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.random.Random

private enum class Mode { IDLE, WALK, PECK, LOOK }

/**
 * Голубь, который тихонько гуляет по низу экрана: ходит, клюёт, оглядывается, иногда курлычет.
 * Нажмёшь — сделает одно из действий (семечко, погладить, танцы…).
 * calm = true, пока идёт домашка: гуляет реже и совсем молча, чтобы не отвлекать.
 */
@Composable
fun WanderingPigeon(
    sounds: Sounds,
    calm: Boolean,
    outfit: ru.domashka.data.Outfit,
    onAction: (PetAction) -> Unit,
    modifier: Modifier = Modifier,
) {
    val calmState by rememberUpdatedState(calm)
    val scope = rememberCoroutineScope()
    val measurer = rememberTextMeasurer()

    BoxWithConstraints(modifier.fillMaxSize()) {
        val birdSize = 140.dp
        val maxX = (maxWidth - birdSize).value.coerceAtLeast(0f)
        val x = remember { Animatable(maxX * 0.75f) }
        var facingRight by remember { mutableStateOf(false) }
        var mode by remember { mutableStateOf(Mode.IDLE) }
        val peck = remember { Animatable(0f) }
        var action by remember { mutableStateOf<PetAction?>(null) }
        val actionT = remember { Animatable(0f) }
        var bubble by remember { mutableStateOf<String?>(null) }

        val tr = rememberInfiniteTransition(label = "walk")
        val stepPhase by tr.animateFloat(-1f, 1f, infiniteRepeatable(tween(260, easing = LinearEasing), RepeatMode.Reverse), label = "step")
        val breathe by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "breathe")

        // жизнь голубя
        LaunchedEffect(maxX) {
            while (isActive) {
                if (action != null) {
                    delay(200)
                    continue
                }
                try {
                    val r = Random.nextFloat()
                    when {
                        r < 0.4f -> { // пройтись
                            val target = Random.nextFloat() * maxX
                            val dist = abs(target - x.value)
                            if (dist > 10f) {
                                facingRight = target > x.value
                                mode = Mode.WALK
                                x.animateTo(target, tween((dist / 45f * 1000f).toInt().coerceAtLeast(300), easing = LinearEasing))
                            }
                            mode = Mode.IDLE
                        }
                        r < 0.65f -> { // поклевать
                            mode = Mode.PECK
                            repeat(Random.nextInt(2, 4)) {
                                peck.animateTo(1f, tween(180))
                                if (!calmState && Random.nextFloat() < 0.5f) sounds.ambientPeck()
                                peck.animateTo(0f, tween(220))
                                delay(120)
                            }
                            mode = Mode.IDLE
                        }
                        r < 0.85f -> { // оглядеться
                            mode = Mode.LOOK
                            repeat(Random.nextInt(1, 3)) {
                                delay(Random.nextLong(500, 1100))
                                facingRight = !facingRight
                            }
                            mode = Mode.IDLE
                        }
                        else -> { // курлыкнуть
                            if (!calmState) {
                                sounds.ambientCoo(Random.nextInt(100))
                                bubble = listOf("курлык", "курлы?", "кур-кур", "…").random()
                                delay(1400)
                                bubble = null
                            }
                        }
                    }
                    delay(if (calmState) Random.nextLong(4000, 9000) else Random.nextLong(900, 3000))
                } catch (e: CancellationException) {
                    if (!isActive) throw e
                    mode = Mode.IDLE
                    peck.snapTo(0f)
                }
            }
        }

        fun doAction(a: PetAction) {
            scope.launch {
                x.stop()
                peck.snapTo(0f)
                mode = Mode.IDLE
                action = a
                bubble = a.phrase
                onAction(a)
                val cues = petCues(a, sounds)
                var next = 0
                val steps = a.durationMs / 16
                for (i in 0..steps) {
                    val t = i.toFloat() / steps
                    while (next < cues.size && cues[next].first <= t) {
                        cues[next].second()
                        next++
                    }
                    actionT.snapTo(t)
                    delay(16)
                }
                action = null
                delay(600)
                bubble = null
            }
        }

        Box(
            Modifier
                .align(Alignment.BottomStart)
                .offset(x = x.value.dp)
                .padding(bottom = 4.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                bubble?.let {
                    Text(
                        it,
                        fontSize = 12.sp,
                        color = Brand.Text,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .widthIn(max = 180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brand.Surface2.copy(alpha = 0.95f))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
                Canvas(
                    Modifier
                        .size(birdSize)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { doAction(PetAction.entries.random()) }
                ) {
                    val a = action
                    scale(if (facingRight) 1f else -1f, 1f) {
                        drawPigeonScene(
                            measurer = measurer,
                            a = a,
                            t = actionT.value,
                            breathe = breathe,
                            step = if (mode == Mode.WALK && a == null) stepPhase else 0f,
                            peck = if (a == null) peck.value else 0f,
                            outfit = outfit,
                        )
                    }
                }
            }
        }
    }
}
