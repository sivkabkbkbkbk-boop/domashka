package ru.domashka.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import ru.domashka.R

/**
 * Спокойная фоновая музыка, пока идёт домашка.
 * 5 треков, играют по кругу в случайном порядке (один и тот же дважды подряд не повторяется).
 * Плавно появляется и плавно затихает.
 */
class MusicPlayer(private val context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val tracks = listOf(R.raw.music_1, R.raw.music_2, R.raw.music_3, R.raw.music_4, R.raw.music_5)
    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var queue = ArrayDeque<Int>()
    private var lastTrack = -1
    private var volume = 0f
    private var wantPlaying = false

    var enabled: Boolean
        get() = prefs.getBoolean("music", true)
        set(value) {
            prefs.edit().putBoolean("music", value).apply()
            if (!value) stop()
        }

    private fun nextTrack(): Int {
        if (queue.isEmpty()) {
            var order = tracks.shuffled()
            if (order.first() == lastTrack && order.size > 1) order = order.drop(1) + order.first()
            queue = ArrayDeque(order)
        }
        return queue.removeFirst().also { lastTrack = it }
    }

    fun start() {
        if (!enabled) return
        wantPlaying = true
        if (player == null) playNext() else fadeTo(TARGET)
    }

    fun stop() {
        wantPlaying = false
        fadeTo(0f)
    }

    private fun playNext() {
        release()
        if (!wantPlaying) return
        val mp = MediaPlayer.create(context, nextTrack()) ?: return
        mp.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        )
        mp.setOnCompletionListener { handler.postDelayed({ playNext() }, 1500) }
        volume = 0f
        mp.setVolume(0f, 0f)
        mp.start()
        player = mp
        fadeTo(TARGET)
    }

    private val fadeStep = object : Runnable {
        var target = 0f
        override fun run() {
            val mp = player ?: return
            volume += if (target > volume) 0.02f else -0.02f
            if ((target >= volume && target - volume < 0.02f) || (target < volume && volume - target < 0.02f)) {
                volume = target
            }
            volume = volume.coerceIn(0f, 1f)
            mp.setVolume(volume, volume)
            if (volume != target) {
                handler.postDelayed(this, 50)
            } else if (target == 0f) {
                release()
            }
        }
    }

    private fun fadeTo(target: Float) {
        handler.removeCallbacks(fadeStep)
        fadeStep.target = target
        handler.post(fadeStep)
    }

    private fun release() {
        handler.removeCallbacksAndMessages(null)
        player?.run {
            try {
                stop()
            } catch (e: IllegalStateException) {
            }
            release()
        }
        player = null
    }

    companion object {
        private const val TARGET = 0.45f
    }
}
