package ru.domashka.ui

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** 30 мемов из assets/memes. Показываются в случайном порядке без повторов, пока не кончатся. */
object MemeBag {
    fun next(context: Context): String? {
        val all = context.assets.list("memes")?.filter { it.endsWith(".jpg") || it.endsWith(".png") }?.sorted()
            ?: return null
        if (all.isEmpty()) return null
        val prefs = context.getSharedPreferences("memes", Context.MODE_PRIVATE)
        var queue = prefs.getString("queue", "")!!.split(',').filter { it in all }
        if (queue.isEmpty()) {
            val last = prefs.getString("last", null)
            queue = all.shuffled()
            if (queue.first() == last && queue.size > 1) queue = queue.drop(1) + queue.first()
        }
        val pick = queue.first()
        prefs.edit().putString("queue", queue.drop(1).joinToString(",")).putString("last", pick).apply()
        return "memes/$pick"
    }
}

@Composable
fun MemeDialog(path: String, onClose: () -> Unit) {
    val context = LocalContext.current
    val image by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) {
            try {
                context.assets.open(path).use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
            } catch (e: Exception) {
                null
            }
        }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.8f)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("🎁 Мем за домашку", color = Brand.Gold, style = androidx.compose.material3.MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(12.dp))
                image?.let {
                    Image(
                        it,
                        contentDescription = "Мем",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(20.dp))
                    )
                }
                Spacer(Modifier.height(16.dp))
                GradientButton(onClick = onClose, brush = Brand.Main, modifier = Modifier.fillMaxWidth()) {
                    Text("😂 Огонь!", style = buttonTextStyle(), color = Color.White)
                }
            }
        }
    }
}
