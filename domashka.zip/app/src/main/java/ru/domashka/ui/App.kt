package ru.domashka.ui

import android.content.Context
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import java.io.File
import ru.domashka.data.isRunning

@Composable
fun App(vm: MainViewModel = viewModel()) {
    val ocrState by vm.ocrState.collectAsState()
    val subjects by vm.subjects.collectAsState()

    when (val st = ocrState) {
        is OcrState.Review -> {
            BackHandler { vm.dismissOcr() }
            ReviewScreen(
                drafts = st.drafts,
                preview = st.preview,
                subjects = subjects.map { it.name },
                onChange = vm::updateDraft,
                onRemove = vm::removeDraft,
                onAdd = vm::addManualDraft,
                onSave = vm::saveDrafts,
                onCancel = vm::dismissOcr,
            )
        }
        is OcrState.Crop -> {
            BackHandler { vm.dismissOcr() }
            CropScreen(
                bitmap = st.bitmap,
                onRotate = vm::rotateCrop,
                onCancel = vm::dismissOcr,
                onConfirm = { l, t, r, b -> vm.recognizeCrop(l, t, r, b) },
            )
        }
        else -> MainScreen(vm)
    }

    when (val s = ocrState) {
        OcrState.Opening, OcrState.Processing -> AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            title = { Text(if (s == OcrState.Opening) "Открываю фото…" else "Читаю текст…") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator()
                    Spacer(Modifier.width(16.dp))
                    Text("Это займёт несколько секунд")
                }
            }
        )
        is OcrState.Error -> AlertDialog(
            onDismissRequest = vm::dismissOcr,
            confirmButton = { TextButton(onClick = vm::dismissOcr) { Text("Понятно") } },
            title = { Text("Не получилось") },
            text = { Text(s.message) }
        )
        else -> Unit
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val tasks by vm.tasks.collectAsState()
    val subjects by vm.subjects.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var pendingPhoto by rememberSaveable { mutableStateOf<String?>(null) }

    // Часы для таймеров: тикают раз в секунду, только если какой-то таймер запущен
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val anyRunning = tasks.any { it.isRunning }
    LaunchedEffect(anyRunning) {
        now = System.currentTimeMillis()
        while (anyRunning) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }
    LaunchedEffect(tasks) { now = System.currentTimeMillis() }

    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = pendingPhoto
        if (ok && uri != null) vm.openImage(Uri.parse(uri))
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.openImage(uri)
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(if (tab == 0) "Домашка" else "Сколько времени уходит") })
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.CheckCircle, null) },
                    label = { Text("Задания") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Icon(Icons.Filled.BarChart, null) },
                    label = { Text("Время") }
                )
            }
        }
    ) { padding ->
        if (tab == 0) {
            TasksTab(
                tasks = tasks,
                subjects = subjects,
                now = now,
                modifier = Modifier.padding(padding),
                onCamera = {
                    val uri = newPhotoUri(context)
                    pendingPhoto = uri.toString()
                    takePicture.launch(uri)
                },
                onGallery = {
                    pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onManual = vm::addManualDraft,
                onToggleDone = { vm.toggleDone(it) },
                onToggleTimer = { vm.toggleTimer(it) },
                onResetTimer = { vm.resetTimer(it) },
                onEdit = { id, text, subject -> vm.editTask(id, text, subject) },
                onDelete = { vm.deleteTask(it) },
            )
        } else {
            StatsTab(
                tasks = tasks,
                subjects = subjects,
                now = now,
                modifier = Modifier.padding(padding),
                onRename = { s, name -> vm.renameSubject(s, name) },
                onDelete = { vm.deleteSubject(it) },
            )
        }
    }
}

/** Файл для фото с камеры. Старые снимки удаляем, чтобы не копились. */
private fun newPhotoUri(context: Context): Uri {
    val dir = File(context.cacheDir, "photos").apply { mkdirs() }
    dir.listFiles()?.forEach { it.delete() }
    val file = File(dir, "hw_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

