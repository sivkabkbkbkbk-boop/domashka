package ru.domashka.ui

import android.content.Context
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MusicOff
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.IconButton
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import java.io.File
import ru.domashka.data.isRunning

@Composable
fun App(vm: MainViewModel = viewModel()) {
    val ocrState by vm.ocrState.collectAsState()
    val subjects by vm.subjects.collectAsState()
    val celebration by vm.celebration.collectAsState()
    val appContext = LocalContext.current.applicationContext
    val sounds = remember { Sounds(appContext) }
    remember { PigeonSprites.init(appContext); true }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { PigeonSprites.preload(appContext) }
    }

    when (val st = ocrState) {
        is OcrState.Review -> {
            BackHandler { vm.dismissOcr() }
            ReviewScreen(
                drafts = st.drafts,
                preview = st.preview,
                subjects = subjects.map { it.name },
                onChange = vm::updateDraft,
                onRemove = vm::removeDraft,
                onAdd = vm::addManualDraft,
                onSave = vm::saveDrafts,
                onCancel = vm::dismissOcr,
            )
        }
        is OcrState.Crop -> {
            BackHandler { vm.dismissOcr() }
            CropScreen(
                bitmap = st.bitmap,
                onRotate = vm::rotateCrop,
                onCancel = vm::dismissOcr,
                onConfirm = { l, t, r, b -> vm.recognizeCrop(l, t, r, b) },
            )
        }
        else -> MainScreen(vm, sounds)
    }

    val outfitNow by vm.outfit.collectAsState()
    // после голубя — случайный мем
    var meme by remember { mutableStateOf<String?>(null) }
    celebration?.let {
        CelebrationOverlay(it, sounds, outfitNow) {
            vm.dismissCelebration()
            meme = MemeBag.next(appContext)
        }
    }
    meme?.let { MemeDialog(it) { meme = null } }

    // новые ачивки — баннером сверху, когда не открыт праздник или мем
    val newAch by vm.newAchievements.collectAsState()
    if (celebration == null && meme == null) {
        AchievementBanner(
            a = newAch.firstOrNull(),
            sounds = sounds,
            onDone = vm::dismissAchievement,
            modifier = Modifier.statusBarsPadding()
        )
    }

    when (val s = ocrState) {
        OcrState.Opening, OcrState.Processing -> AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            title = { Text(if (s == OcrState.Opening) "Открываю фото…" else "Читаю текст…") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator()
                    Spacer(Modifier.width(16.dp))
                    Text("Это займёт несколько секунд")
                }
            }
        )
        is OcrState.Error -> AlertDialog(
            onDismissRequest = vm::dismissOcr,
            confirmButton = { TextButton(onClick = vm::dismissOcr) { Text("Понятно") } },
            title = { Text("Не получилось") },
            text = { Text(s.message) }
        )
        else -> Unit
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScreen(vm: MainViewModel, sounds: Sounds) {
    val context = LocalContext.current
    val tasks by vm.tasks.collectAsState()
    val subjects by vm.subjects.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var countdownFor by remember { mutableStateOf<Long?>(null) }
    var soundOn by remember { mutableStateOf(sounds.enabled) }
    val achStats by vm.achStats.collectAsState()
    val achUnlocked by vm.achUnlocked.collectAsState()
    val outfit by vm.outfit.collectAsState()
    var pendingPhoto by rememberSaveable { mutableStateOf<String?>(null) }

    // Часы для таймеров: тикают раз в секунду, только если какой-то таймер запущен
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val anyRunning = tasks.any { it.isRunning }
    LaunchedEffect(anyRunning) {
        now = System.currentTimeMillis()
        while (anyRunning) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }
    LaunchedEffect(tasks) { now = System.currentTimeMillis() }

    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = pendingPhoto
        if (ok && uri != null) vm.openImage(Uri.parse(uri))
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.openImage(uri)
    }

    val todayStart = remember(now / 3_600_000) {
        java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
    }
    val doneToday = tasks.count { it.done && (it.doneAt ?: 0) >= todayStart }
    val openCount = tasks.count { !it.done }

    Scaffold(
        containerColor = Brand.Bg,
        topBar = {
            HomeHeader(
                title = when (tab) { 0 -> "ДОМАШКА"; 1 -> "АЧИВКИ"; else -> "СТАТИСТИКА" },
                done = doneToday,
                total = doneToday + openCount,
                soundOn = soundOn,
                onSound = {
                    soundOn = !soundOn
                    sounds.enabled = soundOn
                },
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Brand.Surface) {
                val itemColors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.White,
                    selectedTextColor = Brand.Text,
                    indicatorColor = Brand.Violet,
                    unselectedIconColor = Brand.Muted,
                    unselectedTextColor = Brand.Muted,
                )
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.CheckCircle, null) },
                    label = { Text("Задания") },
                    colors = itemColors
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Text("🏆", fontSize = 22.sp) },
                    label = { Text("Ачивки") },
                    colors = itemColors
                )
                NavigationBarItem(
                    selected = tab == 2,
                    onClick = { tab = 2 },
                    icon = { Icon(Icons.Filled.BarChart, null) },
                    label = { Text("Время") },
                    colors = itemColors
                )
            }
        }
    ) { padding ->
      Box(
        Modifier
            .padding(padding)
            .fillMaxSize()
      ) {
        if (tab == 0) {
            TasksTab(
                tasks = tasks,
                subjects = subjects,
                now = now,
                modifier = Modifier,
                onCamera = {
                    val uri = newPhotoUri(context)
                    pendingPhoto = uri.toString()
                    takePicture.launch(uri)
                },
                onGallery = {
                    pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onManual = { vm.addManualDraft() },
                onUndo = { vm.toggleDone(it) },
                onStart = { countdownFor = it },
                onStop = { vm.stopTimer(it) },
                onFinish = { vm.finishTask(it) },
                onEdit = { id, text, subject -> vm.editTask(id, text, subject) },
                onDelete = { vm.deleteTask(it) },
            )
        } else if (tab == 1) {
            AchievementsTab(
                stats = achStats,
                unlocked = achUnlocked,
                outfit = outfit,
                onToggle = { vm.toggleItem(it) },
            )
        } else {
            StatsTab(
                tasks = tasks,
                subjects = subjects,
                now = now,
                modifier = Modifier,
                onRename = { s, name -> vm.renameSubject(s, name) },
                onDelete = { vm.deleteSubject(it) },
            )
        }
        // голубь гуляет по низу экрана
        WanderingPigeon(
            sounds = sounds,
            calm = anyRunning,
            outfit = outfit,
            onAction = { vm.onPet(it) },
        )
        // обратный отсчёт 3-2-1 «Начали!» перед стартом таймера
        countdownFor?.let { id ->
            CountdownOverlay(sounds = sounds) {
                vm.startTimer(id)
                countdownFor = null
            }
        }
      }
    }
}

/** Шапка: название, дата, прогресс дня и переключатели звука. */
@Composable
private fun HomeHeader(
    title: String,
    done: Int,
    total: Int,
    soundOn: Boolean,
    onSound: () -> Unit,
) {
    val date = remember {
        java.time.LocalDate.now()
            .format(java.time.format.DateTimeFormatter.ofPattern("EEEE, d MMMM", java.util.Locale("ru")))
            .replaceFirstChar { it.uppercase() }
    }
    Column(
        Modifier
            .fillMaxWidth()
            .background(Brand.Header)
            .statusBarsPadding()
            .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.headlineMedium, color = Color.White)
                Text(date, color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = onSound) {
                Icon(
                    if (soundOn) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                    if (soundOn) "Выключить звук" else "Включить звук",
                    tint = Color.White
                )
            }
        }
        if (total > 0) {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.padding(end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (done >= total) "Всё на сегодня сделано! 🔥" else "Сегодня сделано: $done из $total",
                    color = Color.White,
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(6.dp))
            Box(Modifier.padding(end = 12.dp)) { NeonProgress(done.toFloat() / total) }
        }
    }
}

/** Файл для фото с камеры. Старые снимки удаляем, чтобы не копились. */
private fun newPhotoUri(context: Context): Uri {
    val dir = File(context.cacheDir, "photos").apply { mkdirs() }
    dir.listFiles()?.forEach { it.delete() }
    val file = File(dir, "hw_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

