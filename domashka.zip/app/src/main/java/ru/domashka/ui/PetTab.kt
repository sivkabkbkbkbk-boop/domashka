package ru.domashka.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** Что можно сделать с голубем. */
enum class PetAction(val emoji: String, val label: String, val durationMs: Int, val phrase: String) {
    SEED("🌻", "Семечко", 2600, "Ням-ням! Вкуснота 🌻"),
    PET("✋", "Погладить", 2600, "Курлык… как приятно 🥰"),
    WATER("💧", "Попить", 2600, "Буль-буль. Освежился 💧"),
    DANCE("🕺", "Танцы", 3000, "Туц-туц-туц! 🎶"),
    BATH("🛁", "Искупать", 2800, "Плюх! Я чистый и блестящий ✨"),
    TICKLE("🪶", "Щекотка", 2200, "Ха-ха-ха! Щекотно! 😂"),
    SLEEP("😴", "Спать", 3600, "Хр-р-р… курлы… 😴"),
    HIGH_FIVE("🙌", "Дай пять", 1800, "Йе! Пять! 🙌"),
}

@Composable
fun PetTab(sounds: Sounds, modifier: Modifier = Modifier) {
    var action by remember { mutableStateOf<PetAction?>(null) }
    var runId by remember { mutableIntStateOf(0) }
    var phrase by remember { mutableStateOf("Привет! Покорми меня или погладь 😎") }
    val progress = remember { Animatable(0f) }

    fun start(a: PetAction) {
        action = a
        phrase = a.phrase
        runId++
    }

    // проигрываем анимацию и звуки действия
    LaunchedEffect(runId) {
        val a = action ?: return@LaunchedEffect
        progress.snapTo(0f)
        val cues = when (a) {
            PetAction.SEED -> listOf(0.33f to { sounds.peck() }, 0.53f to { sounds.peck() }, 0.73f to { sounds.peck() }, 0.9f to { sounds.coo() })
            PetAction.PET -> listOf(0.05f to { sounds.purr() }, 0.6f to { sounds.purr() })
            PetAction.WATER -> listOf(0.35f to { sounds.gulp() }, 0.65f to { sounds.gulp() })
            PetAction.DANCE -> listOf(0.0f to { sounds.beat() })
            PetAction.BATH -> listOf(0.0f to { sounds.splash() }, 0.6f to { sounds.splash() })
            PetAction.TICKLE -> listOf(0.1f to { sounds.giggle() }, 0.55f to { sounds.giggle() })
            PetAction.SLEEP -> listOf(0.05f to { sounds.lullaby() })
            PetAction.HIGH_FIVE -> listOf(0.33f to { sounds.clap() }, 0.6f to { sounds.coo() })
        }
        var next = 0
        val steps = a.durationMs / 16
        for (i in 0..steps) {
            val t = i.toFloat() / steps
            while (next < cues.size && cues[next].first <= t) {
                cues[next].second()
                next++
            }
            progress.snapTo(t)
            kotlinx.coroutines.delay(16)
        }
        action = null
    }

    val idle = rememberInfiniteTransition(label = "idle")
    val breathe by idle.animateFloat(0f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "breathe")
    val measurer = rememberTextMeasurer()

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // облачко с репликой
        Text(
            phrase,
            color = Brand.Text,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier
                .clip(RoundedCornerShape(18.dp))
                .background(Brand.Surface2)
                .padding(horizontal = 18.dp, vertical = 10.dp)
        )
        Spacer(Modifier.height(8.dp))
        Canvas(
            Modifier
                .widthIn(max = 380.dp)
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(28.dp))
                .background(Brand.Surface)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { start(PetAction.entries.random()) }
        ) {
            val u = size.minDimension / 100f
            val scene = Scene(this, u)
            val t = progress.value
            val a = action
            scene.floor()

            // поза голубя
            var tilt = 0f
            var wing = 0f
            var beak = 0f
            var eyesClosed = false
            var glasses = true
            var hop = 0f
            var shake = 0f
            when (a) {
                null -> {
                    wing = breathe * 4f
                    hop = 0f
                }
                PetAction.SEED -> {
                    for (k in 0 until 3) {
                        val c = 0.33f + 0.2f * k
                        val local = ((t - (c - 0.08f)) / 0.16f).coerceIn(0f, 1f)
                        tilt = maxOf(tilt, 58f * sin(local * PI.toFloat()))
                    }
                    if (t > 0.88f) { hop = abs(sin((t - 0.88f) / 0.12f * PI.toFloat())) * 5f; beak = 3f }
                }
                PetAction.PET -> { glasses = false; eyesClosed = true; tilt = -4f + 3f * sin(t * 12f); wing = 6f }
                PetAction.WATER -> {
                    for (c in listOf(0.35f, 0.65f)) {
                        val local = ((t - (c - 0.1f)) / 0.2f).coerceIn(0f, 1f)
                        tilt = maxOf(tilt, 50f * sin(local * PI.toFloat()))
                    }
                }
                PetAction.DANCE -> {
                    hop = abs(sin(t * PI.toFloat() * 12f)) * 7f
                    tilt = sin(t * PI.toFloat() * 6f) * 10f
                    wing = 15f + 25f * abs(sin(t * PI.toFloat() * 12f))
                    beak = 2f * abs(sin(t * 30f))
                }
                PetAction.BATH -> {
                    if (t > 0.55f) shake = sin(t * 90f) * 2.5f
                    wing = if (t > 0.55f) 20f * abs(sin(t * 60f)) else 5f
                }
                PetAction.TICKLE -> {
                    tilt = sin(t * 70f) * 7f
                    beak = 3f + 2f * sin(t * 50f)
                    wing = 10f + 10f * abs(sin(t * 40f))
                    glasses = t < 0.15f
                    eyesClosed = !glasses
                }
                PetAction.SLEEP -> { glasses = false; eyesClosed = true; tilt = 6f + 2f * sin(t * 8f); wing = 0f }
                PetAction.HIGH_FIVE -> {
                    wing = 75f * (t / 0.3f).coerceIn(0f, 1f) * (if (t > 0.8f) (1f - (t - 0.8f) / 0.2f) else 1f)
                    beak = if (t in 0.3f..0.7f) 3f else 0f
                }
            }

            // сам голубь: масштаб 0.85, чуть левее — справа место для семечек и миски
            val pig = MascotPainter(this, u * 0.85f, (-12f + shake) * u, (8f - hop) * u)
            if (a == PetAction.SLEEP) drawRect(Color(0xFF05060F).copy(alpha = 0.35f), Offset.Zero, size)
            pig.pigeon(wingAngle = wing, beakOpen = beak, chain = false, tilt = tilt, eyesClosed = eyesClosed, glasses = glasses)

            // реквизит
            when (a) {
                PetAction.SEED -> scene.seeds(t)
                PetAction.PET -> {
                    scene.emoji(measurer, "✋", 30f + 25f * (0.5f + 0.5f * sin(t * 12f)), 20f, 30f)
                    scene.floating(measurer, "❤️", t, 55f, 22f)
                }
                PetAction.WATER -> scene.bowl()
                PetAction.DANCE -> scene.floating(measurer, "🎵", t, 70f, 18f, count = 4)
                PetAction.BATH -> scene.bubbles(t)
                PetAction.TICKLE -> scene.emoji(measurer, "🪶", 40f + 6f * sin(t * 40f), 62f + 3f * sin(t * 55f), 26f)
                PetAction.SLEEP -> scene.floating(measurer, "💤", t, 62f, 16f, count = 3)
                PetAction.HIGH_FIVE -> { if (t in 0.3f..0.75f) scene.burst(t) }
                null -> Unit
            }
        }
        Spacer(Modifier.height(14.dp))
        // кнопки действий: 2 ряда по 4
        PetAction.entries.chunked(4).forEach { rowActions ->
            Row(
                Modifier
                    .widthIn(max = 420.dp)
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                rowActions.forEach { pa ->
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (action == pa) Brand.Violet else Brand.Surface2)
                            .clickable { start(pa) }
                            .padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(pa.emoji, fontSize = 26.sp)
                        Text(pa.label, color = Brand.Text, fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}

/** Рисование реквизита в координатах сцены 0..100. */
private class Scene(val s: DrawScope, val u: Float) {
    fun p(x: Float, y: Float) = Offset(x * u, y * u)

    fun floor() {
        s.drawRect(Color(0xFF232651), p(0f, 86f), Size(100f * u, 14f * u))
    }

    fun emoji(m: androidx.compose.ui.text.TextMeasurer, e: String, x: Float, y: Float, sizeUnits: Float) {
        s.drawText(m, e, topLeft = p(x, y), style = TextStyle(fontSize = (sizeUnits * u / s.density / s.fontScale).sp))
    }

    /** Эмодзи, всплывающие вверх и тающие. */
    fun floating(m: androidx.compose.ui.text.TextMeasurer, e: String, t: Float, x: Float, y: Float, count: Int = 3) {
        for (k in 0 until count) {
            val local = ((t * 1.2f - k * 0.22f)).coerceIn(0f, 1f)
            if (local <= 0f || local >= 1f) continue
            val xx = x + k * 7f + sin(local * 8f + k) * 3f
            val yy = y - local * 18f
            s.drawText(
                m, e, topLeft = p(xx, yy),
                style = TextStyle(
                    fontSize = (9f * u / s.density / s.fontScale).sp,
                    color = Color.White.copy(alpha = 1f - local)
                )
            )
        }
    }

    fun seeds(t: Float) {
        val xs = listOf(72f, 77f, 82f)
        xs.forEachIndexed { k, x ->
            val eatenAt = 0.36f + 0.2f * k
            if (t > eatenAt) return@forEachIndexed
            val fall = (t / 0.22f).coerceIn(0f, 1f)
            val y = 10f + (84f - 10f) * fall * fall
            s.drawOval(Color(0xFF3B2F1E), p(x - 1.8f, y - 1.1f), Size(3.6f * u, 2.2f * u))
            s.drawOval(Color(0xFFE8C77A), p(x - 1.2f, y - 0.7f), Size(2.4f * u, 1.2f * u))
        }
    }

    fun bowl() {
        s.drawArc(Color(0xFF60A5FA), 0f, 180f, true, p(70f, 80f), Size(20f * u, 10f * u))
        s.drawOval(Color(0xFF93C5FD), p(70f, 83f), Size(20f * u, 3f * u))
    }

    fun bubbles(t: Float) {
        for (k in 0 until 9) {
            val local = ((t * 1.3f - k * 0.08f)).coerceIn(0f, 1f)
            if (local <= 0f || local >= 1f) continue
            val x = 20f + (k * 9f) % 60f + sin(local * 6f + k) * 3f
            val y = 80f - local * 60f
            s.drawCircle(Color(0xFFBAE6FD).copy(alpha = 0.8f * (1f - local)), (2f + k % 3) * u, p(x, y), style = Stroke(0.6f * u))
        }
        if (t > 0.6f) { // брызги при отряхивании
            for (k in 0 until 8) {
                val local = ((t - 0.6f) / 0.4f).coerceIn(0f, 1f)
                val ang = k / 8f * 2f * PI.toFloat()
                val x = 45f + kotlin.math.cos(ang) * (18f + local * 22f)
                val y = 50f + sin(ang) * (14f + local * 18f)
                s.drawCircle(Color(0xFF7DD3FC).copy(alpha = 1f - local), 1.2f * u, p(x, y))
            }
        }
    }

    fun burst(t: Float) {
        val local = ((t - 0.3f) / 0.45f).coerceIn(0f, 1f)
        val cx = 30f
        val cy = 22f
        for (k in 0 until 10) {
            val ang = k / 10f * 2f * PI.toFloat()
            val r1 = 3f + local * 8f
            val r2 = r1 + 5f
            s.drawLine(
                Brand.Gold.copy(alpha = 1f - local),
                p(cx + kotlin.math.cos(ang) * r1, cy + sin(ang) * r1),
                p(cx + kotlin.math.cos(ang) * r2, cy + sin(ang) * r2),
                1.4f * u, StrokeCap.Round
            )
        }
    }
}
