package ru.domashka.ui

import java.util.Locale

fun formatClock(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}

fun formatHuman(ms: Long): String {
    if (ms < 60_000) return "${ms / 1000} сек"
    val totalMin = ms / 60_000
    val h = totalMin / 60
    val m = totalMin % 60
    return if (h == 0L) "$m мин" else "$h ч $m мин"
}

fun tasksWord(n: Int): String {
    val n10 = n % 10
    val n100 = n % 100
    val word = when {
        n100 in 11..14 -> "заданий"
        n10 == 1 -> "задание"
        n10 in 2..4 -> "задания"
        else -> "заданий"
    }
    return "$n $word"
}
