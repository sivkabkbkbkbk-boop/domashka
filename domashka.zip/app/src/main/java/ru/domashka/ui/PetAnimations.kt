package ru.domashka.ui

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.unit.sp
import ru.domashka.data.Outfit
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Что умеет голубь. На каждое — несколько фраз, выбирается случайная. */
enum class PetAction(val emoji: String, val label: String, val durationMs: Int, val phrases: List<String>) {
    SEED("🌻", "Семечко", 2600, listOf("Ням-ням! Вкуснота 🌻", "Семечки — топ!", "Ещё одну? Ну пожалуйста!")),
    PET("✋", "Погладить", 2600, listOf("Курлык… как приятно 🥰", "Ещё! Ещё!", "Я таю…")),
    WATER("💧", "Попить", 2600, listOf("Буль-буль. Освежился 💧", "Водичка — жизнь!", "Ах, хорошо!")),
    DANCE("🕺", "Танцы", 3000, listOf("Туц-туц-туц! 🎶", "Смотри, как я умею!", "Дискотека голубей!")),
    BATH("🛁", "Искупать", 2800, listOf("Плюх! Я чистый и блестящий ✨", "Фух, освежился!", "Теперь я самый чистый голубь двора")),
    TICKLE("🪶", "Щекотка", 2200, listOf("Ха-ха-ха! Щекотно! 😂", "Хи-хи, перестань!", "Ай, ха-ха!")),
    SLEEP("😴", "Спать", 3600, listOf("Хр-р-р… курлы… 😴", "Пять минуточек…", "Мне снятся семечки…")),
    HIGH_FIVE("🙌", "Дай пять", 1800, listOf("Йе! Пять! 🙌", "Отбил!", "Команда!")),
    JUMP("🦘", "Прыжок", 1600, listOf("Опа! 🦘", "Выше всех!", "Прыг-скок!")),
    FLY("🕊️", "Полёт", 2600, listOf("Я лечу-у-у! 🕊️", "Вид сверху — огонь!", "Посадка успешная")),
    SING("🎤", "Песня", 2800, listOf("Курлы-курлы-курлы! 🎤", "Я звезда эстрады!", "Ля-ля-курлык!")),
    SNEEZE("🤧", "Апчхи", 2000, listOf("Апчхи! 🤧", "Будь здоров — спасибо!", "Кажется, пёрышко в нос попало")),
    SPIN("🌀", "Волчок", 1800, listOf("Уи-и-и! 🌀", "Голова кружится…", "Крутой разворот!")),
    SHOW_OFF("😎", "Понты", 2400, listOf("Я самый крутой голубь 😎", "Смотрите все!", "Ну как я?")),
    BALL("⚽", "Мячик", 2400, listOf("Гол! ⚽", "Головой — как профи!", "Пас!")),
    READ("📖", "Читать", 3000, listOf("Хм, интересно… 📖", "Голуби тоже учатся!", "Эту книгу я уже клевал")),
    PHOTO("📸", "Селфи", 2200, listOf("Щёлк! Красавчик 📸", "В сторис!", "Ещё дубль?")),
    GIFT("🎁", "Подарок", 2600, listOf("Подарок?! Мне?! 🎁", "Ух ты, что там?", "Спасибо!")),
    RAIN("☔", "Дождик", 3000, listOf("Хорошо, что есть зонтик ☔", "Кап-кап…", "Дождь голубю не помеха")),
    THINK("💭", "Думать", 2600, listOf("Хм… 💭", "Придумал! 💡", "Так-так-так…"));

    val phrase: String get() = phrases.random()
}

/** Действия, которые голубь иногда делает сам, пока гуляет (тихо). */
val AMBIENT_ACTIONS = listOf(PetAction.JUMP, PetAction.THINK, PetAction.READ, PetAction.SHOW_OFF, PetAction.SING, PetAction.SPIN, PetAction.SLEEP)

/** Случайные фразы голубя, пока он гуляет. */
val PIGEON_PHRASES = listOf(
    "Курлык.", "Где тут семечки?", "Я вообще-то голубь, а не воробей.", "Домашка сама себя не сделает…",
    "Ты молодец, кстати.", "Хлеб — это жизнь.", "Кто-нибудь видел мои крошки?", "Я бы помог с математикой, но у меня лапки.",
    "Голуби летают до 80 км/ч!", "Голуби узнают людей в лицо. Тебя — точно.", "Голуби находят дорогу домой за сотни километров.",
    "Шаг, шаг, клюю. Шаг, шаг, клюю.", "Сегодня отличный день для пятёрки.", "Главное — начать.",
    "А ты знал, что голуби видят ультрафиолет?", "Иду по делам. Голубиным.", "Курлы-курлы, я крутой.",
    "Скучно… Может, погнали домашку?", "Эй! Потыкай в меня!", "Я тут просто гуляю.", "Хочу пиццу 🍕", "Ням?",
    "Кажется, я что-то уронил.", "Голуби — самые умные птицы. Ну, почти.", "Пять минут — и готово!",
    "Отдыхать тоже надо.", "Тсс… я охочусь на крошку.", "Чик-чирик. Шучу, курлык.", "Хочу новую шляпу. Открой ачивку!",
    "Кто самый крутой голубь? Я.", "Пойду поклюю.", "Хм…", "Уф, устал ходить.", "Голуби живут рядом с людьми уже 5000 лет!",
    "Я слежу за порядком 👀", "Мне нравится твой телефон.", "Ачивки сами себя не соберут!", "Курлык-курлык, как дела?",
    "Голуби умеют считать до… много!", "Если что — я тут.",
)

/** Подбадривания, пока идёт домашка (без звука). */
val CALM_PHRASES = listOf("Давай-давай!", "Я в тебя верю 💪", "Не отвлекайся 😉", "Ещё чуть-чуть!", "Ты справишься!", "Тихо… человек работает")

/** Звуки по ходу действия: (момент 0..1, звук). */
fun petCues(a: PetAction, sounds: Sounds): List<Pair<Float, () -> Unit>> = when (a) {
    PetAction.SEED -> listOf(0.33f to { sounds.peck() }, 0.53f to { sounds.peck() }, 0.73f to { sounds.peck() }, 0.9f to { sounds.coo() })
    PetAction.PET -> listOf(0.05f to { sounds.purr() }, 0.6f to { sounds.purr() })
    PetAction.WATER -> listOf(0.35f to { sounds.gulp() }, 0.65f to { sounds.gulp() })
    PetAction.DANCE -> listOf(0.0f to { sounds.beat() })
    PetAction.BATH -> listOf(0.0f to { sounds.splash() }, 0.6f to { sounds.splash() })
    PetAction.TICKLE -> listOf(0.1f to { sounds.giggle() }, 0.55f to { sounds.giggle() })
    PetAction.SLEEP -> listOf(0.05f to { sounds.lullaby() })
    PetAction.HIGH_FIVE -> listOf(0.33f to { sounds.clap() }, 0.6f to { sounds.coo() })
    PetAction.JUMP -> listOf(0.05f to { sounds.boing() })
    PetAction.FLY -> listOf(0.05f to { sounds.whistle() }, 0.85f to { sounds.peck() })
    PetAction.SING -> listOf(0.05f to { sounds.coo() }, 0.38f to { sounds.coo() }, 0.7f to { sounds.coo() })
    PetAction.SNEEZE -> listOf(0.45f to { sounds.boing() })
    PetAction.SPIN -> listOf(0.0f to { sounds.whistle() })
    PetAction.SHOW_OFF -> listOf(0.1f to { sounds.fanfare() })
    PetAction.BALL -> listOf(0.48f to { sounds.boing() })
    PetAction.READ -> listOf(0.3f to { sounds.peck() }, 0.65f to { sounds.peck() }, 0.85f to { sounds.achievement() })
    PetAction.PHOTO -> listOf(0.5f to { sounds.clap() })
    PetAction.GIFT -> listOf(0.5f to { sounds.achievement() }, 0.7f to { sounds.coo() })
    PetAction.RAIN -> listOf(0.1f to { sounds.splash() })
    PetAction.THINK -> listOf(0.62f to { sounds.achievement() })
}

/** Клевок по времени: 0 — стоит, дальше наклон и обратно. */
private fun peckPose(local: Float): String = when {
    local <= 0f || local >= 1f -> "idle"
    local < 0.25f || local > 0.75f -> "peck1"
    else -> "peck2"
}

private fun flapFrame(phase: Float): Int = when (((phase * 4).toInt() % 4 + 4) % 4) {
    0 -> 0; 1 -> 30; 2 -> 60; else -> 30
}

/**
 * Голубь 16-бит с действием. t — прогресс действия, step — шаг при ходьбе (-1..1), peck — клевок в покое (0..1).
 */
fun DrawScope.drawPigeonScene(
    measurer: TextMeasurer,
    a: PetAction?,
    t: Float,
    breathe: Float,
    step: Float = 0f,
    peck: Float = 0f,
    outfit: Outfit = Outfit(),
) {
    var pose = "idle"
    var eyes = "open"
    var flap = 0
    var legs = 0
    var dx = 0f
    var dy = 0f
    var glasses = true
    when (a) {
        null -> {
            pose = when {
                peck < 0.3f -> "idle"
                peck < 0.7f -> "peck1"
                else -> "peck2"
            }
            legs = when {
                step > 0.35f -> 1
                step < -0.35f -> -1
                else -> 0
            }
            dy = -abs(step) * 1.2f
        }
        PetAction.SEED -> {
            for (c in listOf(0.33f, 0.53f, 0.73f)) {
                val local = (t - (c - 0.08f)) / 0.16f
                val p = peckPose(local)
                if (p != "idle") pose = p
            }
            if (t > 0.88f) { dy = -abs(sin((t - 0.88f) / 0.12f * PI.toFloat())) * 6f; eyes = "talk" }
        }
        PetAction.PET -> { eyes = "closed"; glasses = false; dy = sin(t * 14f) * 0.8f }
        PetAction.WATER -> {
            for (c in listOf(0.35f, 0.65f)) {
                val p = peckPose((t - (c - 0.1f)) / 0.2f)
                if (p != "idle") pose = p
            }
        }
        PetAction.DANCE -> {
            dy = -abs(sin(t * PI.toFloat() * 12f)) * 8f
            dx = sin(t * PI.toFloat() * 6f) * 4f
            flap = flapFrame(t * 12f)
            eyes = if (((t * 16).toInt()) % 2 == 0) "talk" else "open"
            legs = if (((t * 12).toInt()) % 2 == 0) 1 else -1
        }
        PetAction.BATH -> {
            if (t > 0.55f) { dx = sin(t * 90f) * 2.5f; flap = flapFrame(t * 20f) }
        }
        PetAction.TICKLE -> {
            dx = sin(t * 70f) * 2f
            flap = 30
            eyes = if (((t * 14).toInt()) % 2 == 0) "talk" else "closed"
            glasses = t < 0.15f
        }
        PetAction.SLEEP -> { eyes = "closed"; glasses = false; dy = sin(t * 8f) * 0.8f }
        PetAction.HIGH_FIVE -> {
            flap = if (t in 0.12f..0.8f) 60 else 30
            eyes = if (t in 0.3f..0.7f) "talk" else "open"
        }
        PetAction.JUMP -> {
            dy = -sin((t.coerceIn(0.1f, 0.8f) - 0.1f) / 0.7f * PI.toFloat()) * 30f
            flap = if (dy < -5f) 30 else 0
        }
        PetAction.FLY -> {
            dy = -sin(t * PI.toFloat()) * 60f
            flap = if (t in 0.08f..0.9f) flapFrame(t * 24f) else 0
            dx = sin(t * PI.toFloat() * 2f) * 8f
        }
        PetAction.SING -> {
            eyes = if (((t * 10).toInt()) % 2 == 0) "talk" else "closed"
            glasses = eyes != "closed"
            flap = if (t > 0.6f) 30 else 0
        }
        PetAction.SNEEZE -> {
            when {
                t < 0.4f -> { eyes = "closed"; glasses = false; dy = -t * 3f }
                t < 0.55f -> { eyes = "talk"; dx = -6f; flap = 30 }
                else -> { dx = sin(t * 50f) * 1.5f }
            }
        }
        PetAction.SPIN -> { flap = 30; dy = -abs(sin(t * PI.toFloat() * 2f)) * 4f }
        PetAction.SHOW_OFF -> { flap = 60; eyes = if (t > 0.5f) "talk" else "open" }
        PetAction.BALL -> {
            if (t in 0.4f..0.56f) pose = if (t < 0.48f) "peck1" else "idle"
            if (t > 0.5f && t < 0.7f) eyes = "talk"
        }
        PetAction.READ -> { pose = if (t < 0.8f) "peck1" else "idle"; if (t >= 0.8f) eyes = "talk" }
        PetAction.PHOTO -> { eyes = if (t in 0.45f..0.8f) "talk" else "open"; flap = if (t in 0.45f..0.8f) 60 else 0 }
        PetAction.GIFT -> { if (t > 0.5f) { dy = -abs(sin((t - 0.5f) * 20f)) * 4f; eyes = "talk"; flap = 30 } }
        PetAction.RAIN -> { flap = 0; dy = sin(t * 30f) * 0.5f }
        PetAction.THINK -> {
            if (t < 0.6f) { eyes = "closed"; glasses = false } else { eyes = "talk"; flap = 30 }
        }
    }
    val sx = when (a) {
        PetAction.SPIN -> kotlin.math.cos(t * PI.toFloat() * 4f)
        PetAction.SHOW_OFF -> 1f + 0.14f * sin(t * PI.toFloat())
        else -> 1f
    }
    val sy = if (a == PetAction.SHOW_OFF) 1f + 0.14f * sin(t * PI.toFloat()) else 1f
    var frame: SpriteFrame? = null
    withTransform({
        scale(if (abs(sx) < 0.08f) 0.08f else sx, sy, pivot = Offset(size.width / 2f, size.height))
    }) {
        frame = drawPigeonSprite(outfit, SpritePose(pose, eyes, flap, legs), glasses = glasses, dx = dx, dy = dy)
    }
    val fr = frame ?: return
    val scene = Scene(this, fr)
    when (a) {
        PetAction.SEED -> scene.seeds(t)
        PetAction.PET -> {
            scene.emoji(measurer, "✋", 40f + 18f * (0.5f + 0.5f * sin(t * 12f)), -14f, 22f)
            scene.floating(measurer, "❤️", t, 56f, -2f)
        }
        PetAction.WATER -> scene.bowl()
        PetAction.DANCE -> scene.floating(measurer, "🎵", t, 72f, -6f, count = 4)
        PetAction.BATH -> scene.bubbles(t)
        PetAction.TICKLE -> scene.emoji(measurer, "🪶", 62f + 5f * sin(t * 40f), 58f + 3f * sin(t * 55f), 18f)
        PetAction.SLEEP -> scene.floating(measurer, "💤", t, 64f, -8f, count = 3)
        PetAction.HIGH_FIVE -> { if (t in 0.3f..0.75f) scene.burst(t) }
        PetAction.JUMP -> { if (t > 0.78f) scene.dust(((t - 0.78f) / 0.22f)) }
        PetAction.FLY -> { if (t > 0.88f) scene.dust(((t - 0.88f) / 0.12f)) }
        PetAction.SING -> scene.floating(measurer, "🎶", t, 70f, -8f, count = 4)
        PetAction.SNEEZE -> { if (t in 0.4f..0.8f) scene.emoji(measurer, "💥", 92f, 0f, 16f) }
        PetAction.SPIN -> scene.floating(measurer, "💫", t, 40f, -10f, count = 3)
        PetAction.SHOW_OFF -> { scene.floating(measurer, "✨", t, 20f, 10f, count = 3); scene.floating(measurer, "✨", t, 80f, 0f, count = 2) }
        PetAction.BALL -> scene.ball(measurer, t)
        PetAction.READ -> { scene.emoji(measurer, "📖", 84f, 34f, 20f); if (t > 0.8f) scene.emoji(measurer, "💡", 60f, -24f, 16f) }
        PetAction.PHOTO -> { scene.emoji(measurer, "📸", -6f, 30f, 20f); if (t in 0.48f..0.56f) scene.flash() }
        PetAction.GIFT -> scene.gift(measurer, t)
        PetAction.RAIN -> { scene.emoji(measurer, "☂️", 34f, -30f, 30f); scene.rain(t) }
        PetAction.THINK -> scene.emoji(measurer, if (t < 0.6f) "💭" else "💡", 66f, -26f, 18f)
        null -> Unit
    }
}

/** Реквизит в координатах рисунка голубя (x −8…110, y −20…100). */
private class Scene(val s: DrawScope, val f: SpriteFrame) {
    fun p(x: Float, y: Float) = f.map(x, y)
    private fun sp(units: Float) = (units * f.unit / s.density / s.fontScale).sp

    fun emoji(m: TextMeasurer, e: String, x: Float, y: Float, sizeUnits: Float) {
        s.drawText(m, e, topLeft = p(x, y), style = TextStyle(fontSize = sp(sizeUnits)))
    }

    fun floating(m: TextMeasurer, e: String, t: Float, x: Float, y: Float, count: Int = 3) {
        for (k in 0 until count) {
            val local = (t * 1.2f - k * 0.22f).coerceIn(0f, 1f)
            if (local <= 0f || local >= 1f) continue
            s.drawText(
                m, e, topLeft = p(x + k * 8f + sin(local * 8f + k) * 3f, y - local * 20f),
                style = TextStyle(fontSize = sp(11f), color = Color.White.copy(alpha = 1f - local))
            )
        }
    }

    /** Пиксельный квадратик — реквизит в том же 16-бит стиле. */
    private fun px(x: Float, y: Float, w: Float, h: Float, c: Color) {
        val a = p(x, y); val b = p(x + w, y + h)
        s.drawRect(c, a, Size(b.x - a.x, b.y - a.y))
    }

    fun seeds(t: Float) {
        listOf(82f, 86f, 90f).forEachIndexed { k, x ->
            if (t > 0.36f + 0.2f * k) return@forEachIndexed
            val fall = (t / 0.22f).coerceIn(0f, 1f)
            val y = 30f + (88f - 30f) * fall * fall
            px(x - 1.6f, y - 1f, 3.2f, 2f, Color(0xFF3B2F1E))
            px(x - 1f, y - 0.6f, 1.8f, 1.1f, Color(0xFFE8C77A))
        }
    }

    fun bowl() {
        px(74f, 86f, 26f, 6f, Color(0xFF1E3A8A))
        px(76f, 84f, 22f, 3f, Color(0xFF60A5FA))
        px(78f, 84f, 8f, 1.2f, Color(0xFFBFDBFE))
    }

    fun bubbles(t: Float) {
        for (k in 0 until 9) {
            val local = (t * 1.3f - k * 0.08f).coerceIn(0f, 1f)
            if (local <= 0f || local >= 1f) continue
            val c = p(24f + (k * 11f) % 64f + sin(local * 6f + k) * 3f, 88f - local * 70f)
            s.drawCircle(Color(0xFFBAE6FD).copy(alpha = 0.85f * (1f - local)), (2f + k % 3) * f.unit, c, style = Stroke(0.9f * f.unit))
        }
        if (t > 0.6f) {
            val local = ((t - 0.6f) / 0.4f).coerceIn(0f, 1f)
            for (k in 0 until 8) {
                val ang = k / 8f * 2f * PI.toFloat()
                val x = 50f + cos(ang) * (22f + local * 26f)
                val y = 50f + sin(ang) * (18f + local * 22f)
                px(x - 1f, y - 1f, 2.2f, 2.2f, Color(0xFF7DD3FC).copy(alpha = 1f - local))
            }
        }
    }

    fun dust(local: Float) {
        for (k in 0 until 6) {
            val side = if (k % 2 == 0) -1f else 1f
            val x = 50f + side * (6f + local * 14f + k)
            val y = 90f - local * 6f - (k % 3)
            px(x, y, 2.5f, 2.5f, Color(0xFFD6D3C4).copy(alpha = 1f - local))
        }
    }

    fun ball(m: TextMeasurer, t: Float) {
        val (x, y) = when {
            t < 0.48f -> Pair(-10f + t / 0.48f * 86f, 80f - abs(sin(t * 20f)) * 10f)
            else -> { val l = (t - 0.48f) / 0.52f; Pair(76f + l * 40f, 40f - l * 70f) }
        }
        emoji(m, "⚽", x, y, 14f)
    }

    fun flash() {
        s.drawRect(Color.White.copy(alpha = 0.55f), Offset.Zero, s.size)
    }

    fun gift(m: TextMeasurer, t: Float) {
        if (t < 0.5f) {
            emoji(m, "🎁", 80f, 66f + sin(t * 30f) * 1.5f, 20f)
        } else {
            val l = ((t - 0.5f) / 0.5f).coerceIn(0f, 1f)
            val prize = listOf("🍕", "🎈", "⭐", "🍩", "🏆", "🍪")[((t * 1000).toInt() / 997) % 6]
            emoji(m, prize, 80f, 60f - l * 30f, 20f)
            emoji(m, "✨", 70f, 50f - l * 20f, 12f)
        }
    }

    fun rain(t: Float) {
        for (k in 0 until 14) {
            val x = (k * 9f + 3f) % 100f
            val y = ((t * 3f + k * 0.37f) % 1f) * 110f - 10f
            if (x in 22f..66f && y < 2f) continue   // под зонтиком сухо
            px(x, y, 1f, 4f, Color(0xFF93C5FD).copy(alpha = 0.8f))
        }
    }

    fun burst(t: Float) {
        val local = ((t - 0.3f) / 0.45f).coerceIn(0f, 1f)
        val cx = 14f
        val cy = 20f
        for (k in 0 until 10) {
            val ang = k / 10f * 2f * PI.toFloat()
            val r1 = 4f + local * 10f
            val r2 = r1 + 6f
            s.drawLine(
                Brand.Gold.copy(alpha = 1f - local),
                p(cx + cos(ang) * r1, cy + sin(ang) * r1), p(cx + cos(ang) * r2, cy + sin(ang) * r2),
                1.8f * f.unit, StrokeCap.Square
            )
        }
    }
}
