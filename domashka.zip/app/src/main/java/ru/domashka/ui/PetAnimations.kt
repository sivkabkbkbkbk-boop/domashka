package ru.domashka.ui

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.unit.sp
import ru.domashka.data.Outfit
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Что можно сделать с голубем. */
enum class PetAction(val emoji: String, val label: String, val durationMs: Int, val phrase: String) {
    SEED("🌻", "Семечко", 2600, "Ням-ням! Вкуснота 🌻"),
    PET("✋", "Погладить", 2600, "Курлык… как приятно 🥰"),
    WATER("💧", "Попить", 2600, "Буль-буль. Освежился 💧"),
    DANCE("🕺", "Танцы", 3000, "Туц-туц-туц! 🎶"),
    BATH("🛁", "Искупать", 2800, "Плюх! Я чистый и блестящий ✨"),
    TICKLE("🪶", "Щекотка", 2200, "Ха-ха-ха! Щекотно! 😂"),
    SLEEP("😴", "Спать", 3600, "Хр-р-р… курлы… 😴"),
    HIGH_FIVE("🙌", "Дай пять", 1800, "Йе! Пять! 🙌"),
}

/** Звуки по ходу действия: (момент 0..1, звук). */
fun petCues(a: PetAction, sounds: Sounds): List<Pair<Float, () -> Unit>> = when (a) {
    PetAction.SEED -> listOf(0.33f to { sounds.peck() }, 0.53f to { sounds.peck() }, 0.73f to { sounds.peck() }, 0.9f to { sounds.coo() })
    PetAction.PET -> listOf(0.05f to { sounds.purr() }, 0.6f to { sounds.purr() })
    PetAction.WATER -> listOf(0.35f to { sounds.gulp() }, 0.65f to { sounds.gulp() })
    PetAction.DANCE -> listOf(0.0f to { sounds.beat() })
    PetAction.BATH -> listOf(0.0f to { sounds.splash() }, 0.6f to { sounds.splash() })
    PetAction.TICKLE -> listOf(0.1f to { sounds.giggle() }, 0.55f to { sounds.giggle() })
    PetAction.SLEEP -> listOf(0.05f to { sounds.lullaby() })
    PetAction.HIGH_FIVE -> listOf(0.33f to { sounds.clap() }, 0.6f to { sounds.coo() })
}

/** Клевок по времени: 0 — стоит, дальше наклон и обратно. */
private fun peckPose(local: Float): String = when {
    local <= 0f || local >= 1f -> "idle"
    local < 0.25f || local > 0.75f -> "peck1"
    else -> "peck2"
}

private fun flapFrame(phase: Float): Int = when (((phase * 4).toInt() % 4 + 4) % 4) {
    0 -> 0; 1 -> 30; 2 -> 60; else -> 30
}

/**
 * Голубь 16-бит с действием. t — прогресс действия, step — шаг при ходьбе (-1..1), peck — клевок в покое (0..1).
 */
fun DrawScope.drawPigeonScene(
    measurer: TextMeasurer,
    a: PetAction?,
    t: Float,
    breathe: Float,
    step: Float = 0f,
    peck: Float = 0f,
    outfit: Outfit = Outfit(),
) {
    var pose = "idle"
    var eyes = "open"
    var flap = 0
    var legs = 0
    var dx = 0f
    var dy = 0f
    var glasses = true
    when (a) {
        null -> {
            pose = when {
                peck < 0.3f -> "idle"
                peck < 0.7f -> "peck1"
                else -> "peck2"
            }
            legs = when {
                step > 0.35f -> 1
                step < -0.35f -> -1
                else -> 0
            }
            dy = -abs(step) * 1.2f
        }
        PetAction.SEED -> {
            for (c in listOf(0.33f, 0.53f, 0.73f)) {
                val local = (t - (c - 0.08f)) / 0.16f
                val p = peckPose(local)
                if (p != "idle") pose = p
            }
            if (t > 0.88f) { dy = -abs(sin((t - 0.88f) / 0.12f * PI.toFloat())) * 6f; eyes = "talk" }
        }
        PetAction.PET -> { eyes = "closed"; glasses = false; dy = sin(t * 14f) * 0.8f }
        PetAction.WATER -> {
            for (c in listOf(0.35f, 0.65f)) {
                val p = peckPose((t - (c - 0.1f)) / 0.2f)
                if (p != "idle") pose = p
            }
        }
        PetAction.DANCE -> {
            dy = -abs(sin(t * PI.toFloat() * 12f)) * 8f
            dx = sin(t * PI.toFloat() * 6f) * 4f
            flap = flapFrame(t * 12f)
            eyes = if (((t * 16).toInt()) % 2 == 0) "talk" else "open"
            legs = if (((t * 12).toInt()) % 2 == 0) 1 else -1
        }
        PetAction.BATH -> {
            if (t > 0.55f) { dx = sin(t * 90f) * 2.5f; flap = flapFrame(t * 20f) }
        }
        PetAction.TICKLE -> {
            dx = sin(t * 70f) * 2f
            flap = 30
            eyes = if (((t * 14).toInt()) % 2 == 0) "talk" else "closed"
            glasses = t < 0.15f
        }
        PetAction.SLEEP -> { eyes = "closed"; glasses = false; dy = sin(t * 8f) * 0.8f }
        PetAction.HIGH_FIVE -> {
            flap = if (t in 0.12f..0.8f) 60 else 30
            eyes = if (t in 0.3f..0.7f) "talk" else "open"
        }
    }
    if (a == PetAction.SLEEP) drawRect(Color(0xFF05060F).copy(alpha = 0.3f), Offset.Zero, size)
    val frame = drawPigeonSprite(outfit, SpritePose(pose, eyes, flap, legs), glasses = glasses, dx = dx, dy = dy)
    val scene = Scene(this, frame)
    when (a) {
        PetAction.SEED -> scene.seeds(t)
        PetAction.PET -> {
            scene.emoji(measurer, "✋", 40f + 18f * (0.5f + 0.5f * sin(t * 12f)), -14f, 22f)
            scene.floating(measurer, "❤️", t, 56f, -2f)
        }
        PetAction.WATER -> scene.bowl()
        PetAction.DANCE -> scene.floating(measurer, "🎵", t, 72f, -6f, count = 4)
        PetAction.BATH -> scene.bubbles(t)
        PetAction.TICKLE -> scene.emoji(measurer, "🪶", 62f + 5f * sin(t * 40f), 58f + 3f * sin(t * 55f), 18f)
        PetAction.SLEEP -> scene.floating(measurer, "💤", t, 64f, -8f, count = 3)
        PetAction.HIGH_FIVE -> { if (t in 0.3f..0.75f) scene.burst(t) }
        null -> Unit
    }
}

/** Реквизит в координатах рисунка голубя (x −8…110, y −20…100). */
private class Scene(val s: DrawScope, val f: SpriteFrame) {
    fun p(x: Float, y: Float) = f.map(x, y)
    private fun sp(units: Float) = (units * f.unit / s.density / s.fontScale).sp

    fun emoji(m: TextMeasurer, e: String, x: Float, y: Float, sizeUnits: Float) {
        s.drawText(m, e, topLeft = p(x, y), style = TextStyle(fontSize = sp(sizeUnits)))
    }

    fun floating(m: TextMeasurer, e: String, t: Float, x: Float, y: Float, count: Int = 3) {
        for (k in 0 until count) {
            val local = (t * 1.2f - k * 0.22f).coerceIn(0f, 1f)
            if (local <= 0f || local >= 1f) continue
            s.drawText(
                m, e, topLeft = p(x + k * 8f + sin(local * 8f + k) * 3f, y - local * 20f),
                style = TextStyle(fontSize = sp(11f), color = Color.White.copy(alpha = 1f - local))
            )
        }
    }

    /** Пиксельный квадратик — реквизит в том же 16-бит стиле. */
    private fun px(x: Float, y: Float, w: Float, h: Float, c: Color) {
        val a = p(x, y); val b = p(x + w, y + h)
        s.drawRect(c, a, Size(b.x - a.x, b.y - a.y))
    }

    fun seeds(t: Float) {
        listOf(82f, 86f, 90f).forEachIndexed { k, x ->
            if (t > 0.36f + 0.2f * k) return@forEachIndexed
            val fall = (t / 0.22f).coerceIn(0f, 1f)
            val y = 30f + (88f - 30f) * fall * fall
            px(x - 1.6f, y - 1f, 3.2f, 2f, Color(0xFF3B2F1E))
            px(x - 1f, y - 0.6f, 1.8f, 1.1f, Color(0xFFE8C77A))
        }
    }

    fun bowl() {
        px(74f, 86f, 26f, 6f, Color(0xFF1E3A8A))
        px(76f, 84f, 22f, 3f, Color(0xFF60A5FA))
        px(78f, 84f, 8f, 1.2f, Color(0xFFBFDBFE))
    }

    fun bubbles(t: Float) {
        for (k in 0 until 9) {
            val local = (t * 1.3f - k * 0.08f).coerceIn(0f, 1f)
            if (local <= 0f || local >= 1f) continue
            val c = p(24f + (k * 11f) % 64f + sin(local * 6f + k) * 3f, 88f - local * 70f)
            s.drawCircle(Color(0xFFBAE6FD).copy(alpha = 0.85f * (1f - local)), (2f + k % 3) * f.unit, c, style = Stroke(0.9f * f.unit))
        }
        if (t > 0.6f) {
            val local = ((t - 0.6f) / 0.4f).coerceIn(0f, 1f)
            for (k in 0 until 8) {
                val ang = k / 8f * 2f * PI.toFloat()
                val x = 50f + cos(ang) * (22f + local * 26f)
                val y = 50f + sin(ang) * (18f + local * 22f)
                px(x - 1f, y - 1f, 2.2f, 2.2f, Color(0xFF7DD3FC).copy(alpha = 1f - local))
            }
        }
    }

    fun burst(t: Float) {
        val local = ((t - 0.3f) / 0.45f).coerceIn(0f, 1f)
        val cx = 14f
        val cy = 20f
        for (k in 0 until 10) {
            val ang = k / 10f * 2f * PI.toFloat()
            val r1 = 4f + local * 10f
            val r2 = r1 + 6f
            s.drawLine(
                Brand.Gold.copy(alpha = 1f - local),
                p(cx + cos(ang) * r1, cy + sin(ang) * r1), p(cx + cos(ang) * r2, cy + sin(ang) * r2),
                1.8f * f.unit, StrokeCap.Square
            )
        }
    }
}
