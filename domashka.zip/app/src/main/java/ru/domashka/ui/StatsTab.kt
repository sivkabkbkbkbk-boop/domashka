package ru.domashka.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ru.domashka.data.HomeworkTask
import ru.domashka.data.elapsed
import ru.domashka.data.isRunning
import ru.domashka.data.Subject
import java.util.Calendar

private data class SubjectStat(
    val subject: Subject,
    val totalMs: Long,
    val todayMs: Long,
    val done: Int,
    val total: Int,
    val avgDoneMs: Long,
)

private fun startOfToday(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

@Composable
fun StatsTab(
    tasks: List<HomeworkTask>,
    subjects: List<Subject>,
    now: Long,
    modifier: Modifier,
    onRename: (Subject, String) -> Unit,
    onDelete: (Subject) -> Unit,
) {
    val today = startOfToday()
    val stats = subjects.map { s ->
        val list = tasks.filter { it.subjectId == s.id }
        val doneList = list.filter { it.done && it.spentMs > 0 }
        SubjectStat(
            subject = s,
            totalMs = list.sumOf { it.elapsed(now) },
            // «сегодня» — задания, добавленные или сделанные сегодня
            todayMs = list.filter { it.createdAt >= today || (it.doneAt ?: 0) >= today || it.isRunning }
                .sumOf { it.elapsed(now) },
            done = list.count { it.done },
            total = list.size,
            avgDoneMs = if (doneList.isEmpty()) 0 else doneList.sumOf { it.spentMs } / doneList.size,
        )
    }.sortedByDescending { it.totalMs }
    val maxMs = stats.maxOfOrNull { it.totalMs }?.coerceAtLeast(1) ?: 1
    var editing by remember { mutableStateOf<Subject?>(null) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Row(Modifier.fillMaxWidth().background(Brand.Header).padding(16.dp)) {
                    Summary("Сегодня", formatHuman(stats.sumOf { it.todayMs }), Modifier.weight(1f))
                    Summary("Всего", formatHuman(stats.sumOf { it.totalMs }), Modifier.weight(1f))
                    Summary("Сделано", "${tasks.count { it.done }} из ${tasks.size}", Modifier.weight(1f))
                }
            }
        }
        if (stats.isEmpty()) {
            item { Text("Здесь появится время по каждому предмету, когда начнёшь запускать таймеры.") }
        }
        items(stats, key = { it.subject.id }) { st ->
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Brand.Surface)
            ) {
                Column(Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            subjectEmoji(st.subject.name) + "  " + st.subject.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Text(formatHuman(st.totalMs), style = MaterialTheme.typography.titleMedium)
                        IconButton(onClick = { editing = st.subject }) {
                            Icon(Icons.Filled.Edit, "Изменить предмет")
                        }
                    }
                    Box(
                        Modifier
                            .padding(end = 12.dp)
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(Color.White.copy(alpha = 0.1f))
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(st.totalMs.toFloat() / maxMs)
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(Brand.Main)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        buildString {
                            append("Сделано ${st.done} из ${st.total}")
                            if (st.avgDoneMs > 0) append(" · в среднем ${formatHuman(st.avgDoneMs)} на задание")
                            if (st.todayMs > 0) append(" · сегодня ${formatHuman(st.todayMs)}")
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    editing?.let { s ->
        EditSubjectDialog(
            subject = s,
            onDismiss = { editing = null },
            onRename = { onRename(s, it); editing = null },
            onDelete = { onDelete(s); editing = null },
        )
    }
}

@Composable
private fun Summary(label: String, value: String, modifier: Modifier) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun EditSubjectDialog(
    subject: Subject,
    onDismiss: () -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
) {
    var name by remember(subject.id) { mutableStateOf(subject.name) }
    var askDelete by remember { mutableStateOf(false) }
    if (askDelete) {
        AlertDialog(
            onDismissRequest = { askDelete = false },
            title = { Text("Удалить «${subject.name}»?") },
            text = { Text("Все задания этого предмета тоже удалятся.") },
            confirmButton = { TextButton(onClick = onDelete) { Text("Удалить") } },
            dismissButton = { TextButton(onClick = { askDelete = false }) { Text("Отмена") } }
        )
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Предмет") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Если впишешь название, которое уже есть, предметы объединятся.",
                    style = MaterialTheme.typography.bodySmall
                )
                TextButton(onClick = { askDelete = true }) {
                    Text("Удалить предмет", color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onRename(name) }, enabled = name.isNotBlank()) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
