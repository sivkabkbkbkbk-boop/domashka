package ru.domashka.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import ru.domashka.data.HomeworkTask
import ru.domashka.data.elapsed
import ru.domashka.data.isRunning
import ru.domashka.data.Subject

@Composable
fun TasksTab(
    tasks: List<HomeworkTask>,
    subjects: List<Subject>,
    now: Long,
    modifier: Modifier,
    onCamera: () -> Unit,
    onGallery: () -> Unit,
    onManual: () -> Unit,
    onToggleDone: (Long) -> Unit,
    onToggleTimer: (Long) -> Unit,
    onResetTimer: (Long) -> Unit,
    onEdit: (Long, String, String) -> Unit,
    onDelete: (Long) -> Unit,
) {
    var showDone by rememberSaveable { mutableStateOf(false) }
    var editing by remember { mutableStateOf<HomeworkTask?>(null) }

    val subjectById = subjects.associateBy { it.id }
    val visible = if (showDone) tasks else tasks.filter { !it.done }
    val groups = visible
        .groupBy { it.subjectId }
        .toList()
        .sortedBy { (id, _) -> subjectById[id]?.name?.lowercase() ?: "" }
    val doneCount = tasks.count { it.done }

    Column(modifier.fillMaxSize()) {
        // Кнопки добавления
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = onCamera, modifier = Modifier.weight(1.3f)) {
                Icon(Icons.Filled.PhotoCamera, null)
                Spacer(Modifier.width(6.dp))
                Text("Сфоткать")
            }
            FilledTonalButton(onClick = onGallery, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.Image, null)
                Spacer(Modifier.width(6.dp))
                Text("Скрин")
            }
            FilledTonalIconButton(onClick = onManual) {
                Icon(Icons.Filled.Edit, "Вписать вручную")
            }
        }
        if (doneCount > 0) {
            FilterChip(
                selected = showDone,
                onClick = { showDone = !showDone },
                label = { Text("Показать выполненные ($doneCount)") },
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        if (groups.isEmpty()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (tasks.isEmpty())
                        "Пока заданий нет.\n\nНажми «Сфоткать» и наведи камеру на домашку, " +
                            "или выбери скриншот из Дневника."
                    else "Всё сделано! 🎉",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                groups.forEach { (subjectId, list) ->
                    val subjectTasks = tasks.filter { it.subjectId == subjectId }
                    item(key = "h$subjectId") {
                        SubjectHeader(
                            name = subjectById[subjectId]?.name ?: "…",
                            left = subjectTasks.count { !it.done },
                            totalMs = subjectTasks.sumOf { it.elapsed(now) }
                        )
                    }
                    items(list, key = { it.id }) { task ->
                        TaskCard(
                            task = task,
                            now = now,
                            onToggleDone = { onToggleDone(task.id) },
                            onToggleTimer = { onToggleTimer(task.id) },
                            onReset = { onResetTimer(task.id) },
                            onEdit = { editing = task },
                            onDelete = { onDelete(task.id) },
                        )
                    }
                }
            }
        }
    }

    editing?.let { t ->
        EditTaskDialog(
            task = t,
            subjectName = subjectById[t.subjectId]?.name ?: "",
            subjects = subjects.map { it.name },
            onDismiss = { editing = null },
            onSave = { text, subject ->
                onEdit(t.id, text, subject)
                editing = null
            }
        )
    }
}

@Composable
private fun SubjectHeader(name: String, left: Int, totalMs: Long) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                if (left == 0) "всё сделано" else "осталось: ${tasksWord(left)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (totalMs > 0) {
            Icon(Icons.Filled.Timer, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(4.dp))
            Text(formatHuman(totalMs), color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun TaskCard(
    task: HomeworkTask,
    now: Long,
    onToggleDone: () -> Unit,
    onToggleTimer: () -> Unit,
    onReset: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    var expanded by rememberSaveable(task.id) { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val running = task.isRunning

    Card(
        Modifier.fillMaxWidth(),
        colors = if (running) CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ) else CardDefaults.cardColors()
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.Top) {
            Checkbox(checked = task.done, onCheckedChange = { onToggleDone() })
            Column(
                Modifier
                    .weight(1f)
                    .padding(top = 12.dp)
            ) {
                Text(
                    task.text,
                    maxLines = if (expanded) Int.MAX_VALUE else 4,
                    overflow = TextOverflow.Ellipsis,
                    textDecoration = if (task.done) TextDecoration.LineThrough else null,
                    color = if (task.done) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.clickable { expanded = !expanded }
                )
                Spacer(Modifier.height(6.dp))
                val elapsed = task.elapsed(now)
                if (elapsed > 0 || running) {
                    Text(
                        (if (running) "⏱ идёт: " else "⏱ ") + formatClock(elapsed),
                        style = MaterialTheme.typography.titleMedium,
                        color = if (running) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (!task.done) {
                    if (running) {
                        FilledIconButton(onClick = onToggleTimer, modifier = Modifier.size(52.dp)) {
                            Icon(Icons.Filled.Pause, "Пауза")
                        }
                    } else {
                        FilledTonalIconButton(onClick = onToggleTimer, modifier = Modifier.size(52.dp)) {
                            Icon(Icons.Filled.PlayArrow, "Старт")
                        }
                    }
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Ещё") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Изменить") },
                            leadingIcon = { Icon(Icons.Filled.Edit, null) },
                            onClick = { menu = false; onEdit() }
                        )
                        DropdownMenuItem(
                            text = { Text("Сбросить время") },
                            onClick = { menu = false; onReset() }
                        )
                        DropdownMenuItem(
                            text = { Text("Удалить") },
                            onClick = { menu = false; confirmDelete = true }
                        )
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Удалить задание?") },
            text = { Text(task.text, maxLines = 3, overflow = TextOverflow.Ellipsis) },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Удалить") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Отмена") }
            }
        )
    }
}

@Composable
private fun EditTaskDialog(
    task: HomeworkTask,
    subjectName: String,
    subjects: List<String>,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit,
) {
    var text by remember(task.id) { mutableStateOf(task.text) }
    var subject by remember(task.id) { mutableStateOf(subjectName) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Изменить задание") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SubjectPicker(value = subject, onChange = { subject = it }, existing = subjects)
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Что задано") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(text, subject) }, enabled = text.isNotBlank()) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
