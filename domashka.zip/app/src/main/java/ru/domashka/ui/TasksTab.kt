package ru.domashka.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.domashka.data.HomeworkTask
import ru.domashka.data.Subject
import ru.domashka.data.elapsed
import ru.domashka.data.isRunning

@Composable
fun TasksTab(
    tasks: List<HomeworkTask>,
    subjects: List<Subject>,
    now: Long,
    modifier: Modifier,
    onCamera: () -> Unit,
    onGallery: () -> Unit,
    onManual: () -> Unit,
    onUndo: (Long) -> Unit,
    onStart: (Long) -> Unit,
    onStop: (Long) -> Unit,
    onFinish: (Long) -> Unit,
    onEdit: (Long, String, String) -> Unit,
    onDelete: (Long) -> Unit,
) {
    var showDone by rememberSaveable { mutableStateOf(false) }
    var editing by remember { mutableStateOf<HomeworkTask?>(null) }

    val subjectById = subjects.associateBy { it.id }
    fun nameOf(t: HomeworkTask) = subjectById[t.subjectId]?.name ?: "…"
    val running = tasks.firstOrNull { it.isRunning }
    // сверху — то, что делается сейчас, потом несделанные, внизу сделанные
    val visible = (if (showDone) tasks else tasks.filter { !it.done })
        .sortedWith(compareBy<HomeworkTask>({ !it.isRunning }, { it.done }, { nameOf(it).lowercase() }))
    val doneCount = tasks.count { it.done }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GradientButton(onClick = onCamera, brush = Brand.Main, modifier = Modifier.weight(1.3f)) {
                Text("📸 Сфоткать", style = buttonTextStyle(), color = Color.White)
            }
            GradientButton(onClick = onGallery, brush = Brand.Hot, modifier = Modifier.weight(1f)) {
                Text("🖼 Скрин", style = buttonTextStyle(), color = Color.White)
            }
            Box(
                Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brand.Surface2),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = onManual) { Icon(Icons.Filled.Edit, "Добавить вручную", tint = Brand.Text) }
            }
        }
        if (doneCount > 0) {
            FilterChip(
                selected = showDone,
                onClick = { showDone = !showDone },
                label = { Text("✅ Сделанные ($doneCount)") },
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        if (visible.isEmpty()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (tasks.isNotEmpty()) "🎉" else "📚", fontSize = 64.sp)
                    Spacer(Modifier.height(8.dp))
                    if (tasks.isNotEmpty()) {
                        Text("Всё сделано!", style = MaterialTheme.typography.headlineSmall, color = Brand.Lime)
                        Text("Голубь доволен. Можно отдыхать 😎", color = Brand.Muted)
                    } else {
                        Text("Йо! Заданий пока нет", style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Сфоткай день в дневнике или выбери скрин — я сам найду предметы, по которым что-то задано.",
                            color = Brand.Muted,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 120.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(visible, key = { it.id }) { task ->
                    TaskCard(
                        task = task,
                        subject = nameOf(task),
                        now = now,
                        otherRunning = running != null && running.id != task.id,
                        onStart = { onStart(task.id) },
                        onStop = { onStop(task.id) },
                        onFinish = { onFinish(task.id) },
                        onUndo = { onUndo(task.id) },
                        onEdit = { editing = task },
                        onDelete = { onDelete(task.id) },
                    )
                }
            }
        }
    }

    editing?.let { t ->
        EditTaskDialog(
            task = t,
            subjectName = subjectById[t.subjectId]?.name ?: "",
            subjects = subjects.map { it.name },
            onDismiss = { editing = null },
            onSave = { text, subject ->
                onEdit(t.id, text, subject)
                editing = null
            }
        )
    }
}

@Composable
private fun TaskCard(
    task: HomeworkTask,
    subject: String,
    now: Long,
    otherRunning: Boolean,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onFinish: () -> Unit,
    onUndo: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmStop by remember { mutableStateOf(false) }
    val running = task.isRunning
    val accent = Brand.accent(subject)

    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = if (running) Color(0xFF24204A) else Brand.Surface),
        border = if (running) BorderStroke(2.dp, Brand.Main) else null
    ) {
        Column(Modifier.padding(start = 14.dp, end = 4.dp, top = 12.dp, bottom = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // эмодзи предмета в цветном кружке
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(accent.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) { Text(subjectEmoji(subject), fontSize = 24.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        subject,
                        style = MaterialTheme.typography.titleLarge,
                        color = if (task.done) Brand.Muted else Brand.Text,
                        textDecoration = if (task.done) TextDecoration.LineThrough else null,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    when {
                        task.done -> Text(
                            if (task.spentMs > 0) "✅ Сделано за ${formatHuman(task.spentMs)}" else "✅ Сделано",
                            color = Brand.Lime,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        task.text.isNotBlank() -> Text(
                            task.text, color = Brand.Muted, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        else -> Text(if (running) "делаю прямо сейчас…" else "ждёт тебя", color = Brand.Muted,
                            style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Ещё", tint = Brand.Muted) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Изменить") },
                            leadingIcon = { Icon(Icons.Filled.Edit, null) },
                            onClick = { menu = false; onEdit() }
                        )
                        if (task.done) {
                            DropdownMenuItem(text = { Text("Вернуть в несделанные") }, onClick = { menu = false; onUndo() })
                        }
                        DropdownMenuItem(text = { Text("Удалить") }, onClick = { menu = false; confirmDelete = true })
                    }
                }
            }

            if (running) {
                Text(
                    formatClock(task.elapsed(now)),
                    style = MaterialTheme.typography.displaySmall,
                    color = Brand.Cyan,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, end = 10.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }

            if (!task.done) {
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(end = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (running) {
                        GradientButton(onClick = { confirmStop = true }, brush = Brand.Hot, modifier = Modifier.weight(1f)) {
                            Text("⏹ Стоп", style = buttonTextStyle(), color = Color.White)
                        }
                        GradientButton(onClick = onFinish, brush = Brand.Win, modifier = Modifier.weight(1.7f)) {
                            Text("✅ Я всё сделал!", style = buttonTextStyle(), color = Color(0xFF10240A))
                        }
                    } else {
                        GradientButton(
                            onClick = onStart,
                            brush = Brand.Main,
                            enabled = !otherRunning,
                            modifier = Modifier.weight(1.7f)
                        ) {
                            Text(
                                if (otherRunning) "Сначала доделай другое" else "▶ Погнали!",
                                style = buttonTextStyle(),
                                color = Color.White,
                                maxLines = 1
                            )
                        }
                        if (!otherRunning) {
                            OutlinedButton(
                                onClick = onFinish,
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 46.dp),
                                shape = RoundedCornerShape(18.dp),
                                border = BorderStroke(1.5.dp, Brand.Lime.copy(alpha = 0.7f))
                            ) {
                                Text("Уже сделал", color = Brand.Lime, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmStop) {
        AlertDialog(
            onDismissRequest = { confirmStop = false },
            title = { Text("Остановить?") },
            text = { Text("Время по этому заданию сбросится в ноль. Потом можно будет начать заново.") },
            confirmButton = { TextButton(onClick = { confirmStop = false; onStop() }) { Text("Стоп") } },
            dismissButton = { TextButton(onClick = { confirmStop = false }) { Text("Продолжить делать") } }
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Удалить «$subject»?") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Удалить") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun EditTaskDialog(
    task: HomeworkTask,
    subjectName: String,
    subjects: List<String>,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit,
) {
    var text by remember(task.id) { mutableStateOf(task.text) }
    var subject by remember(task.id) { mutableStateOf(subjectName) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Изменить задание") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SubjectPicker(value = subject, onChange = { subject = it }, existing = subjects)
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Заметка (можно не писать)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 80.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(text, subject) }, enabled = subject.isNotBlank()) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
