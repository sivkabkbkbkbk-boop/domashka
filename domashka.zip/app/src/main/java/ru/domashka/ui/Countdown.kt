package ru.domashka.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope

/** Обратный отсчёт на весь экран: 3, 2, 1, «Начали!» — со звуком. Потом onDone(). */
@Composable
fun CountdownOverlay(sounds: Sounds, onDone: () -> Unit) {
    val done by rememberUpdatedState(onDone)
    var label by remember { mutableStateOf("3") }
    var color by remember { mutableStateOf(Brand.Cyan) }
    val scale = remember { Animatable(2f) }
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        val steps = listOf("3" to Brand.Cyan, "2" to Brand.Violet, "1" to Brand.Pink, "Начали!" to Brand.Lime)
        for ((text, c) in steps) {
            label = text
            color = c
            val go = text == "Начали!"
            if (go) sounds.countGo() else sounds.countBeep()
            scale.snapTo(if (go) 0.4f else 2.2f)
            alpha.snapTo(1f)
            coroutineScope {
                launch { scale.animateTo(1f, tween(if (go) 450 else 380, easing = FastOutSlowInEasing)) }
            }
            kotlinx.coroutines.delay(if (go) 450 else 420)
            alpha.animateTo(0f, tween(if (go) 350 else 200))
        }
        done()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC0E0F1F))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            modifier = Modifier
                .scale(scale.value)
                .alpha(alpha.value),
            style = MaterialTheme.typography.displaySmall.copy(
                fontSize = if (label.length > 2) 64.sp else 150.sp,
                fontWeight = FontWeight.Black,
                shadow = Shadow(color.copy(alpha = 0.8f), Offset(0f, 0f), 30f)
            ),
            color = color,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Visible,
        )
    }
}
