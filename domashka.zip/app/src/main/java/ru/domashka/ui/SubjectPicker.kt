package ru.domashka.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import ru.domashka.data.SubjectKey
import ru.domashka.ocr.SubjectParser

/**
 * Выбор предмета: сначала — уже созданные предметы (нажал и готово),
 * ниже — частые школьные предметы, и поле, куда можно вписать новый.
 */
@Composable
fun SubjectPicker(
    value: String,
    onChange: (String) -> Unit,
    existing: List<String>,
    modifier: Modifier = Modifier,
) {
    val key = SubjectKey.of(value)
    val existingKeys = existing.map { SubjectKey.of(it) }.toSet()
    val suggestions = SubjectParser.COMMON.filter { SubjectKey.of(it) !in existingKeys }

    Column(modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            label = { Text("Предмет") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
            modifier = Modifier.fillMaxWidth(),
            supportingText = {
                when {
                    value.isBlank() -> Text("Выбери ниже или впиши новый")
                    key !in existingKeys -> Text("Новый предмет — появится в списке")
                    else -> Text("Предмет из списка")
                }
            }
        )
        if (existing.isNotEmpty()) {
            Text("Мои предметы", style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(4.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(existing) { name ->
                    FilterChip(
                        selected = SubjectKey.of(name) == key,
                        onClick = { onChange(name) },
                        label = { Text(name) }
                    )
                }
            }
        }
        if (suggestions.isNotEmpty()) {
            Text("Добавить новый", style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(4.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(suggestions) { name ->
                    SuggestionChip(onClick = { onChange(name) }, label = { Text(name) })
                }
            }
        }
    }
}
