package ru.domashka.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.min

/** Выделение: доли от 0 до 1 по ширине и высоте снимка. */
private data class Sel(val l: Float, val t: Float, val r: Float, val b: Float)

private enum class Grab { NONE, MOVE, L, T, R, B, TL, TR, BL, BR }

/** Где на экране лежит картинка (ContentScale.Fit, по центру). */
private fun imageRect(box: IntSize, bmpW: Int, bmpH: Int): Rect {
    val scale = min(box.width.toFloat() / bmpW, box.height.toFloat() / bmpH)
    val w = bmpW * scale
    val h = bmpH * scale
    val left = (box.width - w) / 2f
    val top = (box.height - h) / 2f
    return Rect(left, top, left + w, top + h)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CropScreen(
    bitmap: Bitmap,
    onRotate: () -> Unit,
    onCancel: () -> Unit,
    onConfirm: (Float, Float, Float, Float) -> Unit,
) {
    val image = remember(bitmap) { bitmap.asImageBitmap() }
    var sel by remember(bitmap) { mutableStateOf(Sel(0.03f, 0.03f, 0.97f, 0.97f)) }
    var grab by remember { mutableStateOf(Grab.NONE) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Выдели домашку") },
                navigationIcon = {
                    IconButton(onClick = onCancel) { Icon(Icons.Filled.Close, "Отмена") }
                },
                actions = {
                    IconButton(onClick = onRotate) { Icon(Icons.Filled.RotateRight, "Повернуть") }
                }
            )
        },
        bottomBar = {
            Column(Modifier.padding(16.dp)) {
                Text(
                    "Потяни за края рамки. Лучше выделять один день — одну колонку: так читается гораздо точнее.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.width(8.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { sel = Sel(0f, 0f, 1f, 1f) },
                        modifier = Modifier.weight(1f)
                    ) { Text("Весь снимок") }
                    Button(
                        onClick = { onConfirm(sel.l, sel.t, sel.r, sel.b) },
                        modifier = Modifier.weight(1.4f)
                    ) {
                        Icon(Icons.Filled.Crop, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Распознать")
                    }
                }
            }
        }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(12.dp)
        ) {
            Image(
                bitmap = image,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
            Canvas(
                Modifier
                    .fillMaxSize()
                    .pointerInput(bitmap) {
                        val touch = 36.dp.toPx()
                        detectDragGestures(
                            onDragStart = { pos ->
                                val img = imageRect(size, bitmap.width, bitmap.height)
                                val s = sel
                                val l = img.left + s.l * img.width
                                val r = img.left + s.r * img.width
                                val t = img.top + s.t * img.height
                                val b = img.top + s.b * img.height
                                val nearL = abs(pos.x - l) < touch
                                val nearR = abs(pos.x - r) < touch
                                val nearT = abs(pos.y - t) < touch
                                val nearB = abs(pos.y - b) < touch
                                val inY = pos.y > t - touch && pos.y < b + touch
                                val inX = pos.x > l - touch && pos.x < r + touch
                                grab = when {
                                    nearL && nearT -> Grab.TL
                                    nearR && nearT -> Grab.TR
                                    nearL && nearB -> Grab.BL
                                    nearR && nearB -> Grab.BR
                                    nearL && inY -> Grab.L
                                    nearR && inY -> Grab.R
                                    nearT && inX -> Grab.T
                                    nearB && inX -> Grab.B
                                    pos.x in l..r && pos.y in t..b -> Grab.MOVE
                                    else -> Grab.NONE
                                }
                            },
                            onDragEnd = { grab = Grab.NONE },
                            onDragCancel = { grab = Grab.NONE },
                            onDrag = { change, drag ->
                                change.consume()
                                val img = imageRect(size, bitmap.width, bitmap.height)
                                val dx = drag.x / img.width
                                val dy = drag.y / img.height
                                val minSize = 0.05f
                                val s = sel
                                sel = when (grab) {
                                    Grab.NONE -> s
                                    Grab.MOVE -> {
                                        val mx = dx.coerceIn(-s.l, 1f - s.r)
                                        val my = dy.coerceIn(-s.t, 1f - s.b)
                                        Sel(s.l + mx, s.t + my, s.r + mx, s.b + my)
                                    }
                                    else -> {
                                        var (l, t, r, b) = s
                                        if (grab in setOf(Grab.L, Grab.TL, Grab.BL)) l = (l + dx).coerceIn(0f, r - minSize)
                                        if (grab in setOf(Grab.R, Grab.TR, Grab.BR)) r = (r + dx).coerceIn(l + minSize, 1f)
                                        if (grab in setOf(Grab.T, Grab.TL, Grab.TR)) t = (t + dy).coerceIn(0f, b - minSize)
                                        if (grab in setOf(Grab.B, Grab.BL, Grab.BR)) b = (b + dy).coerceIn(t + minSize, 1f)
                                        Sel(l, t, r, b)
                                    }
                                }
                            }
                        )
                    }
            ) {
                val img = imageRect(IntSize(size.width.toInt(), size.height.toInt()), bitmap.width, bitmap.height)
                val l = img.left + sel.l * img.width
                val r = img.left + sel.r * img.width
                val t = img.top + sel.t * img.height
                val b = img.top + sel.b * img.height
                val shade = Color.Black.copy(alpha = 0.55f)
                // затемняем всё вне рамки
                drawRect(shade, Offset(img.left, img.top), Size(img.width, t - img.top))
                drawRect(shade, Offset(img.left, b), Size(img.width, img.bottom - b))
                drawRect(shade, Offset(img.left, t), Size(l - img.left, b - t))
                drawRect(shade, Offset(r, t), Size(img.right - r, b - t))
                // рамка и ручки
                val accent = Color(0xFF4FC3F7)
                drawRect(accent, Offset(l, t), Size(r - l, b - t), style = Stroke(width = 3.dp.toPx()))
                val hs = 18.dp.toPx()
                listOf(Offset(l, t), Offset(r, t), Offset(l, b), Offset(r, b)).forEach { c ->
                    drawRoundRect(
                        accent,
                        Offset(c.x - hs / 2, c.y - hs / 2),
                        Size(hs, hs),
                        CornerRadius(4.dp.toPx())
                    )
                }
                listOf(Offset((l + r) / 2, t), Offset((l + r) / 2, b)).forEach { c ->
                    drawRoundRect(accent, Offset(c.x - hs, c.y - 4.dp.toPx()), Size(hs * 2, 8.dp.toPx()), CornerRadius(4.dp.toPx()))
                }
                listOf(Offset(l, (t + b) / 2), Offset(r, (t + b) / 2)).forEach { c ->
                    drawRoundRect(accent, Offset(c.x - 4.dp.toPx(), c.y - hs), Size(8.dp.toPx(), hs * 2), CornerRadius(4.dp.toPx()))
                }
            }
        }
    }
}
