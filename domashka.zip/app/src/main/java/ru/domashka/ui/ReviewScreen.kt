package ru.domashka.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Экран проверки: какие предметы нашлись и по каким есть домашка. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewScreen(
    drafts: List<Draft>,
    preview: Bitmap?,
    subjects: List<String>,
    onChange: (Draft) -> Unit,
    onRemove: (Int) -> Unit,
    onAdd: () -> Int,
    onSave: () -> Unit,
    onCancel: () -> Unit,
) {
    val count = drafts.count { it.checked && it.subject.isNotBlank() }
    // пустой предмет (добавлен вручную) — сразу открываем выбор
    var editingId by remember { mutableStateOf(drafts.firstOrNull { it.subject.isBlank() }?.id) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Что задано") },
                navigationIcon = {
                    IconButton(onClick = onCancel) { Icon(Icons.Filled.Close, "Отмена") }
                }
            )
        },
        bottomBar = {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(onClick = { editingId = onAdd() }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Add, null)
                    Text(" Предмет")
                }
                Button(onClick = onSave, enabled = count > 0, modifier = Modifier.weight(1.4f)) {
                    Text("Добавить ($count)")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(
                    "Галочкой отмечены предметы, по которым есть домашка. Проверь и нажми «Добавить».",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            if (preview != null) {
                item {
                    var big by remember { mutableStateOf(false) }
                    val img = remember(preview) { preview.asImageBitmap() }
                    Column {
                        Image(
                            bitmap = img,
                            contentDescription = "Снимок",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = if (big) 600.dp else 160.dp)
                                .clickable { big = !big }
                        )
                        Text(
                            if (big) "Нажми на снимок, чтобы уменьшить" else "Нажми на снимок, чтобы увеличить",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
            items(drafts, key = { it.id }) { d ->
                LessonRow(
                    draft = d,
                    onToggle = { onChange(d.copy(checked = !d.checked)) },
                    onEdit = { editingId = d.id },
                    onRemove = { onRemove(d.id) }
                )
            }
        }
    }

    val editing = drafts.firstOrNull { it.id == editingId }
    if (editing != null) {
        SubjectDialog(
            initial = editing.subject,
            subjects = subjects,
            onDismiss = {
                if (editing.subject.isBlank()) onRemove(editing.id)
                editingId = null
            },
            onSave = { name ->
                onChange(editing.copy(subject = name, checked = true))
                editingId = null
            }
        )
    }
}

@Composable
private fun LessonRow(draft: Draft, onToggle: () -> Unit, onEdit: () -> Unit, onRemove: () -> Unit) {
    val (status, color) = when (draft.hasHomework) {
        true -> "есть задание" to Color(0xFF43A047)
        false -> "не задано" to MaterialTheme.colorScheme.onSurfaceVariant
        null -> if (draft.subject.isBlank()) "" to Color.Unspecified
        else "не понял, есть ли задание" to Color(0xFFFB8C00)
    }
    Card(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle),
        colors = if (draft.checked) CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ) else CardDefaults.cardColors()
    ) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = draft.checked, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f)) {
                Text(
                    draft.subject.ifBlank { "Выбери предмет" },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (status.isNotEmpty()) {
                    Text(status, style = MaterialTheme.typography.bodySmall, color = color)
                }
            }
            IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, "Изменить предмет") }
            IconButton(onClick = onRemove) { Icon(Icons.Filled.Delete, "Убрать") }
        }
    }
}

@Composable
private fun SubjectDialog(
    initial: String,
    subjects: List<String>,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit,
) {
    var name by remember(initial) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Предмет") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SubjectPicker(value = name, onChange = { name = it }, existing = subjects)
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name.trim()) }, enabled = name.isNotBlank()) { Text("Готово") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
