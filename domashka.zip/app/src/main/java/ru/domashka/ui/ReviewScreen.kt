package ru.domashka.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Экран проверки: что распознано, по каким предметам. Можно поправить перед сохранением. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewScreen(
    drafts: List<Draft>,
    preview: Bitmap?,
    subjects: List<String>,
    onChange: (Draft) -> Unit,
    onRemove: (Int) -> Unit,
    onAdd: () -> Unit,
    onSave: () -> Unit,
    onCancel: () -> Unit,
) {
    val count = drafts.count { it.text.isNotBlank() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Проверь задания") },
                navigationIcon = {
                    IconButton(onClick = onCancel) { Icon(Icons.Filled.Close, "Отмена") }
                }
            )
        },
        bottomBar = {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(onClick = onAdd, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Add, null)
                    Text(" Ещё")
                }
                Button(onClick = onSave, enabled = count > 0, modifier = Modifier.weight(2f)) {
                    Text("Сохранить ($count)")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "Я разложил текст по предметам. Проверь, исправь ошибки и нажми «Сохранить».",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            if (preview != null) {
                item {
                    var big by remember { mutableStateOf(false) }
                    val img = remember(preview) { preview.asImageBitmap() }
                    Image(
                        bitmap = img,
                        contentDescription = "Снимок",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = if (big) 600.dp else 180.dp)
                            .clickable { big = !big }
                    )
                    Text(
                        if (big) "Нажми на снимок, чтобы уменьшить" else "Нажми на снимок, чтобы увеличить",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
            items(drafts, key = { it.id }) { d ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Задание",
                                style = MaterialTheme.typography.titleSmall,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { onRemove(d.id) }) {
                                Icon(Icons.Filled.Delete, "Убрать")
                            }
                        }
                        SubjectPicker(
                            value = d.subject,
                            onChange = { onChange(d.copy(subject = it)) },
                            existing = subjects
                        )
                        OutlinedTextField(
                            value = d.text,
                            onValueChange = { onChange(d.copy(text = it)) },
                            label = { Text("Что задано") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 120.dp)
                        )
                    }
                }
            }
        }
    }
}
