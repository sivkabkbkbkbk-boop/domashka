package ru.domashka.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

// ---------------------------------------------------------------------------
// Голубь-маскот: кепка, тёмные очки, по праздникам — золотая цепь.
// ---------------------------------------------------------------------------

/**
 * Танцующий голубь. dancing = прыгает, машет крылом и курлычет (клюв открывается).
 */
@Composable
fun MascotPigeon(modifier: Modifier = Modifier, dancing: Boolean = true, chain: Boolean = false) {
    val t = rememberInfiniteTransition(label = "mascot")
    val hop by t.animateFloat(0f, 1f, infiniteRepeatable(tween(520, easing = LinearEasing)), label = "hop")
    val sway by t.animateFloat(-1f, 1f, infiniteRepeatable(tween(1040), RepeatMode.Reverse), label = "sway")
    val flap by t.animateFloat(0f, 1f, infiniteRepeatable(tween(260), RepeatMode.Reverse), label = "flap")
    val talk by t.animateFloat(0f, 1f, infiniteRepeatable(tween(180), RepeatMode.Reverse), label = "talk")
    val sparkle by t.animateFloat(0f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "sparkle")

    Canvas(modifier) {
        val u = size.minDimension / 100f
        val ox = (size.width - 100 * u) / 2
        val oy = (size.height - 100 * u) / 2
        val p = MascotPainter(this, u, ox, oy)
        val jump = if (dancing) abs(sin(hop * PI.toFloat())) * 7f else 0f
        val tilt = if (dancing) sway * 7f else 0f
        translate(top = -jump * u) {
            rotate(tilt, pivot = p.p(50f, 90f)) {
                p.pigeon(
                    wingAngle = if (dancing) 10f + flap * 30f else 0f,
                    beakOpen = if (dancing) talk * 4f else 0f,
                    chain = chain,
                )
            }
        }
        if (dancing) p.sparkles(sparkle)
    }
}

private class MascotPainter(val s: DrawScope, val u: Float, val ox: Float, val oy: Float) {
    fun p(x: Float, y: Float) = Offset(ox + x * u, oy + y * u)

    private fun oval(c: Color, cx: Float, cy: Float, rx: Float, ry: Float) =
        s.drawOval(c, p(cx - rx, cy - ry), Size(2 * rx * u, 2 * ry * u))

    private fun circle(c: Color, cx: Float, cy: Float, r: Float) = s.drawCircle(c, r * u, p(cx, cy))

    private fun line(c: Color, x1: Float, y1: Float, x2: Float, y2: Float, w: Float) =
        s.drawLine(c, p(x1, y1), p(x2, y2), w * u, StrokeCap.Round)

    private fun poly(c: Color, vararg pts: Float) {
        val path = Path()
        val first = p(pts[0], pts[1])
        path.moveTo(first.x, first.y)
        var i = 2
        while (i < pts.size) {
            val o = p(pts[i], pts[i + 1])
            path.lineTo(o.x, o.y)
            i += 2
        }
        path.close()
        s.drawPath(path, c)
    }

    fun pigeon(wingAngle: Float, beakOpen: Float, chain: Boolean) {
        val body = Color(0xFF9AA3AD)
        val head = Color(0xFF7D8792)
        val wing = Color(0xFF7E8790)
        val leg = Color(0xFFE57373)
        val bar = Color(0xFF4E555D)
        val dark = Color(0xFF3F3A3A)

        poly(Color(0xFF5E6670), 28f, 56f, 6f, 62f, 8f, 70f, 30f, 68f) // хвост
        for (x in listOf(46f, 56f)) { // лапки
            line(leg, x, 76f, x - 1, 90f, 2.5f)
            line(leg, x - 1, 90f, x + 4, 91f, 2.2f)
            line(leg, x - 1, 90f, x - 5, 91f, 2.2f)
        }
        oval(body, 50f, 62f, 27f, 18f) // тело
        s.drawOval( // шея с переливами
            Brush.linearGradient(listOf(Color(0xFF5FB878), Color(0xFF8E5FB0)), p(53f, 35f), p(75f, 59f)),
            p(53f, 35f), Size(22 * u, 24 * u)
        )
        if (chain) { // золотые цепи
            for (i in 0 until 2) {
                val rx = 11f + i * 5
                val ry = 10f + i * 5
                val cy = 46f + i
                val tl = p(64f - rx, cy - ry)
                val sz = Size(2 * rx * u, 2 * ry * u)
                s.drawArc(Color(0xFFFFC107), 0f, 180f, false, tl, sz, style = Stroke(3.2f * u))
                s.drawArc(
                    Color(0xFFB8860B), 0f, 180f, false, tl, sz,
                    style = Stroke(3.2f * u, pathEffect = PathEffect.dashPathEffect(floatArrayOf(1.2f * u, 2.6f * u)))
                )
            }
            circle(Color(0xFFFFD54F), 64f, 62f, 5f)
            s.drawCircle(Color(0xFFB8860B), 5f * u, p(64f, 62f), style = Stroke(1.2f * u))
            circle(Color(0xFFB8860B), 64f, 62f, 2f)
        }
        // крыло: машет вокруг плеча
        s.rotate(wingAngle, pivot = p(58f, 56f)) {
            oval(wing, 44f, 60f, 17f, 11f)
            line(bar, 34f, 62f, 50f, 60f, 2.2f)
            line(bar, 36f, 67f, 52f, 65f, 2.2f)
        }
        circle(head, 70f, 34f, 12f) // голова
        // клюв: нижняя половинка открывается — «курлык!»
        poly(dark, 80f, 33f, 90f, 36f, 80f, 36.5f)
        poly(dark, 80f, 36.5f, 88f, 37f + beakOpen, 80f, 39f)
        oval(Color(0xFFF1ECE6), 81f, 32.5f, 2.6f, 1.6f)
        // тёмные очки с бликом
        line(Color(0xFF111111), 59f, 34f, 67f, 34f, 2f)
        s.drawRoundRect(Color(0xFF111111), p(66f, 30.5f), Size(17 * u, 8 * u), CornerRadius(3.5f * u))
        line(Color.White.copy(alpha = 0.85f), 69f, 32.5f, 74f, 32.5f, 1.3f)
        // кепка
        s.drawArc(Color(0xFFE53935), 180f, 180f, true, p(58f, 19f), Size(24 * u, 24 * u))
        s.drawRoundRect(Color(0xFFB71C1C), p(77f, 27.5f), Size(15 * u, 3.6f * u), CornerRadius(1.8f * u))
        circle(Color(0xFFB71C1C), 70f, 20f, 1.8f)
    }

    fun sparkles(phase: Float) {
        val spots = listOf(Triple(16f, 22f, 0f), Triple(92f, 12f, 0.5f), Triple(94f, 56f, 0.25f), Triple(10f, 48f, 0.75f))
        for ((x, y, shift) in spots) {
            val a = ((phase + shift) % 1f).let { if (it < 0.5f) it * 2 else (1 - it) * 2 }
            val c = Color(0xFFFFD54F).copy(alpha = 0.3f + 0.7f * a)
            val r = 2.5f + 2.5f * a
            line(c, x - r, y, x + r, y, 1.3f)
            line(c, x, y - r, x, y + r, 1.3f)
        }
    }
}

// ---------------------------------------------------------------------------
// Конфетти
// ---------------------------------------------------------------------------

private data class Piece(val x: Float, val delay: Float, val speed: Float, val drift: Float, val spin: Float, val color: Color, val w: Float)

@Composable
fun Confetti(modifier: Modifier = Modifier, seed: Int) {
    val pieces = remember(seed) {
        val r = Random(seed)
        val colors = listOf(0xFFE53935, 0xFFFFC107, 0xFF43A047, 0xFF1E88E5, 0xFF8E24AA, 0xFFFF7043).map { Color(it) }
        List(90) {
            Piece(
                x = r.nextFloat(), delay = r.nextFloat() * 0.35f, speed = 0.7f + r.nextFloat() * 0.6f,
                drift = (r.nextFloat() - 0.5f) * 0.25f, spin = r.nextFloat() * 720f - 360f,
                color = colors[r.nextInt(colors.size)], w = 6f + r.nextFloat() * 8f
            )
        }
    }
    val progress = remember(seed) { Animatable(0f) }
    LaunchedEffect(seed) { progress.animateTo(1f, tween(3200, easing = LinearEasing)) }
    Canvas(modifier) {
        val t = progress.value
        for (pc in pieces) {
            val local = ((t - pc.delay) / (1f - pc.delay)).coerceIn(0f, 1f)
            if (local <= 0f || local >= 1f) continue
            val y = -20f + local * pc.speed * (size.height + 60f) * 1.2f
            val x = pc.x * size.width + sin(local * 12f + pc.x * 10f) * 18f + pc.drift * size.width * local
            rotate(pc.spin * local, pivot = Offset(x, y)) {
                drawRect(pc.color, Offset(x - pc.w / 2, y - pc.w / 4), Size(pc.w, pc.w / 2))
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Праздничный экран «Я всё сделал!»
// ---------------------------------------------------------------------------

private val PRAISE = listOf(
    "Курлык! Красавчик! 😎",
    "Вот это скорость!",
    "Голубь одобряет!",
    "Мощно! Так держать!",
    "Ты — легенда двора!",
    "Уважуха от голубя!",
    "Огонь! 🔥",
    "Чётко сработано!",
    "Пять с плюсом!",
    "Ты сегодня в ударе!",
    "Я бы так не смог. А я, между прочим, голубь!",
    "Курлык-курлык! Это было круто!",
)

private val ALL_DONE = listOf(
    "ВСЯ ДОМАШКА СДЕЛАНА! 🎉",
    "СВОБОДА! Всё готово! 🎉",
    "Домашке конец! Ты чемпион! 🏆",
)

@Composable
fun CelebrationOverlay(c: Celebration, sounds: Sounds?, onClose: () -> Unit) {
    val title = if (c.allDone) ALL_DONE[c.seed % ALL_DONE.size] else PRAISE[c.seed % PRAISE.size]
    val subtitle = buildString {
        val subj = if (c.subject.isNotBlank()) "«${c.subject}»" else "Задание"
        if (c.spentMs >= 60_000) {
            append("$subj — готово за ${formatHuman(c.spentMs)}.")
            if (c.averageMs >= 60_000) {
                when {
                    c.spentMs < c.averageMs * 0.9 -> append(" Быстрее, чем обычно (обычно ${formatHuman(c.averageMs)})! ⚡")
                    c.spentMs <= c.averageMs * 1.1 -> append(" Ровно в своём темпе. 👍")
                    else -> append(" Сегодня дольше обычного — зато сделано!")
                }
            }
        } else {
            append("$subj — готово!")
        }
        if (c.allDone) append("\nГолубь выдаёт тебе золотую цепь. Можно отдыхать!")
    }

    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var pokes by remember { mutableIntStateOf(0) }
    val pop = remember(c.seed) { Animatable(0f) }
    LaunchedEffect(c.seed) {
        sounds?.celebrate(scope, c.allDone, c.seed)
        pop.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessLow))
    }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.55f)),
            contentAlignment = Alignment.Center
        ) {
            Confetti(Modifier.fillMaxSize(), seed = c.seed + pokes * 7919)
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .scale(pop.value),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // облачко с похвалой
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White, contentColor = Color(0xFF1B1B1F))
                ) {
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            title,
                            fontSize = if (c.allDone) 26.sp else 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(subtitle, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                    }
                }
                MascotPigeon(
                    Modifier
                        .size(260.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            pokes++
                            sounds?.poke(c.seed + pokes)
                        },
                    dancing = true,
                    chain = c.allDone
                )
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32), contentColor = Color.White),
                    modifier = Modifier.height(52.dp)
                ) {
                    Text(if (c.allDone) "Ура, свобода!" else "Курлык! 👍", fontSize = 18.sp)
                }
            }
        }
    }
}
