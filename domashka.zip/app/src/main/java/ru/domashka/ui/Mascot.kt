package ru.domashka.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ru.domashka.data.Outfit
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

// ---------------------------------------------------------------------------
// Голубь-маскот: кепка, тёмные очки, по праздникам — золотая цепь.
// ---------------------------------------------------------------------------

/**
 * Танцующий голубь. dancing = прыгает, машет крылом и курлычет (клюв открывается).
 */
@Composable
fun MascotPigeon(modifier: Modifier = Modifier, dancing: Boolean = true, chain: Boolean = false, outfit: Outfit = Outfit()) {
    val t = rememberInfiniteTransition(label = "mascot")
    val phase by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1040, easing = LinearEasing)), label = "phase")
    Canvas(modifier) {
        if (dancing) {
            val hop = abs(sin(phase * 2f * PI.toFloat())) * 7f
            val beat = (phase * 8).toInt()
            drawPigeonSprite(
                outfit,
                SpritePose(
                    pose = "idle",
                    eyes = if (beat % 2 == 0) "talk" else "open",
                    flap = listOf(0, 30, 60, 30)[beat % 4],
                    step = if (beat % 2 == 0) 1 else -1,
                ),
                chain = chain,
                dy = -hop,
            )
        } else {
            drawPigeonSprite(outfit, SpritePose(), chain = chain)
        }
    }
}

// ---------------------------------------------------------------------------
// Конфетти
// ---------------------------------------------------------------------------

private data class Piece(val x: Float, val delay: Float, val speed: Float, val drift: Float, val spin: Float, val color: Color, val w: Float)

@Composable
fun Confetti(modifier: Modifier = Modifier, seed: Int) {
    val pieces = remember(seed) {
        val r = Random(seed)
        val colors = listOf(0xFFE53935, 0xFFFFC107, 0xFF43A047, 0xFF1E88E5, 0xFF8E24AA, 0xFFFF7043).map { Color(it) }
        List(90) {
            Piece(
                x = r.nextFloat(), delay = r.nextFloat() * 0.35f, speed = 0.7f + r.nextFloat() * 0.6f,
                drift = (r.nextFloat() - 0.5f) * 0.25f, spin = r.nextFloat() * 720f - 360f,
                color = colors[r.nextInt(colors.size)], w = 6f + r.nextFloat() * 8f
            )
        }
    }
    val progress = remember(seed) { Animatable(0f) }
    LaunchedEffect(seed) { progress.animateTo(1f, tween(3200, easing = LinearEasing)) }
    Canvas(modifier) {
        val t = progress.value
        for (pc in pieces) {
            val local = ((t - pc.delay) / (1f - pc.delay)).coerceIn(0f, 1f)
            if (local <= 0f || local >= 1f) continue
            val y = -20f + local * pc.speed * (size.height + 60f) * 1.2f
            val x = pc.x * size.width + sin(local * 12f + pc.x * 10f) * 18f + pc.drift * size.width * local
            rotate(pc.spin * local, pivot = Offset(x, y)) {
                drawRect(pc.color, Offset(x - pc.w / 2, y - pc.w / 4), Size(pc.w, pc.w / 2))
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Праздничный экран «Я всё сделал!»
// ---------------------------------------------------------------------------

private val PRAISE = listOf(
    "Курлык! Красавчик! 😎",
    "Вот это скорость!",
    "Голубь одобряет!",
    "Мощно! Так держать!",
    "Ты — легенда двора!",
    "Уважуха от голубя!",
    "Огонь! 🔥",
    "Чётко сработано!",
    "Пять с плюсом!",
    "Ты сегодня в ударе!",
    "Я бы так не смог. А я, между прочим, голубь!",
    "Курлык-курлык! Это было круто!",
)

private val ALL_DONE = listOf(
    "ВСЯ ДОМАШКА СДЕЛАНА! 🎉",
    "СВОБОДА! Всё готово! 🎉",
    "Домашке конец! Ты чемпион! 🏆",
)

@Composable
fun CelebrationOverlay(c: Celebration, sounds: Sounds?, outfit: Outfit = Outfit(), onClose: () -> Unit) {
    val title = if (c.allDone) ALL_DONE[c.seed % ALL_DONE.size] else PRAISE[c.seed % PRAISE.size]
    val subtitle = buildString {
        val subj = if (c.subject.isNotBlank()) "«${c.subject}»" else "Задание"
        if (c.spentMs >= 60_000) {
            append("$subj — готово за ${formatHuman(c.spentMs)}.")
            if (c.averageMs >= 60_000) {
                when {
                    c.spentMs < c.averageMs * 0.9 -> append(" Быстрее, чем обычно (обычно ${formatHuman(c.averageMs)})! ⚡")
                    c.spentMs <= c.averageMs * 1.1 -> append(" Ровно в своём темпе. 👍")
                    else -> append(" Сегодня дольше обычного — зато сделано!")
                }
            }
        } else {
            append("$subj — готово!")
        }
        if (c.allDone) append("\nГолубь выдаёт тебе золотую цепь. Можно отдыхать!")
    }

    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var pokes by remember { mutableIntStateOf(0) }
    val pop = remember(c.seed) { Animatable(0f) }
    LaunchedEffect(c.seed) {
        sounds?.celebrate(scope, c.allDone, c.seed)
        pop.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessLow))
    }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.55f)),
            contentAlignment = Alignment.Center
        ) {
            Confetti(Modifier.fillMaxSize(), seed = c.seed + pokes * 7919)
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .scale(pop.value),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // облачко с похвалой
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White, contentColor = Color(0xFF1B1B1F))
                ) {
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            title,
                            fontSize = if (c.allDone) 26.sp else 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(subtitle, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                    }
                }
                MascotPigeon(
                    Modifier
                        .size(260.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            pokes++
                            sounds?.poke(c.seed + pokes)
                        },
                    dancing = true,
                    chain = c.allDone,
                    outfit = outfit
                )
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32), contentColor = Color.White),
                    modifier = Modifier.height(52.dp)
                ) {
                    Text(if (c.allDone) "Ура, свобода!" else "Курлык! 👍", fontSize = 18.sp)
                }
            }
        }
    }
}
