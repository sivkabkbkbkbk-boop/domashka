package ru.domashka.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ru.domashka.data.Outfit
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

// ---------------------------------------------------------------------------
// Голубь-маскот: кепка, тёмные очки, по праздникам — золотая цепь.
// ---------------------------------------------------------------------------

/**
 * Танцующий голубь. dancing = прыгает, машет крылом и курлычет (клюв открывается).
 */
@Composable
fun MascotPigeon(modifier: Modifier = Modifier, dancing: Boolean = true, chain: Boolean = false, outfit: Outfit = Outfit()) {
    val t = rememberInfiniteTransition(label = "mascot")
    val hop by t.animateFloat(0f, 1f, infiniteRepeatable(tween(520, easing = LinearEasing)), label = "hop")
    val sway by t.animateFloat(-1f, 1f, infiniteRepeatable(tween(1040), RepeatMode.Reverse), label = "sway")
    val flap by t.animateFloat(0f, 1f, infiniteRepeatable(tween(260), RepeatMode.Reverse), label = "flap")
    val talk by t.animateFloat(0f, 1f, infiniteRepeatable(tween(180), RepeatMode.Reverse), label = "talk")
    val sparkle by t.animateFloat(0f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "sparkle")

    Canvas(modifier) {
        val u = size.minDimension / 100f
        val ox = (size.width - 100 * u) / 2
        val oy = (size.height - 100 * u) / 2
        val p = MascotPainter(this, u, ox, oy)
        val jump = if (dancing) abs(sin(hop * PI.toFloat())) * 7f else 0f
        val tilt = if (dancing) sway * 7f else 0f
        translate(top = -jump * u) {
            rotate(tilt, pivot = p.p(50f, 90f)) {
                p.pigeon(
                    wingAngle = if (dancing) 10f + flap * 30f else 0f,
                    beakOpen = if (dancing) talk * 4f else 0f,
                    chain = chain,
                    outfit = outfit,
                )
            }
        }
        if (dancing) p.sparkles(sparkle)
    }
}

internal class MascotPainter(val s: DrawScope, val u: Float, val ox: Float, val oy: Float) {
    fun p(x: Float, y: Float) = Offset(ox + x * u, oy + y * u)

    private fun oval(c: Color, cx: Float, cy: Float, rx: Float, ry: Float) =
        s.drawOval(c, p(cx - rx, cy - ry), Size(2 * rx * u, 2 * ry * u))

    private fun circle(c: Color, cx: Float, cy: Float, r: Float) = s.drawCircle(c, r * u, p(cx, cy))

    private fun line(c: Color, x1: Float, y1: Float, x2: Float, y2: Float, w: Float) =
        s.drawLine(c, p(x1, y1), p(x2, y2), w * u, StrokeCap.Round)

    private fun poly(c: Color, vararg pts: Float) {
        val path = Path()
        val first = p(pts[0], pts[1])
        path.moveTo(first.x, first.y)
        var i = 2
        while (i < pts.size) {
            val o = p(pts[i], pts[i + 1])
            path.lineTo(o.x, o.y)
            i += 2
        }
        path.close()
        s.drawPath(path, c)
    }

    /**
     * Голубь в своём наряде (outfit).
     * tilt — наклон корпуса вперёд вокруг «бедра» (лапки стоят на месте): клюёт, пьёт.
     * eyesClosed — глаза закрыты. glasses=false — снять очки на время (гладят, спит).
     * chain — временная золотая цепь (праздник «вся домашка сделана»).
     */
    fun pigeon(
        wingAngle: Float,
        beakOpen: Float,
        chain: Boolean,
        tilt: Float = 0f,
        eyesClosed: Boolean = false,
        glasses: Boolean = true,
        step: Float = 0f,
        outfit: Outfit = Outfit(),
    ) {
        val (body, head, wing) = when (outfit.color) {
            "gold" -> Triple(Color(0xFFE6C15A), Color(0xFFC9A43E), Color(0xFFD4AF4A))
            "black" -> Triple(Color(0xFF4A505A), Color(0xFF2E333B), Color(0xFF3A3F47))
            "blue" -> Triple(Color(0xFFA8D8F2), Color(0xFF7FB8DD), Color(0xFF8CC4E6))
            "white" -> Triple(Color(0xFFF4F4F4), Color(0xFFE2E2E2), Color(0xFFD8D8D8))
            "pink" -> Triple(Color(0xFFF6B3CC), Color(0xFFE68FB0), Color(0xFFEC9ABA))
            else -> Triple(Color(0xFF9AA3AD), Color(0xFF7D8792), Color(0xFF7E8790))
        }
        val leg = Color(0xFFE57373)
        val bar = Color(0xFF4E555D)
        val dark = Color(0xFF3F3A3A)

        listOf(46f, 56f).forEachIndexed { i, x -> // лапки — не наклоняются; при ходьбе переступают
            val swing = if (i == 0) step * 4f else -step * 4f
            val lift = if ((i == 0 && step > 0f) || (i == 1 && step < 0f)) kotlin.math.abs(step) * 2.5f else 0f
            val fx = x - 1 + swing
            val fy = 90f - lift
            line(leg, x, 76f, fx, fy, 2.5f)
            line(leg, fx, fy, fx + 5, fy + 1, 2.2f)
            line(leg, fx, fy, fx - 4, fy + 1, 2.2f)
        }
        s.rotate(tilt, pivot = p(50f, 76f)) {
            if (outfit.back == "cape") { // плащ — за телом
                poly(Color(0xFFDC2626), 66f, 40f, 44f, 40f, 6f, 58f, 10f, 82f, 40f, 76f)
                poly(Color(0xFFB91C1C), 66f, 40f, 56f, 41f, 14f, 66f, 10f, 82f)
            }
            poly(Color(0xFF5E6670), 28f, 56f, 6f, 62f, 8f, 70f, 30f, 68f) // хвост
            oval(body, 50f, 62f, 27f, 18f) // тело
            s.drawOval( // шея с переливами
                Brush.linearGradient(listOf(Color(0xFF5FB878), Color(0xFF8E5FB0)), p(53f, 35f), p(75f, 59f)),
                p(53f, 35f), Size(22 * u, 24 * u)
            )
            if (outfit.back == "backpack") {
                s.drawRoundRect(Color(0xFF16A34A), p(28f, 40f), Size(20 * u, 20 * u), CornerRadius(5 * u))
                s.drawRoundRect(Color(0xFF15803D), p(31f, 50f), Size(14 * u, 7 * u), CornerRadius(2 * u))
            }
            s.rotate(wingAngle, pivot = p(58f, 56f)) { // крыло
                oval(wing, 44f, 60f, 17f, 11f)
                line(bar, 34f, 62f, 50f, 60f, 2.2f)
                line(bar, 36f, 67f, 52f, 65f, 2.2f)
            }
            if (outfit.back == "backpack") line(Color(0xFF14532D), 46f, 44f, 58f, 56f, 2.2f)
            neckItem(if (chain) "chain" else outfit.neck)

            circle(head, 70f, 34f, 12f) // голова
            poly(dark, 80f, 33f, 90f, 36f, 80f, 36.5f) // клюв
            poly(dark, 80f, 36.5f, 88f, 37f + beakOpen, 80f, 39f)
            oval(Color(0xFFF1ECE6), 81f, 32.5f, 2.6f, 1.6f)

            val eyewear = if (glasses) outfit.eyes else null
            val coversEye = eyewear == "sun" || eyewear == "pixel" || eyewear == "hearts"
            if (!coversEye) {
                if (eyesClosed) {
                    s.drawArc(Color(0xFF111111), 10f, 160f, false, p(71f, 31f), Size(6 * u, 4 * u), style = Stroke(1.4f * u))
                } else {
                    circle(Color(0xFFFF8C00), 74f, 33.5f, 3.2f)
                    circle(Color(0xFF111111), 74.5f, 33.5f, 1.6f)
                }
            }
            eyeItem(eyewear)
            headItem(outfit.head)
        }
    }

    private fun neckItem(id: String?) {
        when (id) {
            "chain" -> {
                val tl = p(53f, 36f)
                val sz = Size(22 * u, 20 * u)
                s.drawArc(Color(0xFFFFC107), 0f, 180f, false, tl, sz, style = Stroke(3.2f * u))
                s.drawArc(
                    Color(0xFFB8860B), 0f, 180f, false, tl, sz,
                    style = Stroke(3.2f * u, pathEffect = PathEffect.dashPathEffect(floatArrayOf(1.2f * u, 2.6f * u)))
                )
                circle(Color(0xFFFFD54F), 64f, 58f, 4.5f)
                s.drawCircle(Color(0xFFB8860B), 4.5f * u, p(64f, 58f), style = Stroke(1.2f * u))
                circle(Color(0xFFB8860B), 64f, 58f, 1.8f)
            }
            "scarf" -> {
                val tl = p(53f, 37f)
                val sz = Size(22 * u, 16 * u)
                s.drawArc(Color(0xFFEF4444), 0f, 180f, false, tl, sz, style = Stroke(5f * u))
                s.drawArc(
                    Color.White, 0f, 180f, false, tl, sz,
                    style = Stroke(5f * u, pathEffect = PathEffect.dashPathEffect(floatArrayOf(2f * u, 3f * u)))
                )
                poly(Color(0xFFEF4444), 57f, 49f, 62f, 50f, 60f, 63f, 55f, 62f)
            }
            "bowtie" -> {
                poly(Color(0xFFDC2626), 57f, 45f, 64f, 49f, 57f, 53f)
                poly(Color(0xFFDC2626), 71f, 45f, 64f, 49f, 71f, 53f)
                circle(Color(0xFF991B1B), 64f, 49f, 2f)
            }
            "tie" -> {
                poly(Color(0xFF1D4ED8), 62f, 47f, 66f, 47f, 65f, 50f, 63f, 50f)
                poly(Color(0xFF2563EB), 63f, 50f, 65f, 50f, 67f, 62f, 64f, 66f, 61f, 62f)
                line(Color(0xFF93C5FD), 62f, 55f, 66f, 54f, 1f)
                line(Color(0xFF93C5FD), 61.6f, 59f, 66.6f, 58f, 1f)
            }
            "medal" -> {
                line(Color(0xFF2563EB), 57f, 41f, 64f, 54f, 2.4f)
                line(Color(0xFF2563EB), 71f, 41f, 64f, 54f, 2.4f)
                circle(Color(0xFFFFC53D), 64f, 57f, 4.5f)
                s.drawCircle(Color(0xFFB8860B), 4.5f * u, p(64f, 57f), style = Stroke(1f * u))
                circle(Color(0xFFB8860B), 64f, 57f, 1.6f)
            }
        }
    }

    private fun eyeItem(id: String?) {
        val black = Color(0xFF111111)
        when (id) {
            "sun" -> {
                line(black, 59f, 34f, 67f, 34f, 2f)
                s.drawRoundRect(black, p(66f, 30.5f), Size(17 * u, 8 * u), CornerRadius(3.5f * u))
                line(Color.White.copy(alpha = 0.85f), 69f, 32.5f, 74f, 32.5f, 1.3f)
            }
            "pixel" -> {
                line(black, 59f, 32.5f, 67f, 32.5f, 2f)
                s.drawRect(black, p(66f, 30.5f), Size(16 * u, 3.4f * u))
                s.drawRect(black, p(67.5f, 33.9f), Size(11 * u, 3.4f * u))
                s.drawRect(Color.White, p(69f, 31.2f), Size(2 * u, 2 * u))
                s.drawRect(Color.White, p(71f, 34.4f), Size(2 * u, 2 * u))
            }
            "nerd" -> {
                line(black, 59f, 33f, 69.5f, 33f, 1.5f)
                circle(Color(0x4DBAE6FD), 74f, 33.5f, 4.6f)
                s.drawCircle(black, 4.6f * u, p(74f, 33.5f), style = Stroke(1.6f * u))
            }
            "monocle" -> {
                s.drawCircle(Color(0xFFD4A017), 4.3f * u, p(74f, 33.5f), style = Stroke(1.4f * u))
                line(Color(0xFFD4A017), 74f, 37.8f, 70f, 44f, 0.8f)
                line(Color(0xFFD4A017), 70f, 44f, 64f, 48f, 0.8f)
            }
            "hearts" -> {
                line(Color(0xFFDB2777), 59f, 33f, 68f, 33f, 1.6f)
                val pink = Color(0xFFEC4899)
                circle(pink, 71.5f, 32.3f, 2.9f)
                circle(pink, 76.5f, 32.3f, 2.9f)
                poly(pink, 68.7f, 33.2f, 79.3f, 33.2f, 74f, 39f)
            }
        }
    }

    private fun headItem(id: String?) {
        when (id) {
            "cap" -> {
                s.drawArc(Color(0xFFE53935), 180f, 180f, true, p(58f, 19f), Size(24 * u, 24 * u))
                s.drawRoundRect(Color(0xFFB71C1C), p(77f, 27.5f), Size(15 * u, 3.6f * u), CornerRadius(1.8f * u))
                circle(Color(0xFFB71C1C), 70f, 20f, 1.8f)
            }
            "beanie" -> {
                s.drawArc(Color(0xFF3B82F6), 180f, 180f, true, p(57.5f, 17.5f), Size(25 * u, 25 * u))
                s.drawRoundRect(Color(0xFF1D4ED8), p(57f, 27f), Size(26 * u, 4.5f * u), CornerRadius(2 * u))
                circle(Color.White, 70f, 17f, 3.2f)
            }
            "crown" -> {
                poly(Color(0xFFFFC53D), 60f, 26f, 60f, 16f, 64.5f, 21f, 67.5f, 13f, 70f, 20f, 72.5f, 13f, 75.5f, 21f, 80f, 16f, 80f, 26f)
                circle(Color(0xFFE11D48), 70f, 23f, 1.6f)
                circle(Color(0xFF2563EB), 64f, 23.5f, 1.1f)
                circle(Color(0xFF16A34A), 76f, 23.5f, 1.1f)
            }
            "party" -> {
                poly(Color(0xFFEC4899), 62f, 25f, 70f, 5f, 78f, 25f)
                line(Color(0xFFFDE047), 64.5f, 19f, 74f, 15f, 1.6f)
                line(Color(0xFFFDE047), 63f, 23.5f, 76.5f, 21f, 1.6f)
                circle(Color(0xFFFDE047), 70f, 5f, 2.6f)
            }
            "cowboy" -> {
                oval(Color(0xFF8D5524), 70f, 24.5f, 17f, 3.6f)
                poly(Color(0xFFA0652E), 61f, 24f, 62f, 13f, 66f, 11.5f, 70f, 14f, 74f, 11.5f, 78f, 13f, 79f, 24f)
                s.drawRect(Color(0xFF5B3718), p(61.4f, 20f), Size(17.2f * u, 2.6f * u))
            }
            "tophat" -> {
                oval(Color(0xFF111111), 70f, 24f, 13.5f, 2.8f)
                s.drawRoundRect(Color(0xFF1F1F1F), p(62f, 6f), Size(16 * u, 18 * u), CornerRadius(1.5f * u))
                s.drawRect(Color(0xFFDC2626), p(62f, 18.5f), Size(16 * u, 3 * u))
            }
            "headphones" -> {
                s.drawArc(Color(0xFF1F2937), 190f, 150f, false, p(57.5f, 21f), Size(25 * u, 26 * u), style = Stroke(2.8f * u))
                oval(Color(0xFFEF4444), 64f, 33f, 4.5f, 5.8f)
                oval(Color(0xFF7F1D1D), 64f, 33f, 2.4f, 3.6f)
            }
        }
    }

    fun sparkles(phase: Float) {
        val spots = listOf(Triple(16f, 22f, 0f), Triple(92f, 12f, 0.5f), Triple(94f, 56f, 0.25f), Triple(10f, 48f, 0.75f))
        for ((x, y, shift) in spots) {
            val a = ((phase + shift) % 1f).let { if (it < 0.5f) it * 2 else (1 - it) * 2 }
            val c = Color(0xFFFFD54F).copy(alpha = 0.3f + 0.7f * a)
            val r = 2.5f + 2.5f * a
            line(c, x - r, y, x + r, y, 1.3f)
            line(c, x, y - r, x, y + r, 1.3f)
        }
    }
}

// ---------------------------------------------------------------------------
// Конфетти
// ---------------------------------------------------------------------------

private data class Piece(val x: Float, val delay: Float, val speed: Float, val drift: Float, val spin: Float, val color: Color, val w: Float)

@Composable
fun Confetti(modifier: Modifier = Modifier, seed: Int) {
    val pieces = remember(seed) {
        val r = Random(seed)
        val colors = listOf(0xFFE53935, 0xFFFFC107, 0xFF43A047, 0xFF1E88E5, 0xFF8E24AA, 0xFFFF7043).map { Color(it) }
        List(90) {
            Piece(
                x = r.nextFloat(), delay = r.nextFloat() * 0.35f, speed = 0.7f + r.nextFloat() * 0.6f,
                drift = (r.nextFloat() - 0.5f) * 0.25f, spin = r.nextFloat() * 720f - 360f,
                color = colors[r.nextInt(colors.size)], w = 6f + r.nextFloat() * 8f
            )
        }
    }
    val progress = remember(seed) { Animatable(0f) }
    LaunchedEffect(seed) { progress.animateTo(1f, tween(3200, easing = LinearEasing)) }
    Canvas(modifier) {
        val t = progress.value
        for (pc in pieces) {
            val local = ((t - pc.delay) / (1f - pc.delay)).coerceIn(0f, 1f)
            if (local <= 0f || local >= 1f) continue
            val y = -20f + local * pc.speed * (size.height + 60f) * 1.2f
            val x = pc.x * size.width + sin(local * 12f + pc.x * 10f) * 18f + pc.drift * size.width * local
            rotate(pc.spin * local, pivot = Offset(x, y)) {
                drawRect(pc.color, Offset(x - pc.w / 2, y - pc.w / 4), Size(pc.w, pc.w / 2))
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Праздничный экран «Я всё сделал!»
// ---------------------------------------------------------------------------

private val PRAISE = listOf(
    "Курлык! Красавчик! 😎",
    "Вот это скорость!",
    "Голубь одобряет!",
    "Мощно! Так держать!",
    "Ты — легенда двора!",
    "Уважуха от голубя!",
    "Огонь! 🔥",
    "Чётко сработано!",
    "Пять с плюсом!",
    "Ты сегодня в ударе!",
    "Я бы так не смог. А я, между прочим, голубь!",
    "Курлык-курлык! Это было круто!",
)

private val ALL_DONE = listOf(
    "ВСЯ ДОМАШКА СДЕЛАНА! 🎉",
    "СВОБОДА! Всё готово! 🎉",
    "Домашке конец! Ты чемпион! 🏆",
)

@Composable
fun CelebrationOverlay(c: Celebration, sounds: Sounds?, outfit: Outfit = Outfit(), onClose: () -> Unit) {
    val title = if (c.allDone) ALL_DONE[c.seed % ALL_DONE.size] else PRAISE[c.seed % PRAISE.size]
    val subtitle = buildString {
        val subj = if (c.subject.isNotBlank()) "«${c.subject}»" else "Задание"
        if (c.spentMs >= 60_000) {
            append("$subj — готово за ${formatHuman(c.spentMs)}.")
            if (c.averageMs >= 60_000) {
                when {
                    c.spentMs < c.averageMs * 0.9 -> append(" Быстрее, чем обычно (обычно ${formatHuman(c.averageMs)})! ⚡")
                    c.spentMs <= c.averageMs * 1.1 -> append(" Ровно в своём темпе. 👍")
                    else -> append(" Сегодня дольше обычного — зато сделано!")
                }
            }
        } else {
            append("$subj — готово!")
        }
        if (c.allDone) append("\nГолубь выдаёт тебе золотую цепь. Можно отдыхать!")
    }

    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var pokes by remember { mutableIntStateOf(0) }
    val pop = remember(c.seed) { Animatable(0f) }
    LaunchedEffect(c.seed) {
        sounds?.celebrate(scope, c.allDone, c.seed)
        pop.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessLow))
    }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.55f)),
            contentAlignment = Alignment.Center
        ) {
            Confetti(Modifier.fillMaxSize(), seed = c.seed + pokes * 7919)
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .scale(pop.value),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // облачко с похвалой
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White, contentColor = Color(0xFF1B1B1F))
                ) {
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            title,
                            fontSize = if (c.allDone) 26.sp else 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(subtitle, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                    }
                }
                MascotPigeon(
                    Modifier
                        .size(260.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            pokes++
                            sounds?.poke(c.seed + pokes)
                        },
                    dancing = true,
                    chain = c.allDone,
                    outfit = outfit
                )
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32), contentColor = Color.White),
                    modifier = Modifier.height(52.dp)
                ) {
                    Text(if (c.allDone) "Ура, свобода!" else "Курлык! 👍", fontSize = 18.sp)
                }
            }
        }
    }
}
