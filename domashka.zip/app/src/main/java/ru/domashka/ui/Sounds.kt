package ru.domashka.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import ru.domashka.R

/** Звуки голубя. Загружаются один раз; выключаются кнопкой с динамиком. */
class Sounds(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val pool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val coo = pool.load(context, R.raw.coo, 1)
    private val fanfare = pool.load(context, R.raw.fanfare, 1)
    private val boing = pool.load(context, R.raw.boing, 1)
    private val whistle = pool.load(context, R.raw.whistle, 1)
    private val tada = pool.load(context, R.raw.tada, 1)

    var enabled: Boolean
        get() = prefs.getBoolean("sound", true)
        set(value) = prefs.edit().putBoolean("sound", value).apply()

    private fun play(id: Int, volume: Float = 1f, rate: Float = 1f) {
        if (enabled) pool.play(id, volume, volume, 1, 0, rate)
    }

    /** Праздник за одно задание: фанфары, «курлык» и случайный смешной звук. */
    fun celebrate(scope: CoroutineScope, allDone: Boolean, seed: Int) {
        scope.launch(Dispatchers.Main) {
            if (allDone) {
                play(tada)
                delay(700)
                play(coo, rate = 1.1f)
                delay(500)
                play(whistle)
                delay(700)
                play(coo, rate = 0.9f)
            } else {
                play(fanfare)
                delay(650)
                play(coo, rate = 0.95f + (seed % 3) * 0.05f)
                delay(750)
                if (seed % 2 == 0) play(boing) else play(whistle)
            }
        }
    }

    /** Короткий «курлык» — когда голубя тыкают пальцем. */
    fun poke(seed: Int) = play(coo, rate = 0.85f + (seed % 5) * 0.1f)
}
