package ru.domashka.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import ru.domashka.R

/** Звуки голубя. Все негромкие; выключаются кнопкой с динамиком. */
class Sounds(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val pool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val coo = pool.load(context, R.raw.coo, 1)
    private val fanfare = pool.load(context, R.raw.fanfare, 1)
    private val boing = pool.load(context, R.raw.boing, 1)
    private val whistle = pool.load(context, R.raw.whistle, 1)
    private val tada = pool.load(context, R.raw.tada, 1)
    private val peck = pool.load(context, R.raw.pet_peck, 1)
    private val purr = pool.load(context, R.raw.pet_purr, 1)
    private val gulp = pool.load(context, R.raw.pet_gulp, 1)
    private val splash = pool.load(context, R.raw.pet_splash, 1)
    private val giggle = pool.load(context, R.raw.pet_giggle, 1)
    private val lullaby = pool.load(context, R.raw.pet_lullaby, 1)
    private val clap = pool.load(context, R.raw.pet_clap, 1)
    private val beat = pool.load(context, R.raw.pet_beat, 1)

    var enabled: Boolean
        get() = prefs.getBoolean("sound", true)
        set(value) = prefs.edit().putBoolean("sound", value).apply()

    private fun play(id: Int, volume: Float, rate: Float = 1f) {
        if (enabled) pool.play(id, volume, volume, 1, 0, rate)
    }

    /** Праздник за задание — тихо и приятно. */
    fun celebrate(scope: CoroutineScope, allDone: Boolean, seed: Int) {
        scope.launch(Dispatchers.Main) {
            if (allDone) {
                play(tada, CELEBRATE)
                delay(900)
                play(coo, COO)
                delay(600)
                play(whistle, CELEBRATE * 0.7f)
            } else {
                play(fanfare, CELEBRATE)
                delay(700)
                play(coo, COO, rate = 0.95f + (seed % 3) * 0.05f)
                delay(800)
                if (seed % 2 == 0) play(boing, CELEBRATE * 0.8f) else play(whistle, CELEBRATE * 0.6f)
            }
        }
    }

    fun poke(seed: Int) = play(coo, COO, rate = 0.9f + (seed % 4) * 0.07f)

    // --- звуки действий с голубем ---
    fun peck() = play(peck, PET)
    fun purr() = play(purr, PET)
    fun gulp() = play(gulp, PET)
    fun splash() = play(splash, PET * 0.8f)
    fun giggle() = play(giggle, PET * 0.8f)
    fun lullaby() = play(lullaby, PET * 0.8f)
    fun clap() = play(clap, PET)
    fun beat() = play(beat, PET * 0.7f)
    fun coo() = play(coo, PET)

    // --- фоновые звуки, пока голубь гуляет ---
    fun ambientPeck() = play(peck, AMBIENT)
    fun ambientCoo(seed: Int) = play(coo, AMBIENT, rate = 0.9f + (seed % 4) * 0.06f)

    /** Новая ачивка. */
    fun achievement() = play(clap, PET)

    companion object {
        // всё в 5 раз тише, чем было: еле слышно, не мешает
        private const val CELEBRATE = 0.028f
        private const val COO = 0.024f
        private const val PET = 0.044f
        /** Звуки гуляющего голубя — ещё тише. */
        private const val AMBIENT = 0.02f
    }
}
