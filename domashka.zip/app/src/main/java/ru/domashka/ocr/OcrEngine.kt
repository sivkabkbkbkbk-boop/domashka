package ru.domashka.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Распознавание текста прямо на телефоне (Tesseract, языки rus+eng, цифры входят в оба).
 * Модели лежат в assets/tessdata и при первом запуске копируются в память приложения.
 */
class OcrEngine(private val context: Context) {

    private val lock = Mutex()

    /** Открывает фото с учётом поворота (EXIF). Держим достаточно деталей для обрезки. */
    suspend fun loadBitmap(uri: Uri): Bitmap = withContext(Dispatchers.IO) {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        val bmp = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val w = info.size.width
            val h = info.size.height
            val longest = max(w, h)
            if (longest > LOAD_MAX_SIDE) {
                val scale = LOAD_MAX_SIDE.toFloat() / longest
                decoder.setTargetSize((w * scale).roundToInt(), (h * scale).roundToInt())
            }
        }
        if (bmp.config == Bitmap.Config.ARGB_8888) bmp
        else bmp.copy(Bitmap.Config.ARGB_8888, false).also { bmp.recycle() }
    }

    fun rotate(src: Bitmap): Bitmap {
        val m = Matrix().apply { postRotate(90f) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    /** Вырезает часть снимка. l, t, r, b — доли от 0 до 1. */
    fun crop(src: Bitmap, l: Float, t: Float, r: Float, b: Float): Bitmap {
        val x = (l * src.width).roundToInt().coerceIn(0, src.width - 1)
        val y = (t * src.height).roundToInt().coerceIn(0, src.height - 1)
        val w = ((r - l) * src.width).roundToInt().coerceIn(1, src.width - x)
        val h = ((b - t) * src.height).roundToInt().coerceIn(1, src.height - y)
        return Bitmap.createBitmap(src, x, y, w, h)
    }

    suspend fun recognize(src: Bitmap): String = lock.withLock {
        withContext(Dispatchers.Default) {
            val prepared = prepare(src)
            val dataPath = prepareData()
            val api = TessBaseAPI()
            try {
                if (!api.init(dataPath, "rus+eng")) {
                    throw IllegalStateException("Не удалось загрузить языковые модели")
                }
                // одна колонка дня — читаем сверху вниз, не перемешивая блоки
                api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_COLUMN)
                // адаптивная бинаризация — лучше для фото экрана с неровным светом
                api.setVariable("thresholding_method", "1")
                api.setVariable("user_defined_dpi", "300")
                api.setImage(prepared)
                cleanup(api.getUTF8Text() ?: "")
            } finally {
                api.recycle()
                if (prepared !== src) prepared.recycle()
            }
        }
    }

    /**
     * Серый цвет + масштаб: мелкий текст увеличиваем (до 2 раз), огромные снимки уменьшаем.
     * Tesseract лучше всего читает, когда строчные буквы высотой ~20–30 пикселей.
     */
    private fun prepare(src: Bitmap): Bitmap {
        val longest = max(src.width, src.height)
        val scale = min(OCR_TARGET_SIDE.toFloat() / longest, 2f)
        val w = (src.width * scale).roundToInt().coerceAtLeast(1)
        val h = (src.height * scale).roundToInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        }
        Canvas(out).drawBitmap(src, Rect(0, 0, src.width, src.height), Rect(0, 0, w, h), paint)
        return out
    }

    private fun prepareData(): String {
        val base = File(context.filesDir, "tesseract")
        val dir = File(base, "tessdata").apply { mkdirs() }
        val versionFile = File(base, "version.txt")
        val fresh = versionFile.exists() && versionFile.readText() == MODELS_VERSION.toString()
        for (lang in LANGS) {
            val target = File(dir, "$lang.traineddata")
            if (!fresh || !target.exists() || target.length() == 0L) {
                val tmp = File(dir, "$lang.tmp")
                context.assets.open("tessdata/$lang.traineddata").use { input ->
                    tmp.outputStream().use { input.copyTo(it) }
                }
                target.delete()
                tmp.renameTo(target)
            }
        }
        versionFile.writeText(MODELS_VERSION.toString())
        return base.absolutePath
    }

    /** Убираем мусор, но сохраняем абзацы (пустая строка между ними). */
    private fun cleanup(raw: String): String {
        val lines = raw.replace("\r", "").lines().map { it.trimEnd() }
        val out = StringBuilder()
        var blank = 0
        for (line in lines) {
            if (line.isBlank()) {
                blank++
            } else {
                if (out.isNotEmpty()) out.append(if (blank > 0) "\n\n" else "\n")
                out.append(line)
                blank = 0
            }
        }
        return out.toString()
    }

    companion object {
        private val LANGS = listOf("rus", "eng")
        private const val LOAD_MAX_SIDE = 3200
        private const val OCR_TARGET_SIDE = 2600
        /** Увеличить, когда меняются модели в assets — тогда они перекопируются. */
        private const val MODELS_VERSION = 2
    }
}
