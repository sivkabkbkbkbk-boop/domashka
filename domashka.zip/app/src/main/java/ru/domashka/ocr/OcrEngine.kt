package ru.domashka.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max

/**
 * Распознавание текста прямо на телефоне (Tesseract, языки rus+eng, цифры входят в оба).
 * Модели лежат в assets/tessdata и при первом запуске копируются в память приложения.
 */
class OcrEngine(private val context: Context) {

    private val lock = Mutex()

    suspend fun recognize(uri: Uri): String = lock.withLock {
        withContext(Dispatchers.Default) {
            val bitmap = loadBitmap(uri)
            val dataPath = prepareData()
            val api = TessBaseAPI()
            try {
                if (!api.init(dataPath, "rus+eng")) {
                    throw IllegalStateException("Не удалось загрузить языковые модели")
                }
                api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
                api.setImage(bitmap)
                cleanup(api.getUTF8Text() ?: "")
            } finally {
                api.recycle()
                bitmap.recycle()
            }
        }
    }

    private fun prepareData(): String {
        val base = File(context.filesDir, "tesseract")
        val dir = File(base, "tessdata").apply { mkdirs() }
        for (lang in LANGS) {
            val target = File(dir, "$lang.traineddata")
            if (!target.exists() || target.length() == 0L) {
                val tmp = File(dir, "$lang.tmp")
                context.assets.open("tessdata/$lang.traineddata").use { input ->
                    tmp.outputStream().use { input.copyTo(it) }
                }
                tmp.renameTo(target)
            }
        }
        return base.absolutePath
    }

    /** ImageDecoder сам учитывает поворот фото (EXIF). Большие фото уменьшаем — так быстрее. */
    private fun loadBitmap(uri: Uri): Bitmap {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        val bmp = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val w = info.size.width
            val h = info.size.height
            val longest = max(w, h)
            if (longest > MAX_SIDE) {
                val scale = MAX_SIDE.toFloat() / longest
                decoder.setTargetSize((w * scale).toInt(), (h * scale).toInt())
            }
        }
        return if (bmp.config == Bitmap.Config.ARGB_8888) bmp
        else bmp.copy(Bitmap.Config.ARGB_8888, false).also { bmp.recycle() }
    }

    /** Убираем мусор, но сохраняем абзацы (пустая строка между ними). */
    private fun cleanup(raw: String): String {
        val lines = raw.replace("\r", "").lines().map { it.trimEnd() }
        val out = StringBuilder()
        var blank = 0
        for (line in lines) {
            if (line.isBlank()) {
                blank++
            } else {
                if (out.isNotEmpty()) out.append(if (blank > 0) "\n\n" else "\n")
                out.append(line)
                blank = 0
            }
        }
        return out.toString()
    }

    companion object {
        private val LANGS = listOf("rus", "eng")
        private const val MAX_SIDE = 2400
    }
}
