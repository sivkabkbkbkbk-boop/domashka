package ru.domashka.ocr

/**
 * Находит на снимке дневника список уроков и понимает, по каким есть домашка.
 * Сам текст задания не нужен — только предмет и «задано / не задано».
 *
 * Названия сравниваются со словарём с допуском на ошибки распознавания:
 * «Рус. яз», «Pyc. язык», «Груд (технология)» — всё поймётся.
 */
object SubjectParser {

    private const val NO_LESSON = "Нет урока"

    /** Официальное название → как его пишут в дневнике (без точек и пробелов сравнивается). */
    private val DICTIONARY: Map<String, List<String>> = linkedMapOf(
        "Русский язык" to listOf("русский язык", "рус яз", "рус язык", "русск яз", "русский"),
        "Литература" to listOf("литература", "лит ра", "литер", "литературное чтение", "литра"),
        "Математика" to listOf("математика", "матем", "мат ка"),
        "Алгебра" to listOf("алгебра"),
        "Геометрия" to listOf("геометрия"),
        "Вероятность и статистика" to listOf("вероятность и статистика", "вероятность"),
        "Английский язык" to listOf("английский язык", "англ яз", "англ язык", "английский", "иностранный язык", "ин яз", "иностр яз"),
        "Немецкий язык" to listOf("немецкий язык", "нем яз", "немецкий"),
        "Французский язык" to listOf("французский язык", "франц яз", "французский"),
        "Китайский язык" to listOf("китайский язык", "кит яз", "китайский"),
        "История" to listOf("история", "всеобщая история", "история россии"),
        "Обществознание" to listOf("обществознание", "общество"),
        "География" to listOf("география"),
        "Биология" to listOf("биология"),
        "Физика" to listOf("физика"),
        "Химия" to listOf("химия"),
        "Информатика" to listOf("информатика"),
        "Окружающий мир" to listOf("окружающий мир"),
        "Музыка" to listOf("музыка"),
        "ИЗО" to listOf("изо", "изобразительное искусство"),
        "Труд (технология)" to listOf("труд технология", "труд", "технология"),
        "Физкультура" to listOf("физкультура", "физическая культура", "физ ра", "физ культура"),
        "ОДНКНР" to listOf("однкнр"),
        "ОБЗР" to listOf("обзр", "обж"),
        "Родной язык" to listOf("родной язык"),
        "Родная литература" to listOf("родная литература"),
        "Разговоры о важном" to listOf("разговоры о важном", "разг о важном"),
        "Экскурсионная деятельность" to listOf("экскурсионная деятельность", "экскурсионная деят"),
        "Школа исследователя" to listOf("школа исследователя", "школа исследовате"),
        "Функциональная грамотность" to listOf("функциональная грамотность", "функц грамотность"),
        "Россия — мои горизонты" to listOf("россия мои горизонты"),
        "Проектная деятельность" to listOf("проектная деятельность", "проектная деят"),
        NO_LESSON to listOf("нет урока"),
    )

    /** Список предметов для подсказок при выборе. */
    val COMMON: List<String> = DICTIONARY.keys.filter { it != NO_LESSON }

    /** Урок на снимке. hasHomework: true — задано, false — «не задано», null — не понятно. */
    data class Lesson(val subject: String, val hasHomework: Boolean?)

    /** Латинские буквы, похожие на русские (распознаватель их путает): P→Р, y→у, c→с… */
    private val LOOKALIKE = mapOf(
        'a' to 'а', 'b' to 'в', 'c' to 'с', 'e' to 'е', 'h' to 'н', 'k' to 'к', 'm' to 'м',
        'n' to 'п', 'o' to 'о', 'p' to 'р', 'r' to 'г', 't' to 'т', 'u' to 'и', 'x' to 'х', 'y' to 'у',
    )

    /** Цифры, похожие на буквы, — только внутри слова («Лuтерат0ра»), а не во времени «8:30». */
    private val DIGIT_LOOKALIKE = mapOf('0' to 'о', '3' to 'з', '6' to 'б')

    /** Только русские буквы, без точек и пробелов: «Pyc. язык» → «русязык». */
    private fun compact(s: String): String {
        val low = s.lowercase()
        val sb = StringBuilder()
        for (i in low.indices) {
            val ch = low[i]
            var c = if (ch == 'ё') 'е' else LOOKALIKE[ch] ?: ch
            val d = DIGIT_LOOKALIKE[ch]
            if (d != null) {
                val prev = low.getOrNull(i - 1)
                val next = low.getOrNull(i + 1)
                if (prev?.isLetter() == true || next?.isLetter() == true) c = d
            }
            if (c in 'а'..'я') sb.append(c)
        }
        return sb.toString()
    }

    private val ALIASES: List<Pair<String, String>> = DICTIONARY
        .flatMap { (canon, list) -> list.map { compact(it) to canon } }
        .sortedByDescending { it.first.length }

    private val NUMBERING = Regex("""^[^\p{L}\d]*\d{1,2}\s*[.,)]?\s+""")
    private val LESSON = Regex("""^[^\p{L}\d]*\d{1,2}\s*[.,]?\s+(?=[А-ЯЁA-Z])""")
    private val HEADER = Regex("""[\p{L}\d][\p{L}\d .()\-]*""")
    private val TIME = Regex("""^\D{0,3}\d{1,2}\s*[:.]\s*\S{2}\s*[-–—~]""")
    private val WORD = Regex("""[a-zа-яё]{3,}""")

    private fun levenshtein(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length]
    }

    /** Сколько опечаток прощаем: короткие слова — точно, длинные — с запасом. */
    private fun tolerance(n: Int) = when {
        n <= 4 -> 0
        n <= 8 -> 1
        else -> n / 5
    }

    /** Если строка — название предмета из словаря, вернёт официальное название. */
    private fun dictionaryMatch(line: String, known: List<Pair<String, String>>): String? {
        val c = compact(line.replace(NUMBERING, ""))
        if (c.isEmpty()) return null
        var best: Triple<Int, String, Int>? = null // оценка, название, длина
        for ((alias, canon) in known + ALIASES) {
            if (alias.isEmpty() || c.length > alias.length + 14) continue
            val tol = tolerance(alias.length)
            // название может стоять не с начала: «9:00 1 Рус. язык» (время в той же строке)
            for (start in 0..minOf(6, maxOf(0, c.length - alias.length + 1))) {
                for (len in alias.length - 1..alias.length + 1) {
                    if (len <= 0 || start + len > c.length) continue
                    val d = levenshtein(c.substring(start, start + len), alias)
                    if (d > tol) continue
                    val score = d + if (start > 0) 1 else 0
                    val b = best
                    if (b == null || score < b.first || (score == b.first && alias.length > b.third)) {
                        best = Triple(score, canon, alias.length)
                    }
                }
            }
        }
        return best?.second
    }

    /**
     * Похоже ли на название нового предмета: хотя бы одно русское слово из 4+ букв,
     * слова в среднем не короче 3 букв (отсекает мусор вроде «А У ДТ ь»).
     */
    private fun looksLikeName(s: String): Boolean {
        val words = s.split(' ', '.', '(', ')', '-').filter { it.isNotBlank() }
        if (words.isEmpty()) return false
        val longWord = words.any { w -> w.length >= 4 && w.all { it in 'а'..'я' || it in 'А'..'Я' || it == 'ё' || it == 'Ё' } }
        val avg = words.sumOf { it.length }.toFloat() / words.size
        return longWord && avg >= 3f
    }

    private fun isTime(line: String): Boolean {
        val letters = line.count { it.isLetter() }
        val digits = line.count { it.isDigit() }
        return (letters <= 2 && digits >= 3) || TIME.containsMatchIn(line)
    }

    private fun isNotAssigned(line: String): Boolean {
        val c = compact(line)
        if ("незадан" in c) return true
        if (c.length < 7) return levenshtein(c, "незадано") <= 2
        return (0..c.length - 7).any { i -> levenshtein(c.substring(i, minOf(c.length, i + 8)), "незадано") <= 2 }
    }

    fun parse(raw: String, knownSubjects: List<String>): List<Lesson> {
        // предметы, которые уже есть в приложении, тоже узнаём
        val known = knownSubjects.map { compact(it) to it }.filter { it.first.length >= 3 }

        class Acc(val subject: String) {
            var notAssigned = false
            var locked = false
            var words = 0
        }

        val lessons = mutableListOf<Acc>()
        var current: Acc? = null
        var afterHeader = false

        for (rawLine in raw.lines()) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue

            var subject = dictionaryMatch(line, known)
            if (subject == null && LESSON.containsMatchIn(line) && line.length <= 45) {
                // новый, незнакомый предмет с номером урока — берём название с фото
                subject = HEADER.find(line.replace(NUMBERING, ""))?.value?.trim(' ', '.', '-')
                    ?.takeIf { looksLikeName(it) }
            }
            if (subject != null) {
                current = Acc(subject).also { lessons += it }
                afterHeader = true
                continue
            }
            val cur = current ?: continue
            if (afterHeader) {
                afterHeader = false
                // строка под названием — время и кабинет, даже если прочиталась мусором
                val words = line.split(' ').filter { it.isNotBlank() }
                val junky = line.length <= 25 && line.none { it.isDigit() } &&
                    words.isNotEmpty() && words.sumOf { it.length }.toFloat() / words.size < 3.5f
                if ((isTime(line) || junky) && !isNotAssigned(line)) continue
            }
            if (isTime(line)) continue
            if (isNotAssigned(line)) {
                cur.notAssigned = true
                // «не задано» сразу под уроком — всё, что ниже, уже не про этот урок
                if (cur.words < 3) cur.locked = true
                continue
            }
            if (!cur.locked) {
                // «WB p.14», «№98» — коротко, но это тоже задание
                val w = WORD.findAll(line.lowercase()).count()
                cur.words += maxOf(w, if (line.count { it.isLetterOrDigit() } >= 3) 1 else 0)
            }
        }

        // склеиваем одинаковые уроки (две «Труд» подряд)
        val result = LinkedHashMap<String, Boolean?>()
        for (l in lessons) {
            if (l.subject == NO_LESSON) continue
            val hw: Boolean? = when {
                l.notAssigned -> l.words >= 3
                l.words >= 1 -> true
                else -> null
            }
            val key = compact(l.subject)
            val prevKey = result.keys.firstOrNull { compact(it) == key }
            if (prevKey == null) {
                result[l.subject] = hw
            } else {
                val prev = result[prevKey]
                result[prevKey] = when {
                    prev == true || hw == true -> true
                    prev == false || hw == false -> false
                    else -> null
                }
            }
        }
        return result.map { (s, hw) -> Lesson(s, hw) }
    }
}
