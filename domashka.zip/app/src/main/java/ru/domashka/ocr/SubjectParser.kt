package ru.domashka.ocr

import ru.domashka.data.SubjectKey

/**
 * Делит распознанный текст на куски по предметам.
 * Если строка начинается с названия предмета («Математика: №245…») — начинается новый кусок.
 */
object SubjectParser {

    val COMMON = listOf(
        "Математика", "Алгебра", "Геометрия", "Вероятность и статистика",
        "Русский язык", "Литература", "Родной язык", "Родная литература",
        "Английский язык", "Немецкий язык", "Французский язык", "Китайский язык",
        "История", "Обществознание", "География", "Биология", "Физика", "Химия",
        "Информатика", "ОДНКНР", "ОБЗР", "ОБЖ", "Музыка", "ИЗО",
        "Технология", "Труд", "Физкультура", "Физическая культура",
    )

    /** Сокращения, которые часто встречаются в дневнике. */
    private val ALIASES = mapOf(
        "русский" to "Русский язык",
        "рус. яз" to "Русский язык",
        "английский" to "Английский язык",
        "англ. яз" to "Английский язык",
        "иностранный язык" to "Английский язык",
        "немецкий" to "Немецкий язык",
        "французский" to "Французский язык",
        "литературное чтение" to "Литература",
        "физ-ра" to "Физкультура",
        "физра" to "Физкультура",
        "изобразительное искусство" to "ИЗО",
        "основы духовно-нравственной культуры народов россии" to "ОДНКНР",
    )

    data class Block(val subject: String?, val text: String)

    private data class Candidate(val key: String, val display: String)

    fun split(raw: String, knownSubjects: List<String>): List<Block> {
        val candidates = buildCandidates(knownSubjects)
        val blocks = mutableListOf<Pair<String?, StringBuilder>>()
        var current: Pair<String?, StringBuilder>? = null

        for (line in raw.lines()) {
            val match = matchLineStart(line.trim(), candidates)
            if (match != null) {
                current = match.first to StringBuilder(match.second)
                blocks += current
            } else {
                if (current == null) {
                    current = null as String? to StringBuilder()
                    blocks += current
                }
                val sb = current.second
                if (sb.isNotEmpty() || line.isNotBlank()) {
                    if (sb.isNotEmpty()) sb.append('\n')
                    sb.append(line)
                }
            }
        }

        var result = blocks
            .map { (subject, sb) -> Block(subject, sb.toString().trim()) }
            .filter { it.text.isNotBlank() }

        // Короткий заголовок сверху («Домашнее задание на 26 сентября») — не задание
        val first = result.firstOrNull()
        if (first != null && first.subject == null && result.size > 1 &&
            !first.text.contains('\n') && first.text.length <= 60
        ) {
            result = result.drop(1)
        }

        if (result.isEmpty()) return listOf(Block(findAnywhere(raw, candidates), raw.trim()))

        // Если предмет нигде в начале строк не нашёлся — поищем упоминание в тексте
        return if (result.size == 1 && result[0].subject == null) {
            listOf(result[0].copy(subject = findAnywhere(raw, candidates)))
        } else result
    }

    private fun buildCandidates(known: List<String>): List<Candidate> {
        val all = LinkedHashMap<String, String>()
        (known + COMMON).forEach { name ->
            val key = SubjectKey.of(name)
            if (key.isNotEmpty() && key !in all) all[key] = SubjectKey.clean(name)
        }
        ALIASES.forEach { (alias, target) ->
            val targetKey = SubjectKey.of(target)
            val display = known.firstOrNull { SubjectKey.of(it) == targetKey } ?: target
            if (alias !in all) all[alias] = display
        }
        // Длинные названия проверяем первыми: «Русский язык» раньше, чем «Русский»
        return all.map { Candidate(it.key, it.value) }.sortedByDescending { it.key.length }
    }

    /** Возвращает (предмет, остаток строки) если строка начинается с названия предмета. */
    private fun matchLineStart(line: String, candidates: List<Candidate>): Pair<String, String>? {
        if (line.isEmpty()) return null
        val norm = line.lowercase().replace('ё', 'е')
        for (c in candidates) {
            if (norm.startsWith(c.key)) {
                val next = norm.getOrNull(c.key.length)
                if (next != null && next.isLetter()) continue // «Историческое…» — не предмет
                val rest = line.substring(c.key.length).trimStart(' ', ':', '-', '–', '—', '.', ',', '|', '\t')
                return c.display to rest
            }
        }
        return null
    }

    private fun findAnywhere(text: String, candidates: List<Candidate>): String? {
        val norm = text.lowercase().replace('ё', 'е')
        return candidates.firstOrNull { c ->
            val idx = norm.indexOf(c.key)
            idx >= 0 &&
                (idx == 0 || !norm[idx - 1].isLetter()) &&
                (norm.getOrNull(idx + c.key.length)?.isLetter() != true)
        }?.display
    }
}
