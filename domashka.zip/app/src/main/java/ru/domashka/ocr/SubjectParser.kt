package ru.domashka.ocr

import ru.domashka.data.SubjectKey

/**
 * Делит распознанный текст на задания по предметам.
 *
 * Формат Дневника.ру:
 *   2. Рус. язык
 *   9:25 - 10:05, 311        <- строка со временем урока
 *   №98 с.61 выписать ...    <- задание
 * Строка, за которой идёт время урока, считается названием предмета.
 * Кроме того, строка, начинающаяся с известного предмета («Математика: №245»), тоже начинает новое задание.
 * «не задано», «Нет урока» и мусор распознавания выбрасываются, одинаковые предметы склеиваются.
 */
object SubjectParser {

    val COMMON = listOf(
        "Математика", "Алгебра", "Геометрия", "Вероятность и статистика",
        "Русский язык", "Литература", "Родной язык", "Родная литература",
        "Английский язык", "Немецкий язык", "Французский язык", "Китайский язык",
        "История", "Обществознание", "География", "Биология", "Физика", "Химия",
        "Информатика", "ОДНКНР", "ОБЗР", "ОБЖ", "Музыка", "ИЗО",
        "Технология", "Труд", "Физкультура", "Физическая культура",
    )

    /** Сокращения из дневника. Ключ — только буквы, без точек и пробелов. */
    private val ALIASES = mapOf(
        "рус" to "Русский язык",
        "русяз" to "Русский язык",
        "русязык" to "Русский язык",
        "русский" to "Русский язык",
        "англ" to "Английский язык",
        "англяз" to "Английский язык",
        "англязык" to "Английский язык",
        "английский" to "Английский язык",
        "иностранныйязык" to "Английский язык",
        "иностранныйязыканглийский" to "Английский язык",
        "литра" to "Литература",
        "литературноечтение" to "Литература",
        "матем" to "Математика",
        "физра" to "Физкультура",
        "физкра" to "Физкультура",
        "изобразительноеискусство" to "ИЗО",
    )

    data class Block(val subject: String?, val text: String)

    private val TIME = Regex("""^\D{0,4}\d{1,2}\s*[:.]\s*\d{2}\s*[-–—~]+\s*\d{1,2}\s*[:.]\s*\d{2}""")
    private val NUMBERING = Regex("""^[^\p{L}\d№]*\d{1,2}\s*[.,)]?\s+""")
    private val EMPTY = Regex("""(не\s*задано|нет\s*урока|не\s*задан)[\s;.,]*""", RegexOption.IGNORE_CASE)
    private val HEADER = Regex("""[\p{L}\d][\p{L}\d .()\-]*""")

    private fun compact(s: String) =
        s.lowercase().replace('ё', 'е').filter { it.isLetter() }

    private fun isTime(line: String) = TIME.containsMatchIn(line)

    /** Строка из обрывков символов: мало букв и цифр. */
    private fun isGarbage(line: String): Boolean {
        val nonSpace = line.count { !it.isWhitespace() }
        val meaningful = line.count { it.isLetterOrDigit() }
        return meaningful < 2 || meaningful.toFloat() / nonSpace < 0.6f
    }

    private fun cleanHeader(text: String): String =
        HEADER.find(text)?.value?.trim(' ', '-', '.')?.ifEmpty { null } ?: text.trim()

    fun split(raw: String, knownSubjects: List<String>): List<Block> {
        val all = (knownSubjects + COMMON)
        val byCompact = LinkedHashMap<String, String>()
        all.forEach { n -> byCompact.putIfAbsent(compact(n), SubjectKey.clean(n)) }

        fun canonical(name: String): String {
            val c = compact(name)
            byCompact[c]?.let { return it }
            ALIASES[c]?.let { target ->
                return knownSubjects.firstOrNull { compact(it) == compact(target) } ?: target
            }
            return name
        }

        // для строк вида «Математика: №245» — ищем известный предмет в начале
        val prefixCandidates = byCompact.values
            .map { SubjectKey.of(it) to it }
            .sortedByDescending { it.first.length }

        fun matchPrefix(line: String): Pair<String, String>? {
            val norm = line.lowercase().replace('ё', 'е')
            for ((key, display) in prefixCandidates) {
                if (key.isEmpty() || !norm.startsWith(key)) continue
                val next = norm.getOrNull(key.length)
                if (next != null && (next.isLetter() || next == ' ' && norm.length > key.length + 1 &&
                            norm[key.length + 1] == '(')) continue
                val rest = line.substring(key.length).trimStart(' ', ':', '-', '–', '—', '.', ',', '|', '\t')
                return display to rest
            }
            return null
        }

        val lines = raw.replace("\r", "").lines().map { it.trim().trimStart('|', '¦', '!', '_', '~', '\'', '`').trim() }
        val blocks = mutableListOf<Pair<String?, StringBuilder>>()
        var current: Pair<String?, StringBuilder>? = null

        for ((i, line) in lines.withIndex()) {
            if (line.isEmpty()) {
                val sb = current?.second
                if (sb != null && sb.isNotEmpty() && !sb.endsWith("\n\n")) sb.append('\n')
                continue
            }
            if (isTime(line) || isGarbage(line)) continue

            val body = line.replace(NUMBERING, "")
            val next = lines.subList(i + 1, lines.size).firstOrNull { it.isNotEmpty() }

            if (next != null && isTime(next)) {
                current = canonical(cleanHeader(body)) to StringBuilder()
                blocks += current
                continue
            }
            val prefix = matchPrefix(body)
            if (prefix != null) {
                current = prefix.first to StringBuilder(prefix.second)
                blocks += current
                continue
            }
            if (current == null) {
                current = null as String? to StringBuilder()
                blocks += current
            }
            val sb = current.second
            if (sb.isNotEmpty() && !sb.endsWith("\n")) sb.append('\n')
            sb.append(line)
        }

        // чистим и склеиваем одинаковые предметы
        val merged = LinkedHashMap<String, Block>()
        for ((subject, sb) in blocks) {
            val text = sb.toString().replace(EMPTY, "").trim()
            if (text.count { it.isLetterOrDigit() } < 2) continue
            if (subject != null && compact(subject) == "нетурока") continue
            val k = subject?.let { compact(it) } ?: ""
            val prev = merged[k]
            merged[k] = if (prev == null) Block(subject, text) else prev.copy(text = prev.text + "\n" + text)
        }
        var result = merged.values.toList()

        // короткий заголовок сверху («Домашнее задание на 26 сентября») — не задание
        val first = result.firstOrNull()
        if (first != null && first.subject == null && result.size > 1 &&
            !first.text.contains('\n') && first.text.length <= 60
        ) result = result.drop(1)

        if (result.isEmpty()) {
            val text = raw.trim()
            return if (text.isEmpty()) emptyList() else listOf(Block(null, text))
        }
        return result
    }
}
