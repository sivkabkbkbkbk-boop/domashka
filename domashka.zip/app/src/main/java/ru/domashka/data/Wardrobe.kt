package ru.domashka.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Куда надевается вещь. */
enum class Slot(val title: String) {
    HEAD("Голова"), EYES("Глаза"), NECK("Шея"), BACK("Спина"), COLOR("Перья")
}

/** Вещь для голубя. Открывается ачивкой achId. */
data class Item(val id: String, val slot: Slot, val emoji: String, val name: String, val achId: String)

object Items {
    val ALL = listOf(
        Item("cap", Slot.HEAD, "🧢", "Кепка", "first"),
        Item("sun", Slot.EYES, "🕶️", "Тёмные очки", "done5"),
        Item("chain", Slot.NECK, "📿", "Золотая цепь", "done25"),
        Item("crown", Slot.HEAD, "👑", "Корона", "done100"),
        Item("bowtie", Slot.NECK, "🎀", "Бабочка", "allday"),
        Item("gold", Slot.COLOR, "✨", "Золотые перья", "allday10"),
        Item("scarf", Slot.NECK, "🧣", "Шарф", "streak3"),
        Item("cape", Slot.BACK, "🦸", "Плащ героя", "streak7"),
        Item("black", Slot.COLOR, "🥷", "Перья ниндзя", "streak30"),
        Item("tie", Slot.NECK, "👔", "Галстук", "hour1"),
        Item("tophat", Slot.HEAD, "🎩", "Цилиндр", "hour10"),
        Item("pixel", Slot.EYES, "😎", "Пиксельные очки", "fast"),
        Item("nerd", Slot.EYES, "🤓", "Очки ботаника", "focus"),
        Item("medal", Slot.NECK, "🏅", "Медаль", "beat5"),
        Item("party", Slot.HEAD, "🥳", "Праздничный колпак", "five"),
        Item("beanie", Slot.HEAD, "🧶", "Шапка с помпоном", "early"),
        Item("cowboy", Slot.HEAD, "🤠", "Ковбойская шляпа", "weekend"),
        Item("backpack", Slot.BACK, "🎒", "Рюкзак", "scan5"),
        Item("blue", Slot.COLOR, "❄️", "Ледяные перья", "math10"),
        Item("white", Slot.COLOR, "🤍", "Белые перья", "rus10"),
        Item("monocle", Slot.EYES, "🧐", "Монокль", "eng10"),
        Item("hearts", Slot.EYES, "💗", "Очки-сердечки", "pets10"),
        Item("pink", Slot.COLOR, "🌸", "Розовые перья", "seeds20"),
        Item("headphones", Slot.HEAD, "🎧", "Наушники", "dance5"),
    )

    fun forAchievement(achId: String): Item? = ALL.firstOrNull { it.achId == achId }
    fun byId(id: String?): Item? = ALL.firstOrNull { it.id == id }
}

/** Что сейчас надето. null — ничего. */
data class Outfit(
    val head: String? = null,
    val eyes: String? = null,
    val neck: String? = null,
    val back: String? = null,
    val color: String? = null,
) {
    fun get(slot: Slot): String? = when (slot) {
        Slot.HEAD -> head
        Slot.EYES -> eyes
        Slot.NECK -> neck
        Slot.BACK -> back
        Slot.COLOR -> color
    }

    fun with(slot: Slot, id: String?): Outfit = when (slot) {
        Slot.HEAD -> copy(head = id)
        Slot.EYES -> copy(eyes = id)
        Slot.NECK -> copy(neck = id)
        Slot.BACK -> copy(back = id)
        Slot.COLOR -> copy(color = id)
    }
}

/** Гардероб голубя: хранит надетые вещи. */
class WardrobeStore(context: Context) {
    private val prefs = context.getSharedPreferences("wardrobe", Context.MODE_PRIVATE)
    private val _outfit = MutableStateFlow(
        Outfit(
            head = prefs.getString("HEAD", null),
            eyes = prefs.getString("EYES", null),
            neck = prefs.getString("NECK", null),
            back = prefs.getString("BACK", null),
            color = prefs.getString("COLOR", null),
        )
    )
    val outfit: StateFlow<Outfit> = _outfit.asStateFlow()

    /** Надеть; если уже надето — снять. */
    fun toggle(item: Item) {
        val current = _outfit.value.get(item.slot)
        set(item.slot, if (current == item.id) null else item.id)
    }

    fun set(slot: Slot, id: String?) {
        _outfit.value = _outfit.value.with(slot, id)
        prefs.edit().putString(slot.name, id).apply()
    }

    /** Новую вещь надеваем сами, если это место свободно. */
    fun autoEquip(item: Item) {
        if (_outfit.value.get(item.slot) == null) set(item.slot, item.id)
    }
}
