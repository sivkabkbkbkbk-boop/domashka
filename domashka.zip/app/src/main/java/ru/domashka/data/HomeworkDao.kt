package ru.domashka.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface HomeworkDao {
    @Query("SELECT * FROM subjects")
    fun subjects(): Flow<List<Subject>>

    @Query("SELECT * FROM tasks ORDER BY done ASC, createdAt DESC")
    fun tasks(): Flow<List<HomeworkTask>>

    @Query("SELECT * FROM subjects WHERE nameKey = :key LIMIT 1")
    suspend fun subjectByKey(key: String): Subject?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSubject(subject: Subject): Long

    @Update
    suspend fun updateSubject(subject: Subject)

    @Delete
    suspend fun deleteSubject(subject: Subject)

    @Query("UPDATE tasks SET subjectId = :to WHERE subjectId = :from")
    suspend fun moveTasks(from: Long, to: Long)

    @Insert
    suspend fun insertTask(task: HomeworkTask): Long

    @Update
    suspend fun updateTask(task: HomeworkTask)

    @Delete
    suspend fun deleteTask(task: HomeworkTask)

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun task(id: Long): HomeworkTask?

    @Query("SELECT COUNT(*) FROM tasks WHERE subjectId = :subjectId AND done = 0")
    suspend fun countOpen(subjectId: Long): Int

    @Query("SELECT COUNT(*) FROM tasks WHERE done = 0")
    suspend fun countUndone(): Int

    @Query("SELECT * FROM tasks WHERE timerStartedAt IS NOT NULL")
    suspend fun runningTasks(): List<HomeworkTask>
}
