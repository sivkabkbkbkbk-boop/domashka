package ru.domashka.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

/** Счётчики, из которых считаются ачивки. Хранятся на телефоне. */
data class AchStats(
    val done: Int = 0,
    val timedMs: Long = 0,
    val streak: Int = 0,
    val bestStreak: Int = 0,
    val lastDoneDay: Long = -10,
    val allDoneDays: Int = 0,
    val fast: Int = 0,            // задания быстрее 10 минут (с таймером)
    val longFocus: Int = 0,       // 30+ минут без остановки
    val beatAverage: Int = 0,     // быстрее своего среднего
    val weekend: Int = 0,
    val early: Int = 0,           // сделано до 16:00
    val maxInDay: Int = 0,
    val todayCount: Int = 0,
    val scans: Int = 0,
    val pets: Int = 0,
    val seeds: Int = 0,
    val dances: Int = 0,
    val math: Int = 0,
    val english: Int = 0,
    val russian: Int = 0,
)

data class Achievement(
    val id: String,
    val emoji: String,
    val title: String,
    val description: String,
    val target: Int,
    val progress: (AchStats) -> Int,
)

object AchievementList {
    val ALL = listOf(
        Achievement("first", "🐣", "Первый шаг", "Сделай первое задание", 1) { it.done },
        Achievement("done5", "🔥", "Разогрев", "Сделай 5 заданий", 5) { it.done },
        Achievement("done25", "⚙️", "Машина", "Сделай 25 заданий", 25) { it.done },
        Achievement("done100", "👑", "Легенда двора", "Сделай 100 заданий", 100) { it.done },
        Achievement("allday", "🏁", "Чистый день", "Сделай всю домашку за день", 1) { it.allDoneDays },
        Achievement("allday10", "🏆", "Десять чистых дней", "10 дней, когда сделано всё", 10) { it.allDoneDays },
        Achievement("streak3", "📅", "Три дня подряд", "Делай домашку 3 дня подряд", 3) { it.bestStreak },
        Achievement("streak7", "🗓️", "Неделя силы", "7 дней подряд", 7) { it.bestStreak },
        Achievement("streak30", "💎", "Железная воля", "30 дней подряд", 30) { it.bestStreak },
        Achievement("hour1", "⏱️", "Час силы", "Набери 1 час по таймеру", 60) { (it.timedMs / 60_000).toInt() },
        Achievement("hour10", "🕰️", "Десять часов", "Набери 10 часов по таймеру", 600) { (it.timedMs / 60_000).toInt() },
        Achievement("fast", "⚡", "Спринтер", "Сделай задание быстрее 10 минут", 1) { it.fast },
        Achievement("focus", "🧘", "Усидчивый", "30 минут без остановки", 1) { it.longFocus },
        Achievement("beat5", "📈", "Быстрее себя", "5 раз обгони своё обычное время", 5) { it.beatAverage },
        Achievement("five", "🖐️", "Пятёрка за день", "Сделай 5 заданий за один день", 5) { it.maxInDay },
        Achievement("early", "🌤️", "Сделал — гуляй", "Закончи задание до 16:00", 1) { it.early },
        Achievement("weekend", "🛋️", "Герой выходных", "Сделай задание в выходной", 1) { it.weekend },
        Achievement("scan5", "📸", "Фотограф", "Распознай дневник 5 раз", 5) { it.scans },
        Achievement("math10", "🧮", "Математик", "10 заданий по математике", 10) { it.math },
        Achievement("rus10", "✍️", "Грамотей", "10 заданий по русскому", 10) { it.russian },
        Achievement("eng10", "🇬🇧", "Полиглот", "10 заданий по английскому", 10) { it.english },
        Achievement("pets10", "🥰", "Друг голубя", "Погладь голубя 10 раз", 10) { it.pets },
        Achievement("seeds20", "🌻", "Кормилец", "Накорми голубя 20 раз", 20) { it.seeds },
        Achievement("dance5", "🕺", "Тусовщик", "Потанцуй с голубем 5 раз", 5) { it.dances },
    )
}

/** Хранилище ачивок: считает, открывает, запоминает. */
class AchievementStore(context: Context) {
    private val prefs = context.getSharedPreferences("achievements", Context.MODE_PRIVATE)
    private val _stats = MutableStateFlow(load())
    val stats: StateFlow<AchStats> = _stats.asStateFlow()
    private val _unlocked = MutableStateFlow(prefs.getStringSet("unlocked", emptySet())!!.toSet())
    val unlocked: StateFlow<Set<String>> = _unlocked.asStateFlow()

    private fun load() = AchStats(
        done = prefs.getInt("done", 0), timedMs = prefs.getLong("timedMs", 0),
        streak = prefs.getInt("streak", 0), bestStreak = prefs.getInt("bestStreak", 0),
        lastDoneDay = prefs.getLong("lastDoneDay", -10), allDoneDays = prefs.getInt("allDoneDays", 0),
        fast = prefs.getInt("fast", 0), longFocus = prefs.getInt("longFocus", 0),
        beatAverage = prefs.getInt("beatAverage", 0), weekend = prefs.getInt("weekend", 0),
        early = prefs.getInt("early", 0), maxInDay = prefs.getInt("maxInDay", 0),
        todayCount = prefs.getInt("todayCount", 0), scans = prefs.getInt("scans", 0),
        pets = prefs.getInt("pets", 0), seeds = prefs.getInt("seeds", 0), dances = prefs.getInt("dances", 0),
        math = prefs.getInt("math", 0), english = prefs.getInt("english", 0), russian = prefs.getInt("russian", 0),
    )

    private fun save(s: AchStats) {
        prefs.edit()
            .putInt("done", s.done).putLong("timedMs", s.timedMs)
            .putInt("streak", s.streak).putInt("bestStreak", s.bestStreak)
            .putLong("lastDoneDay", s.lastDoneDay).putInt("allDoneDays", s.allDoneDays)
            .putInt("fast", s.fast).putInt("longFocus", s.longFocus)
            .putInt("beatAverage", s.beatAverage).putInt("weekend", s.weekend)
            .putInt("early", s.early).putInt("maxInDay", s.maxInDay)
            .putInt("todayCount", s.todayCount).putInt("scans", s.scans)
            .putInt("pets", s.pets).putInt("seeds", s.seeds).putInt("dances", s.dances)
            .putInt("math", s.math).putInt("english", s.english).putInt("russian", s.russian)
            .apply()
    }

    /** Меняет счётчики и возвращает только что открытые ачивки. */
    @Synchronized
    private fun update(change: (AchStats) -> AchStats): List<Achievement> {
        val next = change(_stats.value)
        _stats.value = next
        save(next)
        val have = _unlocked.value
        val fresh = AchievementList.ALL.filter { it.id !in have && it.progress(next) >= it.target }
        if (fresh.isNotEmpty()) {
            val all = have + fresh.map { it.id }
            _unlocked.value = all
            prefs.edit().putStringSet("unlocked", all).apply()
        }
        return fresh
    }

    fun onTaskFinished(subject: String, spentMs: Long, averageMs: Long, allDone: Boolean): List<Achievement> {
        val today = LocalDate.now()
        val day = today.toEpochDay()
        val subj = subject.lowercase()
        return update { s ->
            val streak = when (s.lastDoneDay) {
                day -> s.streak
                day - 1 -> s.streak + 1
                else -> 1
            }
            val todayCount = if (s.lastDoneDay == day) s.todayCount + 1 else 1
            s.copy(
                done = s.done + 1,
                timedMs = s.timedMs + spentMs,
                streak = streak,
                bestStreak = maxOf(s.bestStreak, streak),
                lastDoneDay = day,
                todayCount = todayCount,
                maxInDay = maxOf(s.maxInDay, todayCount),
                allDoneDays = s.allDoneDays + if (allDone) 1 else 0,
                fast = s.fast + if (spentMs in 60_000L until 600_000L) 1 else 0,
                longFocus = s.longFocus + if (spentMs >= 30 * 60_000) 1 else 0,
                beatAverage = s.beatAverage + if (averageMs >= 60_000L && spentMs in 60_000L until averageMs) 1 else 0,
                weekend = s.weekend + if (today.dayOfWeek == DayOfWeek.SATURDAY || today.dayOfWeek == DayOfWeek.SUNDAY) 1 else 0,
                early = s.early + if (LocalTime.now().hour < 16) 1 else 0,
                math = s.math + if ("матем" in subj || "алгеб" in subj || "геометр" in subj) 1 else 0,
                english = s.english + if ("англ" in subj) 1 else 0,
                russian = s.russian + if ("рус" in subj) 1 else 0,
            )
        }
    }

    fun onScan() = update { it.copy(scans = it.scans + 1) }

    fun onPet(kind: String) = update {
        when (kind) {
            "PET" -> it.copy(pets = it.pets + 1)
            "SEED" -> it.copy(seeds = it.seeds + 1)
            "DANCE" -> it.copy(dances = it.dances + 1)
            else -> it
        }
    }
}
