package ru.domashka.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** Предмет. nameKey — нормализованное имя, чтобы не было дублей («Русский язык» = «русский  язык»). */
@Entity(
    tableName = "subjects",
    indices = [Index(value = ["nameKey"], unique = true)]
)
data class Subject(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val nameKey: String,
)

/** Домашнее задание. spentMs — накопленное время, timerStartedAt — когда запущен таймер (null = стоит). */
@Entity(
    tableName = "tasks",
    foreignKeys = [
        ForeignKey(
            entity = Subject::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("subjectId")]
)
data class HomeworkTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val text: String,
    val done: Boolean = false,
    val createdAt: Long,
    val doneAt: Long? = null,
    val spentMs: Long = 0,
    val timerStartedAt: Long? = null,
)

/** Сколько всего потрачено на задание (с учётом идущего таймера). */
fun HomeworkTask.elapsed(now: Long): Long =
    spentMs + (timerStartedAt?.let { (now - it).coerceAtLeast(0) } ?: 0)

val HomeworkTask.isRunning: Boolean get() = timerStartedAt != null

object SubjectKey {
    private val spaces = Regex("\\s+")
    fun of(name: String): String =
        name.trim().lowercase().replace('ё', 'е').replace(spaces, " ")

    fun clean(name: String): String = name.trim().replace(spaces, " ")
}
